-- Create properties table for user posted ads
CREATE TABLE public.properties (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  property_type text NOT NULL,
  furnishing text,
  rent numeric NOT NULL,
  security_deposit numeric,
  city text NOT NULL,
  area text NOT NULL,
  address text,
  bedrooms integer DEFAULT 0,
  bathrooms integer DEFAULT 0,
  sqft integer,
  description text,
  sharing_type text,
  meal_included text,
  room_type text,
  star_rating text,
  plot_area text,
  facing text,
  available_date date,
  images text[] DEFAULT '{}',
  status text DEFAULT 'active',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;

-- Users can view all properties (public listings)
CREATE POLICY "Anyone can view properties"
ON public.properties
FOR SELECT
USING (true);

-- Users can create their own properties
CREATE POLICY "Users can create their own properties"
ON public.properties
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can update their own properties
CREATE POLICY "Users can update their own properties"
ON public.properties
FOR UPDATE
USING (auth.uid() = user_id);

-- Users can delete their own properties
CREATE POLICY "Users can delete their own properties"
ON public.properties
FOR DELETE
USING (auth.uid() = user_id);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_properties_updated_at
BEFORE UPDATE ON public.properties
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();