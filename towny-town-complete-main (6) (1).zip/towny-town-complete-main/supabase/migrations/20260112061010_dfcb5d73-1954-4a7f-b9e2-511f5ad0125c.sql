-- Allow anyone to read active boosts for displaying boost badges on properties
CREATE POLICY "Anyone can view active boosts"
ON public.user_boosts FOR SELECT
USING (is_active = true AND expires_at > now());