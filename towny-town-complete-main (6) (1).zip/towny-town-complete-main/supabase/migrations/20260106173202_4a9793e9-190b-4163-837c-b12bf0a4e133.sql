-- Create a table to store AI chat conversations
CREATE TABLE public.ai_chat_conversations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id),
  messages JSONB NOT NULL DEFAULT '[]'::jsonb,
  requirement TEXT,
  budget TEXT,
  location TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.ai_chat_conversations ENABLE ROW LEVEL SECURITY;

-- Create policy for anyone to insert (anonymous users can chat)
CREATE POLICY "Anyone can create chat conversations" 
ON public.ai_chat_conversations 
FOR INSERT 
WITH CHECK (true);

-- Create policy for anyone to update their own session
CREATE POLICY "Anyone can update their session conversations" 
ON public.ai_chat_conversations 
FOR UPDATE 
USING (true);

-- Create policy for authenticated users to view their conversations
CREATE POLICY "Authenticated users can view all conversations" 
ON public.ai_chat_conversations 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_ai_chat_conversations_updated_at
BEFORE UPDATE ON public.ai_chat_conversations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();