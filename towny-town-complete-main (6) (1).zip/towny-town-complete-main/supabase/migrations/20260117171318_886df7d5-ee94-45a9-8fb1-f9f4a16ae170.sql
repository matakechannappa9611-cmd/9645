-- LAYER 1: Phone verification tracking
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone_verified boolean DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone_verified_at timestamptz;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_voip_number boolean DEFAULT false;

-- Unique phone constraint (1 account per phone)
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_unique_phone 
ON public.profiles(phone) WHERE phone IS NOT NULL AND phone != '';

-- LAYER 2: User trust levels enum and table
CREATE TYPE public.user_trust_level AS ENUM ('new', 'verified', 'trusted', 'broker_flagged');

CREATE TABLE public.user_trust (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  trust_level user_trust_level DEFAULT 'new',
  daily_post_limit integer DEFAULT 1,
  total_posts integer DEFAULT 0,
  total_reports_received integer DEFAULT 0,
  total_reports_made integer DEFAULT 0,
  is_suspended boolean DEFAULT false,
  suspended_until timestamptz,
  suspension_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.user_trust ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own trust" ON public.user_trust
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can view others trust for badges" ON public.user_trust
  FOR SELECT USING (true);

-- LAYER 3: Daily posting tracker
CREATE TABLE public.daily_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  post_date date DEFAULT CURRENT_DATE,
  post_count integer DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, post_date)
);

ALTER TABLE public.daily_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own daily posts" ON public.daily_posts
  FOR SELECT USING (auth.uid() = user_id);

-- LAYER 6: Community reporting
CREATE TYPE public.report_reason AS ENUM ('broker', 'fake_price', 'already_rented', 'spam', 'misleading_photos', 'wrong_location', 'other');

CREATE TABLE public.property_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid REFERENCES public.properties(id) ON DELETE CASCADE NOT NULL,
  reporter_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  reason report_reason NOT NULL,
  details text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(property_id, reporter_id) -- One report per user per property
);

ALTER TABLE public.property_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can create reports" ON public.property_reports
  FOR INSERT WITH CHECK (auth.uid() = reporter_id);

CREATE POLICY "Users can view own reports" ON public.property_reports
  FOR SELECT USING (auth.uid() = reporter_id);

-- Add report count and hidden status to properties
ALTER TABLE public.properties ADD COLUMN IF NOT EXISTS report_count integer DEFAULT 0;
ALTER TABLE public.properties ADD COLUMN IF NOT EXISTS is_hidden boolean DEFAULT false;
ALTER TABLE public.properties ADD COLUMN IF NOT EXISTS hidden_reason text;

-- LAYER 7: Verification badges
CREATE TABLE public.user_badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  badge_type text NOT NULL, -- 'phone_verified', 'owner_verified', 'trusted_user'
  verified_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  verification_data jsonb,
  UNIQUE(user_id, badge_type)
);

ALTER TABLE public.user_badges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view badges" ON public.user_badges
  FOR SELECT USING (true);

CREATE POLICY "System can manage badges" ON public.user_badges
  FOR ALL USING (auth.uid() = user_id);

-- LAYER 8: Device & IP tracking
CREATE TABLE public.device_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  device_fingerprint text,
  ip_address inet,
  user_agent text,
  action_type text, -- 'login', 'signup', 'post', 'report'
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.device_tracking ENABLE ROW LEVEL SECURITY;

-- Only system can read/write device tracking
CREATE POLICY "Users can insert own tracking" ON public.device_tracking
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Spam detection: similar phone ranges
CREATE TABLE public.phone_patterns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_prefix text NOT NULL, -- First 6 digits
  registration_count integer DEFAULT 1,
  flagged boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(phone_prefix)
);

ALTER TABLE public.phone_patterns ENABLE ROW LEVEL SECURITY;

-- Function to check and enforce posting limits
CREATE OR REPLACE FUNCTION public.can_post_property(user_id_param uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_trust_record user_trust%ROWTYPE;
  daily_count integer;
  result jsonb;
BEGIN
  -- Get or create user trust record
  SELECT * INTO user_trust_record FROM user_trust WHERE user_id = user_id_param;
  
  IF NOT FOUND THEN
    INSERT INTO user_trust (user_id, trust_level, daily_post_limit)
    VALUES (user_id_param, 'new', 1)
    RETURNING * INTO user_trust_record;
  END IF;
  
  -- Check if suspended
  IF user_trust_record.is_suspended AND (user_trust_record.suspended_until IS NULL OR user_trust_record.suspended_until > now()) THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'Account suspended: ' || COALESCE(user_trust_record.suspension_reason, 'Policy violation'));
  END IF;
  
  -- Get today's post count
  SELECT COALESCE(post_count, 0) INTO daily_count
  FROM daily_posts
  WHERE user_id = user_id_param AND post_date = CURRENT_DATE;
  
  IF daily_count >= user_trust_record.daily_post_limit THEN
    RETURN jsonb_build_object(
      'allowed', false, 
      'reason', 'Daily limit reached. You can post ' || user_trust_record.daily_post_limit || ' listing(s) per day.',
      'limit', user_trust_record.daily_post_limit,
      'used', daily_count
    );
  END IF;
  
  RETURN jsonb_build_object(
    'allowed', true, 
    'remaining', user_trust_record.daily_post_limit - daily_count,
    'limit', user_trust_record.daily_post_limit,
    'trust_level', user_trust_record.trust_level
  );
END;
$$;

-- Function to record a post
CREATE OR REPLACE FUNCTION public.record_property_post(user_id_param uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO daily_posts (user_id, post_date, post_count)
  VALUES (user_id_param, CURRENT_DATE, 1)
  ON CONFLICT (user_id, post_date)
  DO UPDATE SET post_count = daily_posts.post_count + 1;
  
  UPDATE user_trust
  SET total_posts = total_posts + 1, updated_at = now()
  WHERE user_id = user_id_param;
  
  RETURN true;
END;
$$;

-- Function to handle reports and auto-hide
CREATE OR REPLACE FUNCTION public.handle_property_report()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_count integer;
  property_owner uuid;
BEGIN
  -- Update report count on property
  UPDATE properties
  SET report_count = report_count + 1
  WHERE id = NEW.property_id
  RETURNING report_count, user_id INTO current_count, property_owner;
  
  -- Auto-hide if 3+ reports
  IF current_count >= 3 THEN
    UPDATE properties
    SET is_hidden = true, hidden_reason = 'Auto-hidden due to community reports'
    WHERE id = NEW.property_id;
    
    -- Update owner's trust record
    UPDATE user_trust
    SET total_reports_received = total_reports_received + 1
    WHERE user_id = property_owner;
  END IF;
  
  -- Update reporter's report count
  UPDATE user_trust
  SET total_reports_made = total_reports_made + 1
  WHERE user_id = NEW.reporter_id;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_property_report
  AFTER INSERT ON property_reports
  FOR EACH ROW
  EXECUTE FUNCTION handle_property_report();

-- Function to upgrade user trust level
CREATE OR REPLACE FUNCTION public.upgrade_trust_level(user_id_param uuid)
RETURNS user_trust_level
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_trust user_trust%ROWTYPE;
  phone_verified boolean;
  has_badges integer;
  new_level user_trust_level;
BEGIN
  SELECT * INTO current_trust FROM user_trust WHERE user_id = user_id_param;
  SELECT phone_verified INTO phone_verified FROM profiles WHERE user_id = user_id_param;
  SELECT COUNT(*) INTO has_badges FROM user_badges WHERE user_id = user_id_param;
  
  -- Determine new level
  IF current_trust.total_reports_received >= 5 THEN
    new_level := 'broker_flagged';
  ELSIF has_badges >= 2 AND current_trust.total_posts >= 3 AND current_trust.total_reports_received = 0 THEN
    new_level := 'trusted';
  ELSIF phone_verified THEN
    new_level := 'verified';
  ELSE
    new_level := 'new';
  END IF;
  
  -- Update limits based on level
  UPDATE user_trust
  SET 
    trust_level = new_level,
    daily_post_limit = CASE new_level
      WHEN 'new' THEN 1
      WHEN 'verified' THEN 3
      WHEN 'trusted' THEN 5
      WHEN 'broker_flagged' THEN 0
    END,
    updated_at = now()
  WHERE user_id = user_id_param;
  
  RETURN new_level;
END;
$$;

-- Function to grant phone verified badge
CREATE OR REPLACE FUNCTION public.grant_phone_verified_badge(user_id_param uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO user_badges (user_id, badge_type)
  VALUES (user_id_param, 'phone_verified')
  ON CONFLICT (user_id, badge_type) DO NOTHING;
  
  UPDATE profiles
  SET phone_verified = true, phone_verified_at = now()
  WHERE user_id = user_id_param;
  
  -- Upgrade trust level
  PERFORM upgrade_trust_level(user_id_param);
  
  RETURN true;
END;
$$;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_device_tracking_user ON device_tracking(user_id);
CREATE INDEX IF NOT EXISTS idx_device_tracking_ip ON device_tracking(ip_address);
CREATE INDEX IF NOT EXISTS idx_device_tracking_fingerprint ON device_tracking(device_fingerprint);
CREATE INDEX IF NOT EXISTS idx_property_reports_property ON property_reports(property_id);
CREATE INDEX IF NOT EXISTS idx_properties_hidden ON properties(is_hidden) WHERE is_hidden = false;
CREATE INDEX IF NOT EXISTS idx_daily_posts_date ON daily_posts(post_date);