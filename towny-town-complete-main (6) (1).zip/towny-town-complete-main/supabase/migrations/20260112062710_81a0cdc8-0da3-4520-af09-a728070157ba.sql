-- Create user_coins table for Towny coin system
CREATE TABLE public.user_coins (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  balance INTEGER NOT NULL DEFAULT 0,
  total_earned INTEGER NOT NULL DEFAULT 0,
  total_withdrawn INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT unique_user_coins UNIQUE (user_id)
);

-- Enable RLS on user_coins
ALTER TABLE public.user_coins ENABLE ROW LEVEL SECURITY;

-- Users can view their own coins
CREATE POLICY "Users can view their own coins"
ON public.user_coins FOR SELECT
USING (auth.uid() = user_id);

-- System can insert coins (via function)
CREATE POLICY "System can insert coins"
ON public.user_coins FOR INSERT
WITH CHECK (true);

-- System can update coins (via function)
CREATE POLICY "System can update coins"
ON public.user_coins FOR UPDATE
USING (true);

-- Create coin_transactions table for history
CREATE TABLE public.coin_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  amount INTEGER NOT NULL,
  transaction_type TEXT NOT NULL, -- 'earn', 'withdraw', 'spend'
  source TEXT NOT NULL, -- 'referral', 'withdrawal', 'towny_plus'
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on coin_transactions
ALTER TABLE public.coin_transactions ENABLE ROW LEVEL SECURITY;

-- Users can view their own transactions
CREATE POLICY "Users can view their own transactions"
ON public.coin_transactions FOR SELECT
USING (auth.uid() = user_id);

-- System can insert transactions
CREATE POLICY "System can insert transactions"
ON public.coin_transactions FOR INSERT
WITH CHECK (true);

-- Create withdrawal_requests table
CREATE TABLE public.withdrawal_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  amount INTEGER NOT NULL,
  upi_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'approved', 'rejected', 'completed'
  processed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on withdrawal_requests
ALTER TABLE public.withdrawal_requests ENABLE ROW LEVEL SECURITY;

-- Users can view their own withdrawal requests
CREATE POLICY "Users can view their own withdrawals"
ON public.withdrawal_requests FOR SELECT
USING (auth.uid() = user_id);

-- Users can create withdrawal requests
CREATE POLICY "Users can create withdrawal requests"
ON public.withdrawal_requests FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Update trigger for user_coins
CREATE TRIGGER update_user_coins_updated_at
BEFORE UPDATE ON public.user_coins
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Function to award coins on referral
CREATE OR REPLACE FUNCTION public.award_referral_coins(referrer_user_id UUID, coins_amount INTEGER DEFAULT 10)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Insert or update user coins
  INSERT INTO user_coins (user_id, balance, total_earned)
  VALUES (referrer_user_id, coins_amount, coins_amount)
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    balance = user_coins.balance + coins_amount,
    total_earned = user_coins.total_earned + coins_amount,
    updated_at = now();
  
  -- Record transaction
  INSERT INTO coin_transactions (user_id, amount, transaction_type, source, description)
  VALUES (referrer_user_id, coins_amount, 'earn', 'referral', 'Earned from successful referral');
  
  RETURN TRUE;
END;
$$;

-- Function to request withdrawal (min 100 coins)
CREATE OR REPLACE FUNCTION public.request_coin_withdrawal(user_id_param UUID, amount_param INTEGER, upi_id_param TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_balance INTEGER;
BEGIN
  -- Check minimum withdrawal amount
  IF amount_param < 100 THEN
    RETURN FALSE;
  END IF;
  
  -- Get current balance
  SELECT balance INTO current_balance
  FROM user_coins
  WHERE user_id = user_id_param;
  
  IF current_balance IS NULL OR current_balance < amount_param THEN
    RETURN FALSE;
  END IF;
  
  -- Deduct coins
  UPDATE user_coins
  SET balance = balance - amount_param,
      total_withdrawn = total_withdrawn + amount_param,
      updated_at = now()
  WHERE user_id = user_id_param;
  
  -- Create withdrawal request
  INSERT INTO withdrawal_requests (user_id, amount, upi_id, status)
  VALUES (user_id_param, amount_param, upi_id_param, 'pending');
  
  -- Record transaction
  INSERT INTO coin_transactions (user_id, amount, transaction_type, source, description)
  VALUES (user_id_param, -amount_param, 'withdraw', 'withdrawal', 'Withdrawal request of ' || amount_param || ' coins');
  
  RETURN TRUE;
END;
$$;

-- Update process_referral to also award coins
CREATE OR REPLACE FUNCTION public.process_referral(referral_code_param text, new_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_user_id UUID;
  monthly_count INTEGER;
BEGIN
  -- Get referrer from code
  SELECT user_id INTO referrer_user_id
  FROM referral_codes
  WHERE code = referral_code_param;
  
  IF referrer_user_id IS NULL THEN
    RETURN FALSE;
  END IF;
  
  -- Prevent self-referral
  IF referrer_user_id = new_user_id THEN
    RETURN FALSE;
  END IF;
  
  -- Check monthly limit (max 3 per month for boost)
  SELECT COUNT(*) INTO monthly_count
  FROM user_boosts
  WHERE user_id = referrer_user_id
    AND source = 'referral'
    AND created_at >= date_trunc('month', CURRENT_TIMESTAMP);
  
  IF monthly_count >= 3 THEN
    -- Still award coins but no boost
    PERFORM award_referral_coins(referrer_user_id, 10);
    
    -- Record the referral
    INSERT INTO referrals (referrer_id, referred_user_id, referral_code, status, completed_at)
    VALUES (referrer_user_id, new_user_id, referral_code_param, 'completed', now());
    
    -- Update referral stats
    UPDATE referral_codes
    SET total_referrals = total_referrals + 1,
        successful_referrals = successful_referrals + 1
    WHERE user_id = referrer_user_id;
    
    RETURN TRUE;
  END IF;
  
  -- Record the referral
  INSERT INTO referrals (referrer_id, referred_user_id, referral_code, status, completed_at)
  VALUES (referrer_user_id, new_user_id, referral_code_param, 'completed', now());
  
  -- Grant 1-day boost to referrer (Towny Plus)
  INSERT INTO user_boosts (user_id, boost_type, source, expires_at)
  VALUES (referrer_user_id, 'towny_plus', 'referral', now() + INTERVAL '24 hours');
  
  -- Award 10 Towny coins
  PERFORM award_referral_coins(referrer_user_id, 10);
  
  -- Update referral stats
  UPDATE referral_codes
  SET total_referrals = total_referrals + 1,
      successful_referrals = successful_referrals + 1
  WHERE user_id = referrer_user_id;
  
  RETURN TRUE;
END;
$$;