-- Create table for chat leads/inquiries
CREATE TABLE public.chat_leads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  requirement TEXT NOT NULL,
  budget TEXT NOT NULL,
  location TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.chat_leads ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert (public form submission)
CREATE POLICY "Anyone can submit leads"
ON public.chat_leads
FOR INSERT
WITH CHECK (true);

-- Only authenticated users can view leads (for admin)
CREATE POLICY "Authenticated users can view leads"
ON public.chat_leads
FOR SELECT
USING (auth.uid() IS NOT NULL);