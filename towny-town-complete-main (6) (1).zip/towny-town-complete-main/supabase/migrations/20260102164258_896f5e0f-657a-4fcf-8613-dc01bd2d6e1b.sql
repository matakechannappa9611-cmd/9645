-- Create email subscribers table
CREATE TABLE public.email_subscribers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  subscribed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Enable Row Level Security
ALTER TABLE public.email_subscribers ENABLE ROW LEVEL SECURITY;

-- Allow anyone to subscribe (insert)
CREATE POLICY "Anyone can subscribe"
ON public.email_subscribers
FOR INSERT
WITH CHECK (true);

-- Only authenticated users (admin) can view subscribers
CREATE POLICY "Authenticated users can view subscribers"
ON public.email_subscribers
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Add index for faster email lookups
CREATE INDEX idx_email_subscribers_email ON public.email_subscribers(email);