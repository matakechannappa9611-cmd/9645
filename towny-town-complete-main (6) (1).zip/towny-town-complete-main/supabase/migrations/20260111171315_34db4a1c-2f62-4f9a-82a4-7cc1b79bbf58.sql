-- Create referrals table to track referral relationships
CREATE TABLE public.referrals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_id UUID NOT NULL,
  referred_user_id UUID,
  referral_code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Create user_boosts table to track boost rewards
CREATE TABLE public.user_boosts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  boost_type TEXT NOT NULL DEFAULT 'free_boost',
  source TEXT NOT NULL DEFAULT 'referral',
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Create referral_stats view helper table
CREATE TABLE public.referral_codes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  code TEXT NOT NULL UNIQUE,
  total_referrals INTEGER NOT NULL DEFAULT 0,
  successful_referrals INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_boosts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_codes ENABLE ROW LEVEL SECURITY;

-- RLS policies for referrals
CREATE POLICY "Users can view their own referrals"
ON public.referrals FOR SELECT
USING (auth.uid() = referrer_id OR auth.uid() = referred_user_id);

CREATE POLICY "Users can create referrals"
ON public.referrals FOR INSERT
WITH CHECK (auth.uid() = referrer_id);

-- RLS policies for user_boosts
CREATE POLICY "Users can view their own boosts"
ON public.user_boosts FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "System can insert boosts"
ON public.user_boosts FOR INSERT
WITH CHECK (true);

-- RLS policies for referral_codes
CREATE POLICY "Users can view their own referral code"
ON public.referral_codes FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view referral codes for validation"
ON public.referral_codes FOR SELECT
USING (true);

CREATE POLICY "Users can create their referral code"
ON public.referral_codes FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their referral stats"
ON public.referral_codes FOR UPDATE
USING (auth.uid() = user_id);

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code(user_id_param UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_code TEXT;
  code_exists BOOLEAN;
BEGIN
  LOOP
    new_code := 'TOWNY' || UPPER(SUBSTRING(MD5(RANDOM()::TEXT) FROM 1 FOR 6));
    SELECT EXISTS(SELECT 1 FROM referral_codes WHERE code = new_code) INTO code_exists;
    EXIT WHEN NOT code_exists;
  END LOOP;
  
  INSERT INTO referral_codes (user_id, code)
  VALUES (user_id_param, new_code)
  ON CONFLICT (user_id) DO NOTHING;
  
  RETURN new_code;
END;
$$;

-- Function to process referral signup
CREATE OR REPLACE FUNCTION public.process_referral(
  referral_code_param TEXT,
  new_user_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_user_id UUID;
  monthly_count INTEGER;
BEGIN
  -- Get referrer from code
  SELECT user_id INTO referrer_user_id
  FROM referral_codes
  WHERE code = referral_code_param;
  
  IF referrer_user_id IS NULL THEN
    RETURN FALSE;
  END IF;
  
  -- Prevent self-referral
  IF referrer_user_id = new_user_id THEN
    RETURN FALSE;
  END IF;
  
  -- Check monthly limit (max 3 per month)
  SELECT COUNT(*) INTO monthly_count
  FROM user_boosts
  WHERE user_id = referrer_user_id
    AND source = 'referral'
    AND created_at >= date_trunc('month', CURRENT_TIMESTAMP);
  
  IF monthly_count >= 3 THEN
    RETURN FALSE;
  END IF;
  
  -- Record the referral
  INSERT INTO referrals (referrer_id, referred_user_id, referral_code, status, completed_at)
  VALUES (referrer_user_id, new_user_id, referral_code_param, 'completed', now());
  
  -- Grant 1-day boost to referrer
  INSERT INTO user_boosts (user_id, boost_type, source, expires_at)
  VALUES (referrer_user_id, 'free_boost', 'referral', now() + INTERVAL '24 hours');
  
  -- Update referral stats
  UPDATE referral_codes
  SET total_referrals = total_referrals + 1,
      successful_referrals = successful_referrals + 1
  WHERE user_id = referrer_user_id;
  
  RETURN TRUE;
END;
$$;

-- Function to check if user has active boost
CREATE OR REPLACE FUNCTION public.has_active_boost(user_id_param UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS(
    SELECT 1 FROM user_boosts
    WHERE user_id = user_id_param
      AND is_active = true
      AND expires_at > now()
  );
END;
$$;