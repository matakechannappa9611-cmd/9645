-- Create table for storing OTPs
CREATE TABLE public.otp_codes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  phone TEXT,
  code TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'email',
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.otp_codes ENABLE ROW LEVEL SECURITY;

-- Allow anonymous inserts (for OTP generation)
CREATE POLICY "Allow anonymous insert" ON public.otp_codes
FOR INSERT TO anon WITH CHECK (true);

-- Allow anonymous select for verification
CREATE POLICY "Allow anonymous select" ON public.otp_codes
FOR SELECT TO anon USING (true);

-- Allow anonymous update for marking as verified
CREATE POLICY "Allow anonymous update" ON public.otp_codes
FOR UPDATE TO anon USING (true);

-- Create index for faster lookups
CREATE INDEX idx_otp_codes_email ON public.otp_codes(email);
CREATE INDEX idx_otp_codes_phone ON public.otp_codes(phone);

-- Auto-delete expired OTPs (cleanup function)
CREATE OR REPLACE FUNCTION public.cleanup_expired_otps()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.otp_codes WHERE expires_at < now();
END;
$$;