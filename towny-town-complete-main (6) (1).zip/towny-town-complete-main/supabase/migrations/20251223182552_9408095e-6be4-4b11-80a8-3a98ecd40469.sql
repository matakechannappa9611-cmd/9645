-- Add tenant_type column to properties table
ALTER TABLE public.properties 
ADD COLUMN tenant_type text DEFAULT 'anyone';

-- Add comment for clarity
COMMENT ON COLUMN public.properties.tenant_type IS 'Allowed tenant type: bachelors, family, or anyone';