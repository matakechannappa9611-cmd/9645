import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { location, city, coordinates } = await req.json();
    
    if (!location || !city) {
      return new Response(
        JSON.stringify({ error: "Location and city are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const prompt = `You are an expert on Indian localities and neighborhoods. For the location "${location}" in "${city}", India${coordinates ? ` (coordinates: ${coordinates.lat}, ${coordinates.lng})` : ''}, provide detailed information about nearby amenities and places.

Return a JSON object with the following structure:
{
  "hospitals": [{"name": "Hospital Name", "distance": "1.2 km", "type": "Multi-specialty/Government/Private"}],
  "clinics": [{"name": "Clinic Name", "distance": "0.5 km", "type": "General/Dental/Eye"}],
  "gyms": [{"name": "Gym Name", "distance": "0.8 km", "type": "Premium/Budget"}],
  "restaurants": [{"name": "Restaurant Name", "distance": "0.3 km", "cuisine": "North Indian/South Indian/Chinese"}],
  "cafes": [{"name": "Cafe Name", "distance": "0.4 km"}],
  "parks": [{"name": "Park Name", "distance": "0.6 km", "type": "Public/Lake/Garden"}],
  "shopping": [{"name": "Mall/Market Name", "distance": "1.0 km", "type": "Mall/Market/Supermarket"}],
  "grocery": [{"name": "Store Name", "distance": "0.2 km", "type": "Supermarket/Kirana"}],
  "schools": [{"name": "School Name", "distance": "1.5 km", "type": "CBSE/ICSE/State Board"}],
  "metro": [{"name": "Metro Station", "distance": "2.0 km", "line": "Purple/Green Line"}],
  "bus_stops": [{"name": "Bus Stop Name", "distance": "0.3 km"}],
  "atms": [{"name": "Bank ATM", "distance": "0.2 km"}],
  "pharmacies": [{"name": "Pharmacy Name", "distance": "0.3 km"}],
  "summary": "Brief 2-3 sentence summary about the neighborhood"
}

Provide 2-4 entries per category with realistic names and distances for this specific area. If the location is well-known (like Bellandur in Bangalore), use actual landmark names. Focus on the most popular and relevant places.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: "You are a helpful assistant that provides accurate information about Indian localities. Always respond with valid JSON only, no additional text." },
          { role: "user", content: prompt }
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Payment required. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error("Failed to get amenities data");
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";
    
    // Parse JSON from the response
    let amenities;
    try {
      // Try to extract JSON from the response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        amenities = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in response");
      }
    } catch (parseError) {
      console.error("JSON parse error:", parseError, "Content:", content);
      // Return a fallback structure
      amenities = {
        summary: "Amenity information is being fetched. Please try again.",
        hospitals: [],
        clinics: [],
        gyms: [],
        restaurants: [],
        cafes: [],
        parks: [],
        shopping: [],
        grocery: [],
        schools: [],
        metro: [],
        bus_stops: [],
        atms: [],
        pharmacies: []
      };
    }

    return new Response(
      JSON.stringify(amenities),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error fetching amenities:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
