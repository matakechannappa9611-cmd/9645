import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email } = await req.json();

    if (!email) {
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Set expiry to 5 minutes from now
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Delete any existing OTPs for this email
    await supabase.from("otp_codes").delete().eq("email", email);

    // Store OTP in database
    const { error: insertError } = await supabase.from("otp_codes").insert({
      email,
      code: otp,
      type: "email",
      expires_at: expiresAt,
    });

    if (insertError) {
      console.error("Failed to store OTP:", insertError);
      return new Response(
        JSON.stringify({ error: "Failed to generate OTP" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get Resend API key
    const resendApiKey = Deno.env.get("RESEND_API_KEY");

    if (!resendApiKey) {
      console.error("RESEND_API_KEY not configured");
      return new Response(
        JSON.stringify({ error: "Email service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const resend = new Resend(resendApiKey);

    console.log("Attempting to send OTP email to:", email);

    // Send email
    const { data: emailData, error: emailError } = await resend.emails.send({
      from: "Towny <onboarding@resend.dev>",
      to: [email],
      subject: "Your Towny Verification Code",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #4a7c59; margin: 0;">Towny</h1>
            <p style="color: #666; margin-top: 5px;">Your trusted property platform</p>
          </div>
          
          <div style="background: linear-gradient(135deg, #4a7c59, #6b9b6b); padding: 30px; border-radius: 12px; text-align: center; margin-bottom: 20px;">
            <p style="color: white; margin: 0 0 10px 0; font-size: 16px;">Your verification code is:</p>
            <h2 style="color: white; font-size: 36px; letter-spacing: 8px; margin: 0; font-family: monospace;">${otp}</h2>
          </div>
          
          <p style="color: #666; text-align: center; font-size: 14px;">
            This code expires in 5 minutes.<br/>
            If you didn't request this code, please ignore this email.
          </p>
          
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;" />
          
          <p style="color: #999; text-align: center; font-size: 12px;">
            © ${new Date().getFullYear()} Towny. All rights reserved.
          </p>
        </div>
      `,
    });

    if (emailError) {
      console.error("Resend email error:", JSON.stringify(emailError));
      return new Response(
        JSON.stringify({ error: `Failed to send email: ${emailError.message || 'Unknown error'}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Email sent successfully. Response:", JSON.stringify(emailData));

    console.log("OTP sent successfully to:", email);

    return new Response(
      JSON.stringify({ success: true, message: "OTP sent successfully" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    console.error("Error sending OTP:", error);
    const errorMessage = error instanceof Error ? error.message : "Failed to send OTP";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
