import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import About from "./pages/About";
import Tech from "./pages/Tech";
import Careers from "./pages/Careers";
import Help from "./pages/Help";
import PropertyDetails from "./pages/PropertyDetails";
import Messages from "./pages/Messages";
import Notifications from "./pages/Notifications";
import Saved from "./pages/Saved";
import Profile from "./pages/Profile";
import MyAds from "./pages/MyAds";
import AdminDashboard from "./pages/AdminDashboard";
import NotFound from "./pages/NotFound";
import NeedRoommate from "./pages/NeedRoommate";
import Referrals from "./pages/Referrals";
import Coins from "./pages/Coins";
import TownyAI from "./components/TownyAI";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/about" element={<About />} />
            <Route path="/tech" element={<Tech />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/help" element={<Help />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/property/:id" element={<PropertyDetails />} />
            <Route path="/messages" element={<Messages />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/saved" element={<Saved />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/my-ads" element={<MyAds />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/need-roommate" element={<NeedRoommate />} />
            <Route path="/referrals" element={<Referrals />} />
            <Route path="/coins" element={<Coins />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
          <TownyAI />
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
