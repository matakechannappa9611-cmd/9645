import { Home, MessageSquare, PlusCircle, Heart, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import PostPropertyForm from './PostPropertyForm';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface MobileNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const MobileNav = ({ activeTab, onTabChange }: MobileNavProps) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [showPostForm, setShowPostForm] = useState(false);
  
  const navItems = [
    { id: 'home', label: 'Home', icon: Home, path: '/' },
    { id: 'messaging', label: 'Messages', icon: MessageSquare, path: '/messages' },
    { id: 'post', label: 'Post', icon: PlusCircle, path: null },
    { id: 'saved', label: 'Saved', icon: Heart, path: '/saved' },
    { id: 'roommate', label: 'Roommate', icon: Users, path: '/need-roommate' },
  ];

  const handleNavClick = (item: typeof navItems[0]) => {
    if (item.id === 'post') {
      if (!user) {
        toast({
          title: "Login Required",
          description: "Please login to post a property",
          variant: "destructive"
        });
        navigate('/auth');
        return;
      }
      setShowPostForm(true);
      return;
    }
    onTabChange(item.id);
    if (item.path) {
      navigate(item.path);
    }
  };

  return (
    <>
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border md:hidden">
        <div className="flex items-center justify-around py-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item)}
              className={`flex flex-col items-center gap-1 py-2 px-4 ${
                activeTab === item.id ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
      
      <PostPropertyForm 
        isOpen={showPostForm} 
        onClose={() => setShowPostForm(false)} 
      />
    </>
  );
};

export default MobileNav;
