import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Loader2, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

type Message = {
  role: 'user' | 'assistant';
  content: string;
};

type LeadData = {
  requirement: string;
  budget: string;
  location: string;
};

const QUESTIONS = [
  "Hi! I'm Towny Bot 🏠 What type of property are you looking for? (e.g., 2BHK apartment, PG, commercial space)",
  "Great! What's your budget range? (e.g., ₹10,000-15,000/month or ₹50-80 lakhs)",
  "Perfect! Which location/area are you interested in?",
];

const TownyBot = () => {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: QUESTIONS[0] }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [leadData, setLeadData] = useState<LeadData>({ requirement: '', budget: '', location: '' });
  const [isCompleted, setIsCompleted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const saveLead = async (data: LeadData) => {
    try {
      const { error } = await supabase
        .from('chat_leads')
        .insert({
          requirement: data.requirement,
          budget: data.budget,
          location: data.location,
        });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error saving lead:', error);
      return false;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading || isCompleted) return;
    
    const userMessage = input.trim();
    setInput('');
    
    // Add user message
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    
    // Update lead data based on current step
    const updatedLeadData = { ...leadData };
    if (currentStep === 0) {
      updatedLeadData.requirement = userMessage;
    } else if (currentStep === 1) {
      updatedLeadData.budget = userMessage;
    } else if (currentStep === 2) {
      updatedLeadData.location = userMessage;
    }
    setLeadData(updatedLeadData);

    const nextStep = currentStep + 1;

    if (nextStep < QUESTIONS.length) {
      // Ask next question
      setTimeout(() => {
        setMessages(prev => [...prev, { role: 'assistant', content: QUESTIONS[nextStep] }]);
        setCurrentStep(nextStep);
      }, 500);
    } else {
      // All questions answered - save and close
      setIsLoading(true);
      const saved = await saveLead(updatedLeadData);
      setIsLoading(false);

      if (saved) {
        setMessages(prev => [...prev, { 
          role: 'assistant', 
          content: "Thank you! 🎉 We've received your requirements. Our team will contact you shortly with the best property options. Have a great day!" 
        }]);
        setIsCompleted(true);
        
        toast({
          title: 'Inquiry submitted!',
          description: 'We will get back to you soon.',
        });

        // Auto close after 3 seconds
        setTimeout(() => {
          setIsOpen(false);
          // Reset for next time
          setTimeout(() => {
            setMessages([{ role: 'assistant', content: QUESTIONS[0] }]);
            setCurrentStep(0);
            setLeadData({ requirement: '', budget: '', location: '' });
            setIsCompleted(false);
          }, 500);
        }, 3000);
      } else {
        toast({
          title: 'Error',
          description: 'Failed to submit inquiry. Please try again.',
          variant: 'destructive',
        });
      }
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-20 md:bottom-6 right-4 z-50 w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-lg hover:shadow-xl transition-all flex items-center justify-center ${isOpen ? 'hidden' : ''}`}
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-20 md:bottom-6 right-4 z-50 w-[350px] h-[450px] bg-card border border-border rounded-2xl shadow-2xl flex flex-col overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-primary text-primary-foreground">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5" />
              <span className="font-semibold">Towny Bot</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:opacity-80">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Progress indicator */}
          <div className="px-4 py-2 bg-muted/50 border-b border-border">
            <div className="flex gap-2">
              {[0, 1, 2].map((step) => (
                <div
                  key={step}
                  className={`h-1.5 flex-1 rounded-full transition-colors ${
                    step < currentStep ? 'bg-primary' : 
                    step === currentStep ? 'bg-primary/50' : 'bg-muted-foreground/20'
                  }`}
                />
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Step {Math.min(currentStep + 1, 3)} of 3
            </p>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            <div className="space-y-4">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.role === 'assistant' && (
                    <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      {isCompleted && i === messages.length - 1 ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <Bot className="w-4 h-4 text-primary" />
                      )}
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm ${
                      msg.role === 'user'
                        ? 'bg-primary text-primary-foreground rounded-br-md'
                        : 'bg-muted text-foreground rounded-bl-md'
                    }`}
                  >
                    {msg.content}
                  </div>
                  {msg.role === 'user' && (
                    <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                      <User className="w-4 h-4 text-primary-foreground" />
                    </div>
                  )}
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-2 justify-start">
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Loader2 className="w-4 h-4 text-primary animate-spin" />
                  </div>
                  <div className="bg-muted text-foreground rounded-2xl rounded-bl-md px-3 py-2 text-sm">
                    Saving your inquiry...
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Input */}
          <form onSubmit={handleSubmit} className="p-3 border-t border-border">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={isCompleted ? "Chat completed" : "Type your answer..."}
                className="flex-1 rounded-full"
                disabled={isLoading || isCompleted}
              />
              <Button
                type="submit"
                size="icon"
                className="rounded-full"
                disabled={isLoading || !input.trim() || isCompleted}
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </form>
        </div>
      )}
    </>
  );
};

export default TownyBot;
