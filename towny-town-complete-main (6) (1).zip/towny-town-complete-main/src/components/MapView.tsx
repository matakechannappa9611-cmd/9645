import { useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { Property } from "@/types/property";
import homePinImage from "@/assets/home-pin.png";
import MapDistanceOverlay from "./MapDistanceOverlay";

interface MapViewProps {
  properties: Property[];
  propertyCount: number;
  userLocation?: { lat: number; lng: number } | null;
  showNearMe?: boolean;
  onBadgeClick?: () => void;
}

const formatPrice = (price: number) => {
  if (price >= 10000000) {
    return `₹${(price / 10000000).toFixed(1)} Cr`;
  } else if (price >= 100000) {
    return `₹${(price / 100000).toFixed(1)} L`;
  }
  return `₹${price.toLocaleString("en-IN")}`;
};

// 🇮🇳 India map bounds
const INDIA_BOUNDS: maplibregl.LngLatBoundsLike = [
  [68.1, 6.5], // Southwest
  [97.4, 35.7], // Northeast
];

const MapView = ({ properties, propertyCount, userLocation, showNearMe, onBadgeClick }: MapViewProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<maplibregl.Marker[]>([]);
  const userMarkerRef = useRef<maplibregl.Marker | null>(null);
  const officeMarkerRef = useRef<maplibregl.Marker | null>(null);
  const routeLineRef = useRef<string | null>(null);
  const [officeLocation, setOfficeLocation] = useState<{ lat: number; lng: number; name: string } | null>(null);

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || mapRef.current) return;

    mapRef.current = new maplibregl.Map({
      container: mapContainer.current,
      style: "https://tiles.openfreemap.org/styles/liberty",
      center: [77.5946, 12.9716], // Bangalore
      zoom: 14,
      pitch: 0,
      bearing: 0,
      maxBounds: INDIA_BOUNDS,
    });

    // Prevent world duplication
    mapRef.current.setRenderWorldCopies(false);

    // Zoom-only navigation control
    mapRef.current.addControl(
      new maplibregl.NavigationControl({
        showCompass: false,
        showZoom: true,
      }),
      "top-right",
    );

    // Geolocate control
    mapRef.current.addControl(
      new maplibregl.GeolocateControl({
        positionOptions: { enableHighAccuracy: true },
        trackUserLocation: true,
      }),
      "top-right",
    );

    return () => {
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  // Handle user location
  useEffect(() => {
    if (!mapRef.current) return;

    userMarkerRef.current?.remove();
    userMarkerRef.current = null;

    if (userLocation && showNearMe) {
      const el = document.createElement("div");
      el.innerHTML = `
        <div style="
          background: hsl(217, 91%, 60%);
          width: 20px;
          height: 20px;
          border-radius: 50%;
          border: 3px solid white;
          box-shadow: 0 0 0 8px rgba(59,130,246,0.3);
          animation: pulse 2s infinite;
        "></div>
      `;

      userMarkerRef.current = new maplibregl.Marker({ element: el })
        .setLngLat([userLocation.lng, userLocation.lat])
        .setPopup(
          new maplibregl.Popup({ offset: 25 }).setHTML(
            `<div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:600;">Your Location</div>`,
          ),
        )
        .addTo(mapRef.current);

      mapRef.current.flyTo({
        center: [userLocation.lng, userLocation.lat],
        zoom: 14,
        duration: 1200,
      });
    }
  }, [userLocation, showNearMe]);

  // Handle office location marker and route line
  useEffect(() => {
    if (!mapRef.current) return;

    // Remove existing office marker
    officeMarkerRef.current?.remove();
    officeMarkerRef.current = null;

    // Remove existing route line
    if (routeLineRef.current && mapRef.current.getSource(routeLineRef.current)) {
      mapRef.current.removeLayer(routeLineRef.current);
      mapRef.current.removeSource(routeLineRef.current);
      routeLineRef.current = null;
    }

    if (officeLocation && userLocation) {
      // Add office marker
      const el = document.createElement("div");
      el.innerHTML = `
        <div style="
          background: hsl(150, 40%, 40%);
          width: 24px;
          height: 24px;
          border-radius: 50%;
          border: 3px solid white;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="white" stroke="white" stroke-width="2">
            <rect x="4" y="2" width="16" height="20" rx="2" ry="2"/>
            <path d="M9 22v-4h6v4"/>
            <path d="M8 6h.01M16 6h.01M12 6h.01M8 10h.01M16 10h.01M12 10h.01M8 14h.01M16 14h.01M12 14h.01"/>
          </svg>
        </div>
      `;

      officeMarkerRef.current = new maplibregl.Marker({ element: el })
        .setLngLat([officeLocation.lng, officeLocation.lat])
        .setPopup(
          new maplibregl.Popup({ offset: 25 }).setHTML(
            `<div style="font-family:'Plus Jakarta Sans',sans-serif;">
              <div style="font-weight:600;">Office</div>
              <div style="font-size:12px;color:#666;">${officeLocation.name}</div>
            </div>`
          )
        )
        .addTo(mapRef.current);

      // Add route line
      const routeId = `route-${Date.now()}`;
      routeLineRef.current = routeId;

      mapRef.current.addSource(routeId, {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: {
            type: "LineString",
            coordinates: [
              [userLocation.lng, userLocation.lat],
              [officeLocation.lng, officeLocation.lat],
            ],
          },
        },
      });

      mapRef.current.addLayer({
        id: routeId,
        type: "line",
        source: routeId,
        layout: {
          "line-join": "round",
          "line-cap": "round",
        },
        paint: {
          "line-color": "hsl(217, 91%, 60%)",
          "line-width": 3,
          "line-dasharray": [2, 2],
        },
      });

      // Fit bounds to show both markers
      const bounds = new maplibregl.LngLatBounds();
      bounds.extend([userLocation.lng, userLocation.lat]);
      bounds.extend([officeLocation.lng, officeLocation.lat]);
      
      mapRef.current.fitBounds(bounds, {
        padding: 80,
        maxZoom: 14,
        duration: 1000,
      });
    }
  }, [officeLocation, userLocation]);

  const handleOfficeLocationChange = (location: { lat: number; lng: number; name: string } | null) => {
    setOfficeLocation(location);
  };

  useEffect(() => {
    if (!mapRef.current) return;

    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    const propertiesWithCoords = properties.filter((p) => p.coordinates);

    propertiesWithCoords.forEach((property) => {
      if (!property.coordinates) return;

      const el = document.createElement("div");
      el.innerHTML = `
        <div class="property-marker" style="
          width: 44px;
          height: 44px;
          border-radius: 50%;
          border: 3px solid white;
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
          overflow: hidden;
          cursor: pointer;
          transition: transform 0.2s;
          background: white;
          animation: markerPulse 2s ease-in-out infinite;
        ">
          <img src="${homePinImage}" alt="Property" style="
            width: 100%;
            height: 100%;
            object-fit: cover;
          " />
        </div>
      `;

      el.addEventListener("mouseenter", () => {
        const container = el.querySelector("div");
        if (container) container.style.transform = "scale(1.2)";
      });

      el.addEventListener("mouseleave", () => {
        const container = el.querySelector("div");
        if (container) container.style.transform = "scale(1)";
      });

      const popupContent = `
        <div style="min-width:220px;font-family:'Plus Jakarta Sans',sans-serif;">
          <img src="${property.image}" style="width:100%;height:100px;object-fit:cover;border-radius:8px;margin-bottom:8px;" />
          <div style="font-weight:600;font-size:14px;">${property.title}</div>
          <div style="font-size:12px;color:#666;">
            ${property.location}, ${property.city}
          </div>
          <div style="font-weight:700;font-size:16px;color:hsl(150,40%,30%);margin-top:4px;">
            ${formatPrice(property.price)}${property.priceUnit === "mo" ? "/mo" : ""}
          </div>
        </div>
      `;

      const marker = new maplibregl.Marker({ element: el })
        .setLngLat([property.coordinates.lng, property.coordinates.lat])
        .setPopup(new maplibregl.Popup({ offset: 25, maxWidth: "280px" }).setHTML(popupContent))
        .addTo(mapRef.current);

      markersRef.current.push(marker);
    });

    if (!showNearMe || !userLocation) {
      if (propertiesWithCoords.length > 0) {
        const bounds = new maplibregl.LngLatBounds();
        propertiesWithCoords.forEach((p) => p.coordinates && bounds.extend([p.coordinates.lng, p.coordinates.lat]));

        mapRef.current.fitBounds(bounds, {
          padding: 60,
          maxZoom: 16,
          duration: 1000,
        });
      }
    }
  }, [properties, showNearMe, userLocation]);

  return (
    <div className="relative w-full h-full min-h-[280px] rounded-xl overflow-hidden border border-border">
      <div ref={mapContainer} className="absolute inset-0 w-full h-full" />
      
      {/* Distance Calculator Overlay */}
      <MapDistanceOverlay 
        userLocation={userLocation || null} 
        onOfficeLocationChange={handleOfficeLocationChange} 
      />

      <style>{`
        .maplibregl-popup-content {
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.15);
          padding: 12px;
        }
        .maplibregl-popup-tip {
          border-top-color: white;
        }
        .maplibregl-ctrl-attrib,
        .maplibregl-ctrl-logo {
          display: none !important;
        }
        @keyframes pulse {
          0% { box-shadow: 0 0 0 0 rgba(59,130,246,0.4); }
          70% { box-shadow: 0 0 0 15px rgba(59,130,246,0); }
          100% { box-shadow: 0 0 0 0 rgba(59,130,246,0); }
        }
        @keyframes markerPulse {
          0% { 
            box-shadow: 0 4px 12px rgba(0,0,0,0.3), 0 0 0 0 rgba(74, 124, 89, 0.4);
          }
          50% { 
            box-shadow: 0 4px 12px rgba(0,0,0,0.3), 0 0 0 8px rgba(74, 124, 89, 0);
          }
          100% { 
            box-shadow: 0 4px 12px rgba(0,0,0,0.3), 0 0 0 0 rgba(74, 124, 89, 0.4);
          }
        }
        .property-marker:hover {
          animation: none !important;
          transform: scale(1.2);
        }
      `}</style>
    </div>
  );
};

export default MapView;
