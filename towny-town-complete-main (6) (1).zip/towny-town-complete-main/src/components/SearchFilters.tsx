import { useState, useRef, useEffect } from 'react';
import { Navigation, MapPin, Search, Loader2, Crosshair } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { SearchFilters as SearchFiltersType, PropertyType, TenantType } from '@/types/property';
import { indianCities } from '@/data/properties';
import { useToast } from '@/hooks/use-toast';

// Indian localities/areas for autocomplete
const indianLocalities = [
  'Koramangala, Bangalore',
  'Indiranagar, Bangalore',
  'HSR Layout, Bangalore',
  'Whitefield, Bangalore',
  'Electronic City, Bangalore',
  'MG Road, Bangalore',
  'Jayanagar, Bangalore',
  'BTM Layout, Bangalore',
  'Marathahalli, Bangalore',
  'Bandra West, Mumbai',
  'Andheri East, Mumbai',
  'Powai, Mumbai',
  'Juhu, Mumbai',
  'Worli, Mumbai',
  'Lower Parel, Mumbai',
  'Connaught Place, Delhi',
  'Hauz Khas, Delhi',
  'Greater Kailash, Delhi',
  'Dwarka, Delhi',
  'Vasant Kunj, Delhi',
  'Jubilee Hills, Hyderabad',
  'Banjara Hills, Hyderabad',
  'Gachibowli, Hyderabad',
  'Hitech City, Hyderabad',
  'Madhapur, Hyderabad',
  'Koregaon Park, Pune',
  'Hinjewadi, Pune',
  'Kharadi, Pune',
  'Viman Nagar, Pune',
  'Baner, Pune',
  'Salt Lake, Kolkata',
  'Park Street, Kolkata',
  'Alipore, Kolkata',
  'New Town, Kolkata',
  'Anna Nagar, Chennai',
  'T Nagar, Chennai',
  'Adyar, Chennai',
  'OMR, Chennai',
  'Velachery, Chennai',
];

interface SearchFiltersProps {
  filters: SearchFiltersType;
  onFilterChange: (filters: SearchFiltersType) => void;
  onSearch: () => void;
  onNearMeToggle: (enabled: boolean) => void;
  isLocating?: boolean;
}

const SearchFilters = ({ 
  filters, 
  onFilterChange, 
  onSearch, 
  onNearMeToggle,
  isLocating 
}: SearchFiltersProps) => {
  const { toast } = useToast();
  const [locationInput, setLocationInput] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  const propertyTypes: { id: PropertyType; label: string }[] = [
    { id: 'PG', label: 'PG' },
    { id: 'Hotel', label: 'Hotel' },
    { id: 'Commercial', label: 'Commercial' },
    { id: 'Plot', label: 'Plot/Land' },
  ];

  const bhkOptions = ['All', '1 BHK', '2 BHK', '3 BHK', '4+ BHK'];

  const tenantOptions: { id: TenantType; label: string }[] = [
    { id: 'All', label: 'All Tenants' },
    { id: 'bachelors', label: 'Bachelors' },
    { id: 'family', label: 'Family' },
    { id: 'anyone', label: 'Anyone' },
  ];

  // Get suggestions based on input
  const getSuggestions = (value: string) => {
    if (value.length > 0) {
      const filtered = indianLocalities.filter((loc) =>
        loc.toLowerCase().includes(value.toLowerCase())
      );
      const cityMatches = indianCities.filter((city) =>
        city.toLowerCase().includes(value.toLowerCase())
      );
      return [...cityMatches, ...filtered].slice(0, 8);
    }
    // Show default suggestions when input is empty
    return [...indianCities.slice(0, 4), ...indianLocalities.slice(0, 4)];
  };

  // Handle location input change with autocomplete
  const handleLocationChange = (value: string) => {
    setLocationInput(value);
    setSuggestions(getSuggestions(value));
    setShowSuggestions(true);
  };

  // Show suggestions on focus
  const handleInputFocus = () => {
    setSuggestions(getSuggestions(locationInput));
    setShowSuggestions(true);
  };

  // Handle suggestion selection
  const handleSelectSuggestion = (suggestion: string) => {
    setLocationInput(suggestion);
    setShowSuggestions(false);
    
    // Extract city from suggestion
    const parts = suggestion.split(', ');
    const city = parts.length > 1 ? parts[1] : parts[0];
    
    onFilterChange({ ...filters, location: city });
  };

  // Handle click outside to close suggestions
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        suggestionsRef.current &&
        !suggestionsRef.current.contains(target) &&
        inputRef.current &&
        !inputRef.current.contains(target)
      ) {
        setShowSuggestions(false);
      }
    };

    // Use 'click' instead of 'mousedown' so buttons inside dropdown work
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const handleNearMeClick = () => {
    const newNearMe = !filters.nearMe;
    onFilterChange({ ...filters, nearMe: newNearMe });
    onNearMeToggle(newNearMe);
  };

  // Get current location and reverse geocode to get address
  const handleUseCurrentLocation = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setShowSuggestions(false);
    
    if (!navigator.geolocation) {
      toast({
        title: 'Geolocation not supported',
        description: 'Your browser does not support geolocation',
        variant: 'destructive',
      });
      return;
    }

    setIsGettingLocation(true);

    // Check permissions first
    if (navigator.permissions) {
      navigator.permissions.query({ name: 'geolocation' }).then((result) => {
        if (result.state === 'denied') {
          setIsGettingLocation(false);
          toast({
            title: 'Location access denied',
            description: 'Please enable location access in your browser settings',
            variant: 'destructive',
          });
          return;
        }
        requestLocation();
      }).catch(() => {
        requestLocation();
      });
    } else {
      requestLocation();
    }

    function requestLocation() {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          
          try {
            // Use OpenStreetMap Nominatim for reverse geocoding
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=14`,
              {
                headers: {
                  'Accept': 'application/json',
                }
              }
            );
            
            if (!response.ok) {
              throw new Error('Geocoding failed');
            }
            
            const data = await response.json();
            
            // Extract location name
            const address = data.address;
            let locationName = '';
            
            if (address?.suburb) {
              locationName = address.suburb;
            } else if (address?.neighbourhood) {
              locationName = address.neighbourhood;
            } else if (address?.city_district) {
              locationName = address.city_district;
            }
            
            const city = address?.city || address?.town || address?.state_district || '';
            
            if (locationName && city) {
              setLocationInput(`${locationName}, ${city}`);
              onFilterChange({ ...filters, location: city });
            } else if (city) {
              setLocationInput(city);
              onFilterChange({ ...filters, location: city });
            } else {
              setLocationInput(data.display_name?.split(',')[0] || 'Current Location');
            }
            
            toast({
              title: 'Location detected',
              description: `Found: ${locationName || city || 'Your location'}`,
            });
          } catch (error) {
            console.error('Reverse geocoding error:', error);
            setLocationInput('Current Location');
            toast({
              title: 'Location detected',
              description: 'Using your current coordinates',
            });
          }
          
          setIsGettingLocation(false);
        },
        (error) => {
          setIsGettingLocation(false);
          console.error('Geolocation error:', error.code, error.message);
          
          let errorMessage = 'Please enable location access';
          if (error.code === 1) {
            errorMessage = 'Location permission denied. Please allow location access in your browser.';
          } else if (error.code === 2) {
            errorMessage = 'Location unavailable. Please try again.';
          } else if (error.code === 3) {
            errorMessage = 'Location request timed out. Please try again.';
          }
          
          toast({
            title: 'Could not get location',
            description: errorMessage,
            variant: 'destructive',
          });
        },
        { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
      );
    }
  };

  return (
    <div className="sticky top-[60px] z-40 bg-card border-b border-border py-4 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide pb-1">
          {/* Near Me Button */}
          <Button
            variant={filters.nearMe ? 'default' : 'outline'}
            className="gap-2 rounded-lg"
            onClick={handleNearMeClick}
            disabled={isLocating}
          >
            {isLocating ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Navigation className="w-4 h-4" />
            )}
            Near Me
          </Button>

          {/* Location Search with Autocomplete */}
          <div className="relative flex-1 min-w-[200px] max-w-[320px]">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground z-10" />
            <Input
              ref={inputRef}
              placeholder="Search location..."
              value={locationInput}
              onChange={(e) => handleLocationChange(e.target.value)}
              onFocus={handleInputFocus}
              className="pl-10 pr-10 rounded-lg"
            />
            
            {/* Use Current Location Button */}
            <button
              onClick={(e) => handleUseCurrentLocation(e)}
              disabled={isGettingLocation}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md hover:bg-muted transition-colors disabled:opacity-50"
              title="Use current location"
              type="button"
            >
              {isGettingLocation ? (
                <Loader2 className="w-4 h-4 animate-spin text-primary" />
              ) : (
                <Crosshair className="w-4 h-4 text-primary" />
              )}
            </button>
            
            {/* Autocomplete Suggestions */}
            {showSuggestions && (
              <div
                ref={suggestionsRef}
                className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg z-50 max-h-[280px] overflow-y-auto"
              >
                {/* Use Current Location Option */}
                <button
                  type="button"
                  onClick={(e) => handleUseCurrentLocation(e)}
                  disabled={isGettingLocation}
                  className="w-full px-4 py-2.5 text-left text-sm hover:bg-muted transition-colors flex items-center gap-2 border-b border-border text-primary font-medium"
                >
                  {isGettingLocation ? (
                    <Loader2 className="w-4 h-4 animate-spin flex-shrink-0" />
                  ) : (
                    <Crosshair className="w-4 h-4 flex-shrink-0" />
                  )}
                  <span>Use Current Location</span>
                </button>
                
                {suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleSelectSuggestion(suggestion)}
                    className="w-full px-4 py-2.5 text-left text-sm hover:bg-muted transition-colors flex items-center gap-2 last:rounded-b-lg"
                  >
                    <MapPin className="w-4 h-4 text-primary flex-shrink-0" />
                    <span className="truncate">{suggestion}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* BHK Type */}
          <Select
            value={filters.bhkType}
            onValueChange={(value) => onFilterChange({ ...filters, bhkType: value })}
          >
            <SelectTrigger className="w-[140px] rounded-lg">
              <SelectValue placeholder="BHK Type" />
            </SelectTrigger>
            <SelectContent>
              {bhkOptions.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Tenant Type */}
          <Select
            value={filters.tenantType}
            onValueChange={(value: TenantType) => onFilterChange({ ...filters, tenantType: value })}
          >
            <SelectTrigger className="w-[140px] rounded-lg">
              <SelectValue placeholder="Tenant Type" />
            </SelectTrigger>
            <SelectContent>
              {tenantOptions.map((option) => (
                <SelectItem key={option.id} value={option.id}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Property Type Chips */}
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide flex-shrink-0">
            {propertyTypes.map((type) => (
              <button
                key={type.id}
                onClick={() =>
                  onFilterChange({
                    ...filters,
                    propertyType: filters.propertyType === type.id ? 'All' : type.id,
                  })
                }
                className={`whitespace-nowrap ${filters.propertyType === type.id ? 'filter-chip-active' : 'filter-chip'}`}
              >
                {type.label}
              </button>
            ))}
          </div>

          {/* Search Button */}
          <Button onClick={onSearch} className="gap-2 rounded-lg">
            <Search className="w-4 h-4" />
            Search
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SearchFilters;
