import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, MessageSquare, Bell, Heart, Users, Plus, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PostPropertyForm from './PostPropertyForm';
import ProfileDropdown from './ProfileDropdown';
import TownyPlusButton from './TownyPlusButton';
import { useAuth } from '@/contexts/AuthContext';
import logo from '@/assets/logo.png';

interface HeaderProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

const Header = ({ activeTab = 'home', onTabChange }: HeaderProps) => {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [isPostFormOpen, setIsPostFormOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'roommate', label: 'Roommate', icon: Users },
    { id: 'messaging', label: 'Messaging', icon: MessageSquare },
    { id: 'saved', label: 'Saved', icon: Heart },
    { id: 'notifications', label: 'Notifications', icon: Bell },
  ];

  return (
    <>
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/')}>
              <img src={logo} alt="Towny" className="w-9 h-9 rounded-lg object-cover" />
              <span className="text-xl font-bold text-foreground">Towny</span>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    onTabChange?.(item.id);
                    if (item.id === 'home') navigate('/');
                    else if (item.id === 'messaging') navigate('/messages');
                    else if (item.id === 'notifications') navigate('/notifications');
                    else if (item.id === 'saved') navigate('/saved');
                    else if (item.id === 'roommate') navigate('/need-roommate');
                  }}
                  className={activeTab === item.id ? 'nav-link-active' : 'nav-link'}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-xs">{item.label}</span>
                </button>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Notification bell - visible on mobile/tablet only */}
              <Button
                variant="outline"
                size="icon"
                className="md:hidden h-10 w-10"
                onClick={() => navigate('/notifications')}
              >
                <Bell className="w-5 h-5" />
              </Button>
              
              <TownyPlusButton />
              
              {/* Post Ad - hidden on mobile/tablet, shown on desktop */}
              <Button 
                className="hidden md:flex gap-2 rounded-lg font-semibold"
                onClick={() => setIsPostFormOpen(true)}
              >
                <Plus className="w-4 h-4" />
                Post Ad
              </Button>
              
              {!loading && (
                user ? (
                  <ProfileDropdown />
                ) : (
                  <Button
                    variant="outline"
                    className="gap-2 rounded-lg"
                    onClick={() => navigate('/auth')}
                  >
                    <LogIn className="w-4 h-4" />
                    <span className="hidden sm:inline">Login</span>
                  </Button>
                )
              )}
            </div>
          </div>
        </div>
      </header>

      <PostPropertyForm 
        isOpen={isPostFormOpen} 
        onClose={() => setIsPostFormOpen(false)} 
      />
    </>
  );
};

export default Header;
