import { useState } from 'react';
import { X, MapPin, Upload, Plus, Video, Trash2, Calendar, Loader2, LogIn, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { indianCities } from '@/data/properties';
import { format } from 'date-fns';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { addWatermark } from '@/lib/watermark';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface PostPropertyFormProps {
  isOpen: boolean;
  onClose: () => void;
}

const PostPropertyForm = ({ isOpen, onClose }: PostPropertyFormProps) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [images, setImages] = useState<string[]>([]);
  const [videos, setVideos] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isProcessingImages, setIsProcessingImages] = useState(false);
  const [availableDate, setAvailableDate] = useState<Date>();

  const [formData, setFormData] = useState({
    title: '',
    propertyType: '',
    furnishing: '',
    tenantType: '',
    rent: '',
    securityDeposit: '',
    dailyRent: '',
    city: '',
    area: '',
    address: '',
    bedrooms: '',
    bathrooms: '',
    sqft: '',
    description: '',
    // PG specific
    sharingType: '',
    mealIncluded: '',
    // Hotel specific
    roomType: '',
    starRating: '',
    // Plot specific
    plotArea: '',
    facing: '',
    // Featured ad
    isFeatured: false,
  });

  const propertyTypes = [
    { value: '1bhk', label: '1BHK' },
    { value: '2bhk', label: '2BHK' },
    { value: '3bhk', label: '3BHK' },
    { value: 'pg', label: 'PG' },
    { value: 'hotel', label: 'Hotel' },
    { value: 'commercial', label: 'Commercial' },
    { value: 'plot', label: 'Plot' },
    { value: 'roommate', label: 'Need Roommate' },
  ];

  const furnishingOptions = [
    { value: 'unfurnished', label: 'Unfurnished' },
    { value: 'semi', label: 'Semi-Furnished' },
    { value: 'fully', label: 'Fully Furnished' },
  ];

  const sharingTypes = [
    { value: 'single', label: 'Single Occupancy' },
    { value: 'double', label: 'Double Sharing' },
    { value: 'triple', label: 'Triple Sharing' },
    { value: 'quad', label: '4+ Sharing' },
  ];

  const roomTypes = [
    { value: 'standard', label: 'Standard' },
    { value: 'deluxe', label: 'Deluxe' },
    { value: 'suite', label: 'Suite' },
    { value: 'premium', label: 'Premium' },
  ];

  const facingOptions = [
    { value: 'north', label: 'North' },
    { value: 'south', label: 'South' },
    { value: 'east', label: 'East' },
    { value: 'west', label: 'West' },
    { value: 'northeast', label: 'North-East' },
    { value: 'northwest', label: 'North-West' },
    { value: 'southeast', label: 'South-East' },
    { value: 'southwest', label: 'South-West' },
  ];

  const tenantTypeOptions = [
    { value: 'bachelors', label: 'Bachelors Allowed' },
    { value: 'family', label: 'Family Only' },
    { value: 'anyone', label: 'Anyone' },
  ];

  const isPG = formData.propertyType === 'pg';
  const isHotel = formData.propertyType === 'hotel';
  const isPlot = formData.propertyType === 'plot';
  const isBHK = ['1bhk', '2bhk', '3bhk'].includes(formData.propertyType);
  const isCommercial = formData.propertyType === 'commercial';
  const isRoommate = formData.propertyType === 'roommate';

  const numericFields = ['rent', 'securityDeposit', 'dailyRent', 'bedrooms', 'bathrooms', 'sqft', 'plotArea', 'starRating'];

  const handleInputChange = (field: string, value: string) => {
    // Prevent negative values for numeric fields
    if (numericFields.includes(field)) {
      const numValue = parseFloat(value);
      if (value !== '' && (isNaN(numValue) || numValue < 0)) {
        return;
      }
    }
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    if (images.length + files.length > 5) {
      toast({
        title: 'Maximum 5 images allowed',
        variant: 'destructive',
      });
      return;
    }

    setIsProcessingImages(true);

    try {
      const processedImages: string[] = [];
      
      for (const file of Array.from(files)) {
        if (file.size > 5 * 1024 * 1024) {
          toast({
            title: 'Image too large',
            description: 'Max 5MB per image',
            variant: 'destructive',
          });
          continue;
        }

        // Read file as data URL
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        // Add watermark to the image
        const watermarkedImage = await addWatermark(dataUrl);
        processedImages.push(watermarkedImage);
      }

      setImages((prev) => [...prev, ...processedImages]);
      
      if (processedImages.length > 0) {
        toast({
          title: 'Images added',
          description: `${processedImages.length} image(s) with Towny watermark`,
        });
      }
    } catch (error) {
      console.error('Error processing images:', error);
      toast({
        title: 'Error processing images',
        variant: 'destructive',
      });
    } finally {
      setIsProcessingImages(false);
    }
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    if (videos.length + files.length > 2) {
      toast({
        title: 'Maximum 2 videos allowed',
        variant: 'destructive',
      });
      return;
    }

    Array.from(files).forEach((file) => {
      if (file.size > 50 * 1024 * 1024) {
        toast({
          title: 'Video too large',
          description: 'Max 50MB per video',
          variant: 'destructive',
        });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setVideos((prev) => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const removeVideo = (index: number) => {
    setVideos((prev) => prev.filter((_, i) => i !== index));
  };

  const [isGettingLocation, setIsGettingLocation] = useState(false);

  const handleUseLocation = () => {
    if (navigator.geolocation) {
      setIsGettingLocation(true);
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            const { latitude, longitude } = position.coords;
            
            // Reverse geocode using OpenStreetMap Nominatim
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&addressdetails=1`
            );
            const data = await response.json();
            
            if (data && data.address) {
              const address = data.address;
              const city = address.city || address.town || address.village || address.state_district || '';
              const area = address.suburb || address.neighbourhood || address.road || '';
              const fullAddress = data.display_name || '';
              
              // Find matching city from indianCities
              const matchedCity = indianCities.find(
                c => c.toLowerCase() === city.toLowerCase() || 
                     fullAddress.toLowerCase().includes(c.toLowerCase())
              );
              
              setFormData(prev => ({
                ...prev,
                city: matchedCity || city,
                area: area,
                address: fullAddress.split(',').slice(0, 3).join(', ')
              }));
              
              toast({
                title: 'Location detected',
                description: `${area ? area + ', ' : ''}${matchedCity || city}`,
              });
            }
          } catch (error) {
            console.error('Geocoding error:', error);
            toast({
              title: 'Could not get address',
              description: 'Location detected but address lookup failed',
              variant: 'destructive',
            });
          } finally {
            setIsGettingLocation(false);
          }
        },
        () => {
          setIsGettingLocation(false);
          toast({
            title: 'Location access denied',
            description: 'Please enable location access',
            variant: 'destructive',
          });
        }
      );
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.propertyType || !formData.rent || !formData.city || !formData.area) {
      toast({
        title: 'Required fields missing',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    // Simulate submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    toast({
      title: 'Property posted successfully!',
      description: 'Your listing is now live on Towny',
    });

    setIsSubmitting(false);
    onClose();

    // Reset form
    setFormData({
      title: '',
      propertyType: '',
      furnishing: '',
      tenantType: '',
      rent: '',
      securityDeposit: '',
      dailyRent: '',
      city: '',
      area: '',
      address: '',
      bedrooms: '',
      bathrooms: '',
      sqft: '',
      description: '',
      sharingType: '',
      mealIncluded: '',
      roomType: '',
      starRating: '',
      plotArea: '',
      facing: '',
      isFeatured: false,
    });
    setImages([]);
    setVideos([]);
    setAvailableDate(undefined);
  };

  const handleSignUp = () => {
    onClose();
    navigate('/auth');
  };

  // Show auth prompt if user is not logged in
  if (!user) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-foreground text-center">
              Sign Up to Post Property
            </DialogTitle>
            <DialogDescription className="text-muted-foreground text-center mt-2">
              You need to create an account or sign in to post your property on Towny
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex flex-col items-center gap-4 py-6">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <LogIn className="w-8 h-8 text-primary" />
            </div>
            <p className="text-sm text-muted-foreground text-center max-w-xs">
              Join thousands of property owners listing on Towny. It's free and takes less than a minute!
            </p>
            <div className="flex flex-col sm:flex-row gap-3 w-full mt-2">
              <Button 
                variant="outline" 
                onClick={onClose}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSignUp}
                className="flex-1 gap-2"
              >
                <LogIn className="w-4 h-4" />
                Sign Up / Login
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-foreground">
            Post Your Property
          </DialogTitle>
          <DialogDescription className="text-muted-foreground text-sm mt-1">
            Fill in the details below to list your property on Towny
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* Property Title */}
          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-medium">
              Property Title <span className="text-destructive">*</span>
            </Label>
            <Input
              id="title"
              placeholder="e.g., Spacious 2BHK in Koramangala"
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              className="rounded-lg"
            />
          </div>

          {/* Property Type */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">
              Property Type <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formData.propertyType}
              onValueChange={(value) => handleInputChange('propertyType', value)}
            >
              <SelectTrigger className="rounded-lg">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                {propertyTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Featured Ad Toggle */}
          <div 
            onClick={() => setFormData(prev => ({ ...prev, isFeatured: !prev.isFeatured }))}
            className={cn(
              "flex items-center justify-between p-4 rounded-lg border-2 cursor-pointer transition-all",
              formData.isFeatured 
                ? "border-amber-400 bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-950/30 dark:to-yellow-950/30" 
                : "border-border hover:border-amber-300"
            )}
          >
            <div className="flex items-center gap-3">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center",
                formData.isFeatured ? "bg-gradient-to-r from-amber-400 to-yellow-500" : "bg-muted"
              )}>
                <Star className={cn(
                  "w-5 h-5",
                  formData.isFeatured ? "text-white fill-white" : "text-muted-foreground"
                )} />
              </div>
              <div>
                <p className="font-semibold text-foreground">Featured Ad</p>
                <p className="text-xs text-muted-foreground">Get more visibility with golden star badge</p>
              </div>
            </div>
            <div className={cn(
              "w-12 h-6 rounded-full transition-colors relative",
              formData.isFeatured ? "bg-gradient-to-r from-amber-400 to-yellow-500" : "bg-muted"
            )}>
              <div className={cn(
                "absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm transition-transform",
                formData.isFeatured ? "translate-x-7" : "translate-x-1"
              )} />
            </div>
          </div>

          {/* Tenant Type - Show for BHK and PG */}
          {(isBHK || isPG) && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">
                Tenants Allowed <span className="text-destructive">*</span>
              </Label>
              <Select
                value={formData.tenantType}
                onValueChange={(value) => handleInputChange('tenantType', value)}
              >
                <SelectTrigger className="rounded-lg">
                  <SelectValue placeholder="Select tenant type" />
                </SelectTrigger>
                <SelectContent>
                  {tenantTypeOptions.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Dynamic fields based on property type */}
          {/* PG Specific Fields */}
          {isPG && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Sharing Type</Label>
                <Select
                  value={formData.sharingType}
                  onValueChange={(value) => handleInputChange('sharingType', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select sharing" />
                  </SelectTrigger>
                  <SelectContent>
                    {sharingTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Meals Included</Label>
                <Select
                  value={formData.mealIncluded}
                  onValueChange={(value) => handleInputChange('mealIncluded', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yes">Yes</SelectItem>
                    <SelectItem value="no">No</SelectItem>
                    <SelectItem value="optional">Optional (Extra Cost)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Hotel Specific Fields */}
          {isHotel && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Room Type</Label>
                <Select
                  value={formData.roomType}
                  onValueChange={(value) => handleInputChange('roomType', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select room type" />
                  </SelectTrigger>
                  <SelectContent>
                    {roomTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Star Rating</Label>
                <Select
                  value={formData.starRating}
                  onValueChange={(value) => handleInputChange('starRating', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select rating" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 Star</SelectItem>
                    <SelectItem value="2">2 Star</SelectItem>
                    <SelectItem value="3">3 Star</SelectItem>
                    <SelectItem value="4">4 Star</SelectItem>
                    <SelectItem value="5">5 Star</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Plot Specific Fields */}
          {isPlot && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="plotArea" className="text-sm font-medium">
                  Plot Area (sq.yards)
                </Label>
                <Input
                  id="plotArea"
                  type="number"
                  min="0"
                  placeholder="e.g., 200"
                  value={formData.plotArea}
                  onChange={(e) => handleInputChange('plotArea', e.target.value)}
                  className="rounded-lg"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Facing</Label>
                <Select
                  value={formData.facing}
                  onValueChange={(value) => handleInputChange('facing', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select facing" />
                  </SelectTrigger>
                  <SelectContent>
                    {facingOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Roommate Specific Fields */}
          {isRoommate && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Your Gender</Label>
                <Select
                  value={formData.tenantType}
                  onValueChange={(value) => handleInputChange('tenantType', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Looking For</Label>
                <Select
                  value={formData.sharingType}
                  onValueChange={(value) => handleInputChange('sharingType', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select preference" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male Roommate</SelectItem>
                    <SelectItem value="female">Female Roommate</SelectItem>
                    <SelectItem value="any">Any</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label className="text-sm font-medium">Your Occupation</Label>
                <Select
                  value={formData.roomType}
                  onValueChange={(value) => handleInputChange('roomType', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select occupation" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="working">Working Professional</SelectItem>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {(isBHK || isCommercial || isPG) && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Furnishing</Label>
              <Select
                value={formData.furnishing}
                onValueChange={(value) => handleInputChange('furnishing', value)}
              >
                <SelectTrigger className="rounded-lg">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  {furnishingOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Rent & Security Deposit / Daily Rent */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="rent" className="text-sm font-medium">
                {isHotel ? 'Rent (₹/day)' : 'Rent (₹/month)'} <span className="text-destructive">*</span>
              </Label>
              <Input
                id="rent"
                type="number"
                min="0"
                placeholder={isHotel ? 'e.g., 2500' : 'e.g., 25000'}
                value={formData.rent}
                onChange={(e) => handleInputChange('rent', e.target.value)}
                className="rounded-lg"
              />
            </div>

            {isBHK && (
              <div className="space-y-2">
                <Label htmlFor="deposit" className="text-sm font-medium">
                  Security Deposit (₹)
                </Label>
                <Input
                  id="deposit"
                  type="number"
                  min="0"
                  placeholder="e.g., 50000"
                  value={formData.securityDeposit}
                  onChange={(e) => handleInputChange('securityDeposit', e.target.value)}
                  className="rounded-lg"
                />
              </div>
            )}
          </div>

          {/* Location Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Location</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleUseLocation}
                disabled={isGettingLocation}
                className="gap-2 text-primary border-primary hover:bg-primary/10"
              >
                {isGettingLocation ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Detecting...
                  </>
                ) : (
                  <>
                    <MapPin className="w-4 h-4" />
                    Use Current Location
                  </>
                )}
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  City <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={formData.city}
                  onValueChange={(value) => handleInputChange('city', value)}
                >
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select city" />
                  </SelectTrigger>
                  <SelectContent>
                    {indianCities.map((city) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="area" className="text-sm font-medium">
                  Area/Locality <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="area"
                  placeholder="e.g., Koramangala"
                  value={formData.area}
                  onChange={(e) => handleInputChange('area', e.target.value)}
                  className="rounded-lg"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address" className="text-sm font-medium">
                Full Address
              </Label>
              <Input
                id="address"
                placeholder="Complete address with landmarks"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                className="rounded-lg"
              />
            </div>
          </div>

          {/* Property Details */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="bedrooms" className="text-sm font-medium">
                Bedrooms
              </Label>
              <Input
                id="bedrooms"
                type="number"
                min="0"
                placeholder="0"
                value={formData.bedrooms}
                onChange={(e) => handleInputChange('bedrooms', e.target.value)}
                className="rounded-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bathrooms" className="text-sm font-medium">
                Bathrooms
              </Label>
              <Input
                id="bathrooms"
                type="number"
                min="0"
                placeholder="0"
                value={formData.bathrooms}
                onChange={(e) => handleInputChange('bathrooms', e.target.value)}
                className="rounded-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sqft" className="text-sm font-medium">
                Area (sqft)
              </Label>
              <Input
                id="sqft"
                type="number"
                min="0"
                placeholder="0"
                value={formData.sqft}
                onChange={(e) => handleInputChange('sqft', e.target.value)}
                className="rounded-lg"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium">
                Available From
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal rounded-lg",
                      !availableDate && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {availableDate ? format(availableDate, "dd-MM-yyyy") : <span>dd-mm-yyyy</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={availableDate}
                    onSelect={setAvailableDate}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-medium">
              Description
            </Label>
            <Textarea
              id="description"
              placeholder="Describe your property, amenities, nearby facilities, etc."
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              className="rounded-lg min-h-[100px] resize-none"
            />
          </div>

          {/* Property Images */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">
                Property Images (Max 5)
              </Label>
              <span className="text-xs text-muted-foreground">{images.length}/5</span>
            </div>

            <div className="flex flex-wrap gap-3">
              {images.map((image, index) => (
                <div key={index} className="relative w-20 h-20 rounded-lg overflow-hidden group">
                  <img src={image} alt={`Property ${index + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute inset-0 bg-foreground/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                  >
                    <Trash2 className="w-5 h-5 text-background" />
                  </button>
                </div>
              ))}

              {images.length < 5 && (
                <label className={`w-20 h-20 rounded-lg border-2 border-dashed border-border hover:border-primary flex flex-col items-center justify-center transition-colors ${isProcessingImages ? 'cursor-wait opacity-70' : 'cursor-pointer'}`}>
                  {isProcessingImages ? (
                    <Loader2 className="w-5 h-5 text-primary animate-spin" />
                  ) : (
                    <>
                      <Plus className="w-5 h-5 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground mt-1">Add</span>
                    </>
                  )}
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    multiple
                    onChange={handleImageUpload}
                    className="hidden"
                    disabled={isProcessingImages}
                  />
                </label>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Supported: JPG, PNG, WebP. Max 5MB per image. Towny watermark will be added automatically.
            </p>
          </div>

          {/* Property Videos */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">
                Property Videos (Max 2)
              </Label>
              <span className="text-xs text-muted-foreground">{videos.length}/2</span>
            </div>

            <div className="flex flex-wrap gap-3">
              {videos.map((_, index) => (
                <div key={index} className="relative w-24 h-20 rounded-lg bg-muted flex items-center justify-center group">
                  <Video className="w-6 h-6 text-muted-foreground" />
                  <button
                    type="button"
                    onClick={() => removeVideo(index)}
                    className="absolute inset-0 bg-foreground/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-lg"
                  >
                    <Trash2 className="w-5 h-5 text-background" />
                  </button>
                </div>
              ))}

              {videos.length < 2 && (
                <label className="w-24 h-20 rounded-lg border-2 border-dashed border-border hover:border-primary flex flex-col items-center justify-center cursor-pointer transition-colors">
                  <Video className="w-5 h-5 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground mt-1">Add Video</span>
                  <input
                    type="file"
                    accept="video/mp4,video/quicktime,video/webm"
                    onChange={handleVideoUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Supported: MP4, MOV, WebM. Max 50MB per video.
            </p>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full rounded-lg h-12 text-base font-semibold"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Posting...' : 'Post Property'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PostPropertyForm;
