import { useState } from 'react';
import { Star, Gift, Coins, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useReferral } from '@/hooks/useReferral';
import { useTownyCoins } from '@/hooks/useTownyCoins';

const TownyPlusButton = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { hasActiveBoost, boostExpiresAt } = useReferral();
  const { balance } = useTownyCoins();
  const [isOpen, setIsOpen] = useState(false);

  const getTimeRemaining = () => {
    if (!boostExpiresAt) return null;
    const now = new Date();
    const diff = boostExpiresAt.getTime() - now.getTime();
    if (diff <= 0) return null;
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const handleClick = () => {
    if (!user) {
      navigate('/auth');
      return;
    }
    setIsOpen(true);
  };

  const timeRemaining = getTimeRemaining();

  return (
    <>
      <Button
        variant={hasActiveBoost ? "default" : "outline"}
        size="sm"
        className={`gap-2 rounded-lg ${hasActiveBoost ? 'bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 text-white border-0' : ''}`}
        onClick={handleClick}
      >
        <Star className={`w-4 h-4 ${hasActiveBoost ? 'fill-white text-white' : 'fill-amber-400 text-amber-400'}`} />
        <span className="hidden sm:inline">
          {hasActiveBoost ? 'Towny Plus Active' : 'Towny Plus'}
        </span>
        {balance > 0 && (
          <span className="flex items-center gap-1 ml-1 bg-background/20 px-1.5 py-0.5 rounded text-xs">
            <Coins className="w-3 h-3" />
            {balance}
          </span>
        )}
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
              Towny Plus
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Active Boost Status */}
            {hasActiveBoost && timeRemaining && (
              <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/30 rounded-lg p-4">
                <div className="flex items-center gap-2 text-amber-600 mb-2">
                  <Clock className="w-4 h-4" />
                  <span className="font-semibold">Boost Active!</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Your listings are boosted for the next <strong>{timeRemaining}</strong>
                </p>
              </div>
            )}

            {/* Coin Balance */}
            <div className="bg-muted/50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Coins className="w-5 h-5 text-amber-500" />
                  <span className="font-medium">Towny Coins</span>
                </div>
                <span className="text-2xl font-bold">{balance}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Earn 10 coins for every successful referral
              </p>
            </div>

            {/* How to Unlock */}
            <div className="space-y-3">
              <h4 className="font-medium flex items-center gap-2">
                <Gift className="w-4 h-4 text-primary" />
                How to Unlock Towny Plus
              </h4>
              
              <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
                <p className="text-sm mb-3">
                  <strong>Refer a friend</strong> and get <strong>24 hours</strong> of Towny Plus FREE!
                </p>
                <ul className="text-sm space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    Featured badge on your listings
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    Priority visibility in search
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    Earn 10 Towny coins per referral
                  </li>
                </ul>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-2">
              <Button 
                onClick={() => {
                  setIsOpen(false);
                  navigate('/referrals');
                }}
                className="w-full gap-2"
              >
                <Gift className="w-4 h-4" />
                Refer & Earn
              </Button>
              
              <Button 
                variant="outline"
                onClick={() => {
                  setIsOpen(false);
                  navigate('/coins');
                }}
                className="w-full gap-2"
              >
                <Coins className="w-4 h-4" />
                View Coins & Withdraw
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default TownyPlusButton;
