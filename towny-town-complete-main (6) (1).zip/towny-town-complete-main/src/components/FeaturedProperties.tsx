import { useState } from 'react';
import PropertyCard from './PropertyCard';
import { Property } from '@/types/property';
import Pagination from './Pagination';
import { useBoostedUsers } from '@/hooks/useBoostedUsers';

interface FeaturedPropertiesProps {
  properties: Property[];
}

const FeaturedProperties = ({ properties }: FeaturedPropertiesProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12; // 4 properties x 3 rows
  const { isUserBoosted } = useBoostedUsers();
  
  const totalPages = Math.ceil(properties.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const visibleProperties = properties.slice(startIndex, startIndex + itemsPerPage);

  return (
    <section className="py-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-foreground">Featured Posts</h2>
        <p className="text-muted-foreground mt-1">Handpicked properties for you</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {visibleProperties.map((property, index) => (
          <div
            key={property.id}
            className="animate-fade-in"
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <PropertyCard 
              property={property} 
              isBoosted={property.userId ? isUserBoosted(property.userId) : false}
            />
          </div>
        ))}
      </div>

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
      />
    </section>
  );
};

export default FeaturedProperties;
