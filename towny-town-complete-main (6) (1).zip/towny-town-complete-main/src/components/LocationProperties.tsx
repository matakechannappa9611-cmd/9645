import { useState } from 'react';
import PropertyCard from './PropertyCard';
import { Property } from '@/types/property';
import Pagination from './Pagination';

interface LocationPropertiesProps {
  properties: Property[];
  title?: string;
}

const LocationProperties = ({ properties, title = 'Properties in this Location' }: LocationPropertiesProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6; // 3 properties x 2 rows
  
  const totalPages = Math.ceil(properties.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const visibleProperties = properties.slice(startIndex, startIndex + itemsPerPage);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-foreground">{title}</h2>
        <button className="text-primary hover:text-primary/80 text-sm font-medium transition-colors">
          View all
        </button>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {visibleProperties.length > 0 ? (
          visibleProperties.map((property) => (
            <PropertyCard key={property.id} property={property} />
          ))
        ) : (
          <div className="col-span-2 text-center py-8 text-muted-foreground">
            No properties found in this area
          </div>
        )}
      </div>

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
      />
    </div>
  );
};

export default LocationProperties;
