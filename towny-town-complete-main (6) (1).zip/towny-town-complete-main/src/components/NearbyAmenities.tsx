import { useState, useEffect } from "react";
import {
  Hospital,
  Stethoscope,
  Dumbbell,
  UtensilsCrossed,
  Coffee,
  Trees,
  ShoppingBag,
  ShoppingCart,
  GraduationCap,
  Train,
  Bus,
  Landmark,
  Pill,
  MapPin,
  Loader2,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Amenity {
  name: string;
  distance: string;
  type?: string;
  cuisine?: string;
  line?: string;
}

interface AmenitiesData {
  hospitals: Amenity[];
  clinics: Amenity[];
  gyms: Amenity[];
  restaurants: Amenity[];
  cafes: Amenity[];
  parks: Amenity[];
  shopping: Amenity[];
  grocery: Amenity[];
  schools: Amenity[];
  metro: Amenity[];
  bus_stops: Amenity[];
  atms: Amenity[];
  pharmacies: Amenity[];
  summary: string;
}

interface NearbyAmenitiesProps {
  location: string;
  city: string;
  coordinates?: { lat: number; lng: number };
}

const categoryConfig = [
  { key: "hospitals", label: "Hospitals", icon: Hospital, color: "text-red-500" },
  { key: "clinics", label: "Clinics", icon: Stethoscope, color: "text-pink-500" },
  { key: "gyms", label: "Gyms & Fitness", icon: Dumbbell, color: "text-orange-500" },
  { key: "restaurants", label: "Restaurants", icon: UtensilsCrossed, color: "text-amber-500" },
  { key: "cafes", label: "Cafes", icon: Coffee, color: "text-brown-500" },
  { key: "parks", label: "Parks & Gardens", icon: Trees, color: "text-green-500" },
  { key: "shopping", label: "Shopping", icon: ShoppingBag, color: "text-purple-500" },
  { key: "grocery", label: "Grocery Stores", icon: ShoppingCart, color: "text-teal-500" },
  { key: "schools", label: "Schools", icon: GraduationCap, color: "text-blue-500" },
  { key: "metro", label: "Metro Stations", icon: Train, color: "text-indigo-500" },
  { key: "bus_stops", label: "Bus Stops", icon: Bus, color: "text-cyan-500" },
  { key: "atms", label: "ATMs & Banks", icon: Landmark, color: "text-emerald-500" },
  { key: "pharmacies", label: "Pharmacies", icon: Pill, color: "text-rose-500" },
];

const NearbyAmenities = ({ location, city, coordinates }: NearbyAmenitiesProps) => {
  const [amenities, setAmenities] = useState<AmenitiesData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchAmenities = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke("get-nearby-amenities", {
        body: { location, city, coordinates },
      });
      
      if (fnError) {
        throw fnError;
      }
      
      if (data.error) {
        throw new Error(data.error);
      }
      
      setAmenities(data);
      setIsExpanded(true);
    } catch (err) {
      console.error("Error fetching amenities:", err);
      const errorMessage = err instanceof Error ? err.message : "Failed to load amenities";
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderAmenityList = (items: Amenity[], icon: React.ElementType, color: string) => {
    const Icon = icon;
    return items.map((item, index) => (
      <div
        key={index}
        className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
      >
        <div className={`mt-0.5 ${color}`}>
          <Icon className="w-4 h-4" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm text-foreground truncate">{item.name}</p>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-xs text-primary font-medium">{item.distance}</span>
            {(item.type || item.cuisine || item.line) && (
              <>
                <span className="text-muted-foreground">•</span>
                <span className="text-xs text-muted-foreground truncate">
                  {item.type || item.cuisine || item.line}
                </span>
              </>
            )}
          </div>
        </div>
      </div>
    ));
  };

  if (!isExpanded && !isLoading) {
    return (
      <Button
        variant="outline"
        className="w-full gap-2 border-primary/30 hover:border-primary hover:bg-primary/5"
        onClick={fetchAmenities}
      >
        <Sparkles className="w-4 h-4 text-primary" />
        <span>Discover Nearby Amenities</span>
        <span className="text-xs text-muted-foreground ml-1">(AI powered)</span>
      </Button>
    );
  }

  if (isLoading) {
    return (
      <div className="p-6 rounded-xl border border-border bg-card">
        <div className="flex items-center justify-center gap-3">
          <Loader2 className="w-5 h-5 animate-spin text-primary" />
          <p className="text-muted-foreground">Discovering nearby places...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 rounded-xl border border-destructive/30 bg-destructive/5">
        <p className="text-sm text-destructive text-center">{error}</p>
        <Button
          variant="outline"
          size="sm"
          className="w-full mt-3"
          onClick={fetchAmenities}
        >
          Try Again
        </Button>
      </div>
    );
  }

  if (!amenities) return null;

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <div
        className="flex items-center justify-between p-4 bg-gradient-to-r from-primary/5 to-transparent cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">Nearby Amenities</h3>
          <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
            AI Powered
          </span>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          {isExpanded ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </Button>
      </div>

      {isExpanded && (
        <div className="p-4 space-y-4">
          {/* Summary */}
          {amenities.summary && (
            <p className="text-sm text-muted-foreground bg-muted/30 p-3 rounded-lg italic">
              "{amenities.summary}"
            </p>
          )}

          {/* Amenity Categories */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {categoryConfig.map(({ key, label, icon, color }) => {
              const items = amenities[key as keyof AmenitiesData] as Amenity[];
              if (!items || items.length === 0) return null;

              return (
                <div key={key} className="space-y-2">
                  <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
                    {(() => {
                      const Icon = icon;
                      return <Icon className={`w-4 h-4 ${color}`} />;
                    })()}
                    {label}
                  </h4>
                  <div className="space-y-2">
                    {renderAmenityList(items, icon, color)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default NearbyAmenities;
