import { useState, useMemo } from 'react';
import PropertyCard from './PropertyCard';
import { Property } from '@/types/property';
import Pagination from './Pagination';
import { useBoostedUsers } from '@/hooks/useBoostedUsers';

interface PropertyGridProps {
  properties: Property[];
  title?: string;
  showViewAll?: boolean;
  excludeFeatured?: boolean;
}

const PropertyGrid = ({ 
  properties, 
  title = 'All Properties', 
  showViewAll = false,
  excludeFeatured = false,
}: PropertyGridProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12; // 4 properties x 3 rows
  const { isUserBoosted } = useBoostedUsers();

  // Filter out featured properties if excludeFeatured is true, then sort by price
  // Boosted properties appear first
  const sortedProperties = useMemo(() => {
    const filtered = excludeFeatured ? properties.filter(p => !p.isFeatured) : properties;
    return [...filtered].sort((a, b) => {
      // Boosted properties first
      const aIsBoosted = a.userId ? isUserBoosted(a.userId) : false;
      const bIsBoosted = b.userId ? isUserBoosted(b.userId) : false;
      if (aIsBoosted && !bIsBoosted) return -1;
      if (!aIsBoosted && bIsBoosted) return 1;
      // Then sort by price
      return a.price - b.price;
    });
  }, [properties, excludeFeatured, isUserBoosted]);
  
  const totalPages = Math.ceil(sortedProperties.length / itemsPerPage);
  
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentProperties = sortedProperties.slice(startIndex, startIndex + itemsPerPage);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  return (
    <section className="py-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <h2 className="text-2xl font-bold text-foreground">{title}</h2>

        {showViewAll && (
          <button className="text-primary hover:text-primary/80 font-medium text-sm transition-colors">
            View all
          </button>
        )}
      </div>

      {currentProperties.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {currentProperties.map((property, index) => (
            <div
              key={property.id}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <PropertyCard 
                property={property} 
                isBoosted={property.userId ? isUserBoosted(property.userId) : false}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          No properties found matching your criteria
        </div>
      )}

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={handlePageChange}
      />
    </section>
  );
};

export default PropertyGrid;
