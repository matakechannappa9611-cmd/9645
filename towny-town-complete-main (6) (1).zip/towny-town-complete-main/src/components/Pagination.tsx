import { ChevronRight } from 'lucide-react';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

const Pagination = ({ currentPage, totalPages, onPageChange }: PaginationProps) => {
  if (totalPages <= 1) return null;

  const goToNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  return (
    <div className="flex items-center justify-end gap-1.5 mt-4">
      {/* Page Numbers */}
      {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => i + 1).map((page) => (
        <button
          key={page}
          onClick={() => onPageChange(page)}
          className={`w-8 h-8 rounded-md text-xs font-medium transition-colors ${
            page === currentPage
              ? 'bg-primary text-primary-foreground'
              : 'text-muted-foreground hover:text-primary hover:bg-muted'
          }`}
        >
          {page}
        </button>
      ))}

      {/* Next Button */}
      {currentPage < totalPages && (
        <button
          onClick={goToNext}
          className="flex items-center gap-0.5 px-2 h-8 rounded-md text-xs font-medium text-muted-foreground hover:text-primary hover:bg-muted transition-colors"
        >
          Next
          <ChevronRight className="w-3 h-3" />
        </button>
      )}
    </div>
  );
};

export default Pagination;
