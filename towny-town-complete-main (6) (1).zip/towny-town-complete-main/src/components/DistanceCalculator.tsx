import { useState, useRef, useEffect } from "react";
import { MapPin, Building2, Navigation, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Location {
  lat: number;
  lng: number;
  name: string;
}

// Calculate distance between two coordinates in km (Haversine formula)
const getDistanceFromLatLonInKm = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// Estimate travel time (assuming average speed of 25 km/h in city traffic)
const estimateTravelTime = (distanceKm: number): string => {
  const minutes = Math.round((distanceKm / 25) * 60);
  if (minutes < 60) {
    return `${minutes} min`;
  }
  const hours = Math.floor(minutes / 60);
  const remainingMins = minutes % 60;
  return `${hours}h ${remainingMins}m`;
};

const DistanceCalculator = () => {
  const [homeLocation, setHomeLocation] = useState<Location | null>(null);
  const [officeLocation, setOfficeLocation] = useState<Location | null>(null);
  const [homeSearch, setHomeSearch] = useState("");
  const [officeSearch, setOfficeSearch] = useState("");
  const [homeSuggestions, setHomeSuggestions] = useState<any[]>([]);
  const [officeSuggestions, setOfficeSuggestions] = useState<any[]>([]);
  const [isLoadingHome, setIsLoadingHome] = useState(false);
  const [isLoadingOffice, setIsLoadingOffice] = useState(false);
  const [distance, setDistance] = useState<number | null>(null);
  const homeDebounceRef = useRef<NodeJS.Timeout>();
  const officeDebounceRef = useRef<NodeJS.Timeout>();

  // Simple geocoding using Nominatim (free OpenStreetMap service)
  const searchLocation = async (query: string): Promise<any[]> => {
    if (!query || query.length < 3) return [];
    
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}, India&limit=5`
      );
      const data = await response.json();
      return data.map((item: any) => ({
        lat: parseFloat(item.lat),
        lng: parseFloat(item.lon),
        name: item.display_name.split(",").slice(0, 3).join(", "),
      }));
    } catch (error) {
      console.error("Geocoding error:", error);
      return [];
    }
  };

  // Debounced search for home
  useEffect(() => {
    if (homeDebounceRef.current) {
      clearTimeout(homeDebounceRef.current);
    }
    
    if (homeSearch.length >= 3) {
      setIsLoadingHome(true);
      homeDebounceRef.current = setTimeout(async () => {
        const results = await searchLocation(homeSearch);
        setHomeSuggestions(results);
        setIsLoadingHome(false);
      }, 500);
    } else {
      setHomeSuggestions([]);
    }
  }, [homeSearch]);

  // Debounced search for office
  useEffect(() => {
    if (officeDebounceRef.current) {
      clearTimeout(officeDebounceRef.current);
    }
    
    if (officeSearch.length >= 3) {
      setIsLoadingOffice(true);
      officeDebounceRef.current = setTimeout(async () => {
        const results = await searchLocation(officeSearch);
        setOfficeSuggestions(results);
        setIsLoadingOffice(false);
      }, 500);
    } else {
      setOfficeSuggestions([]);
    }
  }, [officeSearch]);

  // Calculate distance when both locations are set
  useEffect(() => {
    if (homeLocation && officeLocation) {
      const dist = getDistanceFromLatLonInKm(
        homeLocation.lat,
        homeLocation.lng,
        officeLocation.lat,
        officeLocation.lng
      );
      setDistance(dist);
    } else {
      setDistance(null);
    }
  }, [homeLocation, officeLocation]);

  const selectHomeLocation = (loc: Location) => {
    setHomeLocation(loc);
    setHomeSearch(loc.name);
    setHomeSuggestions([]);
  };

  const selectOfficeLocation = (loc: Location) => {
    setOfficeLocation(loc);
    setOfficeSearch(loc.name);
    setOfficeSuggestions([]);
  };

  const clearHome = () => {
    setHomeLocation(null);
    setHomeSearch("");
    setHomeSuggestions([]);
  };

  const clearOffice = () => {
    setOfficeLocation(null);
    setOfficeSearch("");
    setOfficeSuggestions([]);
  };

  const useCurrentLocation = () => {
    if (!navigator.geolocation) return;
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const loc: Location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          name: "Current Location",
        };
        setHomeLocation(loc);
        setHomeSearch("Current Location");
      },
      (error) => {
        console.error("Location error:", error);
      }
    );
  };

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold text-foreground">
          <Navigation className="h-5 w-5 text-primary" />
          Home to Office Distance
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Home Location */}
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">Home Location</span>
          </div>
          <div className="relative">
            <Input
              placeholder="Search your home area..."
              value={homeSearch}
              onChange={(e) => setHomeSearch(e.target.value)}
              className="pr-20"
            />
            <div className="absolute right-1 top-1/2 -translate-y-1/2 flex gap-1">
              {homeLocation && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0"
                  onClick={clearHome}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={useCurrentLocation}
              >
                <MapPin className="h-3 w-3" />
              </Button>
            </div>
          </div>
          {isLoadingHome && (
            <div className="mt-2 text-sm text-muted-foreground">Searching...</div>
          )}
          {homeSuggestions.length > 0 && (
            <div className="absolute z-10 w-full mt-1 bg-popover border border-border rounded-lg shadow-lg max-h-48 overflow-y-auto">
              {homeSuggestions.map((loc, idx) => (
                <button
                  key={idx}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-accent transition-colors border-b border-border last:border-0"
                  onClick={() => selectHomeLocation(loc)}
                >
                  {loc.name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Office Location */}
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <Building2 className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">Office Location</span>
          </div>
          <div className="relative">
            <Input
              placeholder="Search your office area..."
              value={officeSearch}
              onChange={(e) => setOfficeSearch(e.target.value)}
              className="pr-8"
            />
            {officeLocation && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 p-0"
                onClick={clearOffice}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          {isLoadingOffice && (
            <div className="mt-2 text-sm text-muted-foreground">Searching...</div>
          )}
          {officeSuggestions.length > 0 && (
            <div className="absolute z-10 w-full mt-1 bg-popover border border-border rounded-lg shadow-lg max-h-48 overflow-y-auto">
              {officeSuggestions.map((loc, idx) => (
                <button
                  key={idx}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-accent transition-colors border-b border-border last:border-0"
                  onClick={() => selectOfficeLocation(loc)}
                >
                  {loc.name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Distance Result */}
        {distance !== null && (
          <div className="mt-4 p-4 bg-primary/10 rounded-lg border border-primary/20">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-muted-foreground mb-1">Distance</div>
                <div className="text-2xl font-bold text-primary">
                  {distance.toFixed(1)} km
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-muted-foreground mb-1">Est. Travel Time</div>
                <div className="text-lg font-semibold text-foreground">
                  {estimateTravelTime(distance)}
                </div>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              * Estimated time based on average city traffic (25 km/h)
            </p>
          </div>
        )}

        {!distance && (
          <p className="text-xs text-muted-foreground text-center py-2">
            Enter both locations to calculate distance
          </p>
        )}
      </CardContent>
    </Card>
  );
};

export default DistanceCalculator;
