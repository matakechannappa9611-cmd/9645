import { useNavigate } from 'react-router-dom';
import { Heart, MapPin, Bed, Bath, Square, Star, Zap } from 'lucide-react';
import { Property } from '@/types/property';
import { useState } from 'react';

interface PropertyCardProps {
  property: Property;
  onSave?: (id: string) => void;
  showFeaturedBadge?: boolean;
  isBoosted?: boolean;
}

const PropertyCard = ({ property, onSave, showFeaturedBadge = false, isBoosted = false }: PropertyCardProps) => {
  const navigate = useNavigate();
  const [isSaved, setIsSaved] = useState(false);

  const formatPrice = (price: number) => {
    if (price >= 10000000) {
      return `₹${(price / 10000000).toFixed(1)} Cr`;
    } else if (price >= 100000) {
      return `₹${(price / 100000).toFixed(1)} L`;
    }
    return `₹${price.toLocaleString('en-IN')}`;
  };

  const getBadgeText = () => {
    if (property.type === 'BHK' && property.bhk) {
      return `${property.bhk}BHK`;
    }
    return property.type;
  };

  // Get badge color based on property type
  const getBadgeColor = () => {
    switch (property.type) {
      case 'PG':
        return 'bg-violet-500 text-white';
      case 'Hotel':
        return 'bg-amber-500 text-white';
      case 'Commercial':
        return 'bg-blue-600 text-white';
      case 'Plot':
        return 'bg-orange-500 text-white';
      case 'BHK':
      default:
        return 'bg-primary text-primary-foreground';
    }
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsSaved(!isSaved);
    onSave?.(property.id);
  };

  const handleClick = () => {
    navigate(`/property/${property.id}`);
  };

  // Determine top badge offset based on what badges are shown
  const getTypeBadgeTopClass = () => {
    if (isBoosted && (showFeaturedBadge || property.isFeatured)) return 'top-[5.5rem]';
    if (isBoosted || showFeaturedBadge || property.isFeatured) return 'top-12';
    return 'top-3';
  };

  return (
    <div 
      onClick={handleClick}
      className={`group bg-card rounded-xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300 cursor-pointer animate-fade-in ${
        isBoosted ? 'ring-2 ring-primary/50 ring-offset-2 ring-offset-background' : ''
      }`}
    >
      {/* Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={property.image}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        
        {/* Boost Badge */}
        {isBoosted && (
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-lg animate-pulse">
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span className="text-xs font-semibold">Boosted</span>
          </div>
        )}
        
        {/* Featured Star Badge */}
        {(showFeaturedBadge || property.isFeatured) && (
          <div className={`absolute ${isBoosted ? 'top-12' : 'top-3'} left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-400 to-yellow-500 text-white shadow-lg`}>
            <Star className="w-3.5 h-3.5 fill-white" />
            <span className="text-xs font-semibold">Featured</span>
          </div>
        )}

        {/* Property Type Badge with Color */}
        <span className={`absolute ${getTypeBadgeTopClass()} left-3 px-2.5 py-1 rounded-lg text-xs font-semibold ${getBadgeColor()}`}>
          {getBadgeText()}
        </span>

        {/* Save Button */}
        <button
          onClick={handleSave}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-card/90 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-colors"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isSaved ? 'fill-destructive text-destructive' : 'text-muted-foreground'
            }`}
          />
        </button>

        {/* Price Tag */}
        <div className="absolute bottom-3 left-3 px-3 py-1.5 rounded-lg bg-foreground/80 backdrop-blur-sm">
          <span className="text-background font-semibold">
            {formatPrice(property.price)}{property.priceUnit === 'mo' ? '/mo' : ''}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-semibold text-foreground truncate mb-2 group-hover:text-primary transition-colors">
          {property.title}
        </h3>
        
        <div className="flex items-center gap-1 text-muted-foreground text-sm mb-3">
          <MapPin className="w-4 h-4 text-primary flex-shrink-0" />
          <span className="truncate">{property.location}, {property.city}</span>
        </div>

        {/* Features */}
        <div className="flex items-center justify-start gap-3 text-sm text-muted-foreground">
          {property.bedrooms > 0 && (
            <div className="flex items-center gap-1">
              <Bed className="w-4 h-4 flex-shrink-0" />
              <span>{property.bedrooms}</span>
            </div>
          )}
          {property.bathrooms > 0 && (
            <div className="flex items-center gap-1">
              <Bath className="w-4 h-4 flex-shrink-0" />
              <span>{property.bathrooms}</span>
            </div>
          )}
          <div className="flex items-center gap-1">
            <Square className="w-4 h-4 flex-shrink-0" />
            <span>{property.sqft} sqft</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
