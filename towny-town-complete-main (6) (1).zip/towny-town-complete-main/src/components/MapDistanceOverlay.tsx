import { useState, useRef, useEffect } from "react";
import { Building2, Navigation, X, Route } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Location {
  lat: number;
  lng: number;
  name: string;
}

interface MapDistanceOverlayProps {
  userLocation: { lat: number; lng: number } | null;
  onOfficeLocationChange: (location: Location | null) => void;
}

// Calculate distance between two coordinates in km (Haversine formula)
const getDistanceFromLatLonInKm = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// Estimate travel time (assuming average speed of 25 km/h in city traffic)
const estimateTravelTime = (distanceKm: number): string => {
  const minutes = Math.round((distanceKm / 25) * 60);
  if (minutes < 60) {
    return `${minutes} min`;
  }
  const hours = Math.floor(minutes / 60);
  const remainingMins = minutes % 60;
  return `${hours}h ${remainingMins}m`;
};

const MapDistanceOverlay = ({ userLocation, onOfficeLocationChange }: MapDistanceOverlayProps) => {
  const [officeLocation, setOfficeLocation] = useState<Location | null>(null);
  const [officeSearch, setOfficeSearch] = useState("");
  const [officeSuggestions, setOfficeSuggestions] = useState<any[]>([]);
  const [isLoadingOffice, setIsLoadingOffice] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const officeDebounceRef = useRef<NodeJS.Timeout>();
  const containerRef = useRef<HTMLDivElement>(null);

  // Simple geocoding using Nominatim (free OpenStreetMap service)
  const searchLocation = async (query: string): Promise<any[]> => {
    if (!query || query.length < 3) return [];
    
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}, India&limit=5`
      );
      const data = await response.json();
      return data.map((item: any) => ({
        lat: parseFloat(item.lat),
        lng: parseFloat(item.lon),
        name: item.display_name.split(",").slice(0, 3).join(", "),
      }));
    } catch (error) {
      console.error("Geocoding error:", error);
      return [];
    }
  };

  // Debounced search for office
  useEffect(() => {
    if (officeDebounceRef.current) {
      clearTimeout(officeDebounceRef.current);
    }
    
    if (officeSearch.length >= 3 && !officeLocation) {
      setIsLoadingOffice(true);
      officeDebounceRef.current = setTimeout(async () => {
        const results = await searchLocation(officeSearch);
        setOfficeSuggestions(results);
        setIsLoadingOffice(false);
      }, 500);
    } else {
      setOfficeSuggestions([]);
    }
  }, [officeSearch, officeLocation]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOfficeSuggestions([]);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const selectOfficeLocation = (loc: Location) => {
    setOfficeLocation(loc);
    setOfficeSearch(loc.name);
    setOfficeSuggestions([]);
    onOfficeLocationChange(loc);
  };

  const clearOffice = () => {
    setOfficeLocation(null);
    setOfficeSearch("");
    setOfficeSuggestions([]);
    onOfficeLocationChange(null);
  };

  const distance = userLocation && officeLocation 
    ? getDistanceFromLatLonInKm(userLocation.lat, userLocation.lng, officeLocation.lat, officeLocation.lng)
    : null;

  if (!isExpanded) {
    return (
      <button
        onClick={() => setIsExpanded(true)}
        className="absolute top-3 left-3 z-10 bg-background/95 backdrop-blur-sm border border-border rounded-full px-3 py-2 shadow-lg flex items-center gap-2 hover:bg-accent transition-colors"
      >
        <Route className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium">Distance to Office</span>
      </button>
    );
  }

  return (
    <div 
      ref={containerRef}
      className="absolute top-3 left-3 z-10 bg-background/95 backdrop-blur-sm border border-border rounded-xl shadow-lg p-3 w-72"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Navigation className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold">Distance Calculator</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0"
          onClick={() => setIsExpanded(false)}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Your Location Display */}
      {userLocation ? (
        <div className="flex items-center gap-2 p-2 bg-primary/10 rounded-lg mb-2">
          <div className="w-3 h-3 rounded-full bg-primary animate-pulse" />
          <span className="text-xs text-foreground">Your Location Detected</span>
        </div>
      ) : (
        <div className="flex items-center gap-2 p-2 bg-muted rounded-lg mb-2">
          <div className="w-3 h-3 rounded-full bg-muted-foreground" />
          <span className="text-xs text-muted-foreground">Enable location to calculate</span>
        </div>
      )}

      {/* Office Location Search */}
      <div className="relative">
        <div className="flex items-center gap-2 mb-1">
          <Building2 className="h-3 w-3 text-primary" />
          <span className="text-xs font-medium">Office / Workplace</span>
        </div>
        <div className="relative">
          <Input
            placeholder="Search office location..."
            value={officeSearch}
            onChange={(e) => setOfficeSearch(e.target.value)}
            className="h-9 text-sm pr-8"
            disabled={!userLocation}
          />
          {officeLocation && (
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-1 top-1/2 -translate-y-1/2 h-6 w-6 p-0"
              onClick={clearOffice}
            >
              <X className="h-3 w-3" />
            </Button>
          )}
        </div>
        {isLoadingOffice && (
          <div className="mt-1 text-xs text-muted-foreground">Searching...</div>
        )}
        {officeSuggestions.length > 0 && (
          <div className="absolute z-20 w-full mt-1 bg-popover border border-border rounded-lg shadow-lg max-h-40 overflow-y-auto">
            {officeSuggestions.map((loc, idx) => (
              <button
                key={idx}
                className="w-full px-3 py-2 text-left text-xs hover:bg-accent transition-colors border-b border-border last:border-0"
                onClick={() => selectOfficeLocation(loc)}
              >
                {loc.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Distance Result */}
      {distance !== null && (
        <div className="mt-3 p-3 bg-primary/10 rounded-lg border border-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Distance</div>
              <div className="text-xl font-bold text-primary">
                {distance.toFixed(1)} km
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Travel</div>
              <div className="text-base font-semibold text-foreground">
                {estimateTravelTime(distance)}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MapDistanceOverlay;
