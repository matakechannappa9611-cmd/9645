import Header from "@/components/Header";
import Footer from "@/components/Footer";
import MobileNav from "@/components/MobileNav";
import { Rocket, TrendingUp, Heart, Briefcase, Mail } from "lucide-react";

const Careers = () => {
  const benefits = [
    { icon: Rocket, title: "Startup culture with ownership" },
    { icon: TrendingUp, title: "Learning and growth opportunities" },
    { icon: Heart, title: "Flexible and supportive environment" },
    { icon: Briefcase, title: "Work on meaningful products" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header activeTab="careers" onTabChange={() => {}} />
      
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <h1 className="text-4xl font-bold text-foreground mb-8">Careers</h1>
        
        <div className="space-y-6 text-muted-foreground">
          <p className="text-xl leading-relaxed font-medium text-foreground">
            Join Towny and help build the future of local discovery.
          </p>
          
          <p className="text-lg leading-relaxed">
            We're looking for passionate people who want to work on real-world problems and grow with a fast-moving startup. At Towny, your ideas matter and your work creates real impact.
          </p>
          
          <div className="pt-4">
            <h2 className="text-2xl font-semibold text-foreground mb-6">Why work with us:</h2>
            <ul className="space-y-4">
              {benefits.map((benefit, index) => (
                <li key={index} className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-lg">{benefit.title}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="pt-8 mt-8 border-t border-border">
            <div className="flex items-center gap-3 text-lg">
              <Mail className="w-6 h-6 text-primary" />
              <span>For career opportunities, email us at:</span>
              <a 
                href="mailto:townynow@gmail.com" 
                className="text-primary hover:underline font-medium"
              >
                townynow@gmail.com
              </a>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
      <MobileNav activeTab="careers" onTabChange={() => {}} />
    </div>
  );
};

export default Careers;
