import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Heart, 
  Share2, 
  MapPin, 
  Bed, 
  Bath, 
  Square, 
  Phone, 
  MessageCircle,
  Navigation,
  Calendar,
  Play,
  ChevronLeft,
  ChevronRight,
  X,
  User,
  Clock,
  Home,
  Check,
  CheckCheck,
  Send,
  Image as ImageIcon,
  Video,
  Paperclip,
  FileText,
  Smile,
  Mic
} from 'lucide-react';
import NearbyAmenities from '@/components/NearbyAmenities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { properties } from '@/data/properties';

interface ChatMessage {
  id: string;
  content: string;
  sender: 'me' | 'other';
  time: string;
  status: 'sent' | 'delivered' | 'read';
  type: 'text' | 'image' | 'video' | 'document';
  mediaUrl?: string;
}

const EMOJI_LIST = [
  '😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '😊',
  '😇', '🥰', '😍', '🤩', '😘', '😗', '😚', '😋', '😛', '😜',
  '🤪', '😝', '🤑', '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐',
  '😑', '😶', '😏', '😒', '🙄', '😬', '😮', '🤯', '😳', '🥺',
  '😢', '😭', '😤', '😠', '🤬', '😈', '👿', '💀', '☠️', '💩',
  '👍', '👎', '👏', '🙌', '🤝', '🙏', '💪', '❤️', '🧡', '💛',
  '💚', '💙', '💜', '🖤', '🤍', '💯', '✨', '🔥', '🎉', '🏠',
  '🏡', '🏢', '🏗️', '🔑', '🚪', '🛏️', '🛋️', '🚿', '🍳', '📍'
];

const PropertyDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showChatModal, setShowChatModal] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [ownerProfile, setOwnerProfile] = useState<{ name: string | null; avatar_url: string | null } | null>(null);
  const [propertyOwnerId, setPropertyOwnerId] = useState<string | null>(null);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  
  const [scheduleData, setScheduleData] = useState({
    name: '',
    phone: '',
    date: '',
    time: '',
    message: '',
  });

  const property = properties.find((p) => p.id === id);

  if (!property) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Property Not Found</h1>
          <Button onClick={() => navigate('/')}>Go Back Home</Button>
        </div>
      </div>
    );
  }

  // Mock additional images for gallery
  const images = [
    property.image,
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop',
  ];

  // Mock owner data
  const owner = {
    name: ownerProfile?.name || 'Property Owner',
    phone: '+91 98765 43210',
    whatsapp: '919876543210',
    verified: true,
  };

  // Fetch property from database and get owner info
  useEffect(() => {
    const fetchPropertyOwner = async () => {
      if (!id) return;
      
      // Try to get property from database first
      const { data: dbProperty } = await supabase
        .from('properties')
        .select('user_id')
        .eq('id', id)
        .single();
      
      if (dbProperty?.user_id) {
        setPropertyOwnerId(dbProperty.user_id);
        
        // Fetch owner profile
        const { data: profile } = await supabase
          .from('profiles')
          .select('name, avatar_url')
          .eq('user_id', dbProperty.user_id)
          .single();
        
        if (profile) {
          setOwnerProfile(profile);
        }
      }
    };
    
    fetchPropertyOwner();
  }, [id]);

  // Fetch messages when chat opens
  useEffect(() => {
    const fetchMessages = async () => {
      if (!showChatModal || !user || !propertyOwnerId) return;
      
      setIsLoadingMessages(true);
      
      const { data: messages, error } = await supabase
        .from('messages')
        .select('*')
        .eq('property_id', id)
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order('created_at', { ascending: true });
      
      if (!error && messages) {
        const formattedMessages: ChatMessage[] = messages.map((msg) => ({
          id: msg.id,
          content: msg.content,
          sender: msg.sender_id === user.id ? 'me' : 'other',
          time: new Date(msg.created_at).toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit' 
          }),
          status: msg.is_read ? 'read' : 'delivered',
          type: 'text',
        }));
        setChatMessages(formattedMessages);
      }
      
      setIsLoadingMessages(false);
    };
    
    fetchMessages();
  }, [showChatModal, user, propertyOwnerId, id]);

  // Set up real-time subscription for messages
  useEffect(() => {
    if (!showChatModal || !user || !propertyOwnerId) return;
    
    const channel = supabase
      .channel(`messages-${id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `property_id=eq.${id}`,
        },
        (payload) => {
          const newMsg = payload.new as any;
          if (newMsg.sender_id !== user.id) {
            setChatMessages((prev) => [
              ...prev,
              {
                id: newMsg.id,
                content: newMsg.content,
                sender: 'other',
                time: new Date(newMsg.created_at).toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit',
                }),
                status: 'delivered',
                type: 'text',
              },
            ]);
          }
        }
      )
      .subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, [showChatModal, user, propertyOwnerId, id]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const formatPrice = (price: number) => {
    if (price >= 10000000) {
      return `₹${(price / 10000000).toFixed(1)} Cr`;
    } else if (price >= 100000) {
      return `₹${(price / 100000).toFixed(1)} L`;
    }
    return `₹${price.toLocaleString('en-IN')}`;
  };

  const handlePrevImage = () => {
    setCurrentImageIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  const handleMessage = async () => {
    if (!user) {
      toast({
        title: 'Please login',
        description: 'You need to login to message the owner',
        variant: 'destructive',
      });
      navigate('/auth');
      return;
    }
    
    setShowChatModal(true);
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !user || !propertyOwnerId) return;
    
    const messageContent = newMessage.trim();
    setNewMessage('');
    
    // Optimistically add message to UI
    const tempId = `temp-${Date.now()}`;
    const tempMessage: ChatMessage = {
      id: tempId,
      content: messageContent,
      sender: 'me',
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      type: 'text',
    };
    setChatMessages((prev) => [...prev, tempMessage]);
    
    // Send to database
    const { data, error } = await supabase
      .from('messages')
      .insert({
        content: messageContent,
        sender_id: user.id,
        receiver_id: propertyOwnerId,
        property_id: id,
      })
      .select()
      .single();
    
    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to send message',
        variant: 'destructive',
      });
      // Remove optimistic message on error
      setChatMessages((prev) => prev.filter((m) => m.id !== tempId));
    } else if (data) {
      // Update with real message
      setChatMessages((prev) =>
        prev.map((m) =>
          m.id === tempId
            ? { ...m, id: data.id, status: 'delivered' }
            : m
        )
      );
    }
  };

  const handleFileUpload = (type: 'image' | 'video' | 'document') => {
    setShowAttachMenu(false);
    const icons = {
      image: '📷',
      video: '🎥',
      document: '📄'
    };
    const labels = {
      image: 'Image',
      video: 'Video',
      document: 'Document'
    };
    
    const message: ChatMessage = {
      id: `${Date.now()}`,
      content: `${icons[type]} ${labels[type]}`,
      sender: 'me',
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      type,
    };
    setChatMessages((prev) => [...prev, message]);
    
    setTimeout(() => {
      setChatMessages((prev) =>
        prev.map((m) => (m.id === message.id ? { ...m, status: 'delivered' } : m))
      );
    }, 500);
    
    toast({
      title: `${labels[type]} sent`,
      description: `Your ${type} has been sent to the owner`,
    });
  };

  const handleEmojiSelect = (emoji: string) => {
    setNewMessage((prev) => prev + emoji);
    setShowEmojiPicker(false);
  };

  const renderMessageStatus = (status: ChatMessage['status']) => {
    if (status === 'sent') return <Check className="w-3 h-3 text-primary-foreground/70" />;
    if (status === 'delivered') return <CheckCheck className="w-3 h-3 text-primary-foreground/70" />;
    if (status === 'read') return <CheckCheck className="w-3 h-3 text-primary-foreground" />;
    return null;
  };

  const getInitials = (name: string | null) => {
    if (!name) return 'O';
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleCall = () => {
    window.open(`tel:${owner.phone}`, '_self');
  };

  const handleNavigation = () => {
    if (property.coordinates) {
      window.open(
        `https://www.google.com/maps/dir/?api=1&destination=${property.coordinates.lat},${property.coordinates.lng}`,
        '_blank'
      );
    } else {
      window.open(
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(property.location + ', ' + property.city)}`,
        '_blank'
      );
    }
  };

  const handleShare = async () => {
    try {
      await navigator.share({
        title: property.title,
        text: `Check out this property: ${property.title} at ${formatPrice(property.price)}`,
        url: window.location.href,
      });
    } catch {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: 'Link copied!',
        description: 'Property link has been copied to clipboard',
      });
    }
  };

  const handleScheduleVisit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: 'Visit Scheduled!',
      description: `Your visit has been scheduled for ${scheduleData.date} at ${scheduleData.time}`,
    });
    setShowScheduleModal(false);
    setScheduleData({ name: '', phone: '', date: '', time: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-14">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 text-foreground hover:text-primary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back</span>
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsSaved(!isSaved)}
                className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
              >
                <Heart className={`w-5 h-5 ${isSaved ? 'fill-destructive text-destructive' : 'text-foreground'}`} />
              </button>
              <button
                onClick={handleShare}
                className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
              >
                <Share2 className="w-5 h-5 text-foreground" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Images & Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <div className="relative rounded-xl overflow-hidden bg-muted aspect-[16/10]">
              <img
                src={images[currentImageIndex]}
                alt={property.title}
                className="w-full h-full object-cover"
              />
              
              {/* Image Navigation */}
              <button
                onClick={handlePrevImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-card/90 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNextImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-card/90 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>

              {/* Image Counter */}
              <div className="absolute bottom-4 left-4 px-3 py-1.5 rounded-full bg-foreground/80 text-background text-sm font-medium">
                {currentImageIndex + 1} / {images.length}
              </div>

              {/* Video Button */}
              <button
                onClick={() => setShowVideoModal(true)}
                className="absolute bottom-4 right-4 flex items-center gap-2 px-4 py-2 rounded-full bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
              >
                <Play className="w-4 h-4" />
                Watch Video
              </button>
            </div>

            {/* Thumbnail Strip */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              {images.map((img, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`flex-shrink-0 w-20 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                    index === currentImageIndex ? 'border-primary' : 'border-transparent'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>

            {/* Property Info */}
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <span className="inline-block px-3 py-1 rounded-full bg-primary text-primary-foreground text-sm font-medium mb-2">
                    {property.bhk ? `${property.bhk}BHK` : property.type}
                  </span>
                  <h1 className="text-2xl font-bold text-foreground">{property.title}</h1>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-primary">
                    {formatPrice(property.price)}
                    <span className="text-base font-normal text-muted-foreground">
                      {property.priceUnit === 'mo' ? '/month' : ''}
                    </span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="w-5 h-5 text-primary" />
                <span>{property.location}, {property.city}</span>
              </div>

              {/* Features */}
              <div className="flex items-center gap-6 py-4 border-y border-border">
                {property.bedrooms > 0 && (
                  <div className="flex items-center gap-2">
                    <Bed className="w-5 h-5 text-muted-foreground" />
                    <span className="font-medium">{property.bedrooms} Bedrooms</span>
                  </div>
                )}
                {property.bathrooms > 0 && (
                  <div className="flex items-center gap-2">
                    <Bath className="w-5 h-5 text-muted-foreground" />
                    <span className="font-medium">{property.bathrooms} Bathrooms</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Square className="w-5 h-5 text-muted-foreground" />
                  <span className="font-medium">{property.sqft} sqft</span>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-3">
              <h2 className="text-lg font-semibold text-foreground">Description</h2>
              <p className="text-muted-foreground leading-relaxed">
                This beautiful {property.bhk ? `${property.bhk}BHK` : ''} property is located in the heart of {property.location}, {property.city}. 
                It offers spacious rooms with excellent ventilation and natural lighting. The property is well-maintained and comes with modern amenities. 
                Close proximity to schools, hospitals, shopping centers, and public transportation makes this an ideal choice for families.
              </p>
            </div>

            {/* Property Amenities */}
            <div className="space-y-3">
              <h2 className="text-lg font-semibold text-foreground">Amenities</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {['24/7 Security', 'Power Backup', 'Parking', 'Gym', 'Swimming Pool', 'Lift'].map((amenity) => (
                  <div key={amenity} className="flex items-center gap-2 p-3 rounded-lg bg-muted">
                    <Check className="w-4 h-4 text-primary" />
                    <span className="text-sm">{amenity}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* AI-Powered Nearby Amenities */}
            <div className="space-y-3">
              <h2 className="text-lg font-semibold text-foreground">Explore Neighborhood</h2>
              <NearbyAmenities 
                location={property.location} 
                city={property.city}
                coordinates={property.coordinates}
              />
            </div>
          </div>

          {/* Right Column - Contact & Actions */}
          <div className="space-y-6">
            {/* Owner Card */}
            <div className="bg-card rounded-xl border border-border p-6 space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="w-7 h-7 text-primary" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground">{owner.name}</h3>
                    {owner.verified && (
                      <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium">
                        Verified
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">Property Owner</p>
                </div>
              </div>

              {/* Contact Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <Button onClick={handleCall} variant="outline" className="gap-2">
                  <Phone className="w-4 h-4" />
                  Call
                </Button>
                <Button onClick={handleMessage} className="gap-2">
                  <MessageCircle className="w-4 h-4" />
                  Message
                </Button>
              </div>

              {/* Phone Number */}
              <button
                onClick={() => setShowContactModal(true)}
                className="w-full py-3 rounded-lg border border-border text-center font-medium hover:bg-muted transition-colors"
              >
                View Contact Number
              </button>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button
                onClick={() => setShowScheduleModal(true)}
                className="w-full gap-2 h-12"
              >
                <Calendar className="w-5 h-5" />
                Schedule Visit
              </Button>

              <Button
                onClick={handleNavigation}
                variant="outline"
                className="w-full gap-2 h-12"
              >
                <Navigation className="w-5 h-5" />
                Get Directions
              </Button>
            </div>

            {/* Quick Info */}
            <div className="bg-muted rounded-xl p-4 space-y-3">
              <h3 className="font-semibold text-foreground">Quick Info</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Property Type</span>
                  <span className="font-medium">{property.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Furnishing</span>
                  <span className="font-medium">Semi-Furnished</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Available From</span>
                  <span className="font-medium">Immediate</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Posted On</span>
                  <span className="font-medium">Dec 20, 2025</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Schedule Visit Modal */}
      <Dialog open={showScheduleModal} onOpenChange={setShowScheduleModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Schedule a Visit</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleScheduleVisit} className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="name">Your Name</Label>
              <Input
                id="name"
                placeholder="Enter your name"
                value={scheduleData.name}
                onChange={(e) => setScheduleData({ ...scheduleData, name: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+91 98765 43210"
                value={scheduleData.phone}
                onChange={(e) => setScheduleData({ ...scheduleData, phone: e.target.value })}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Preferred Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={scheduleData.date}
                  onChange={(e) => setScheduleData({ ...scheduleData, date: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="time">Preferred Time</Label>
                <Input
                  id="time"
                  type="time"
                  value={scheduleData.time}
                  onChange={(e) => setScheduleData({ ...scheduleData, time: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="message">Message (Optional)</Label>
              <Textarea
                id="message"
                placeholder="Any specific requirements..."
                value={scheduleData.message}
                onChange={(e) => setScheduleData({ ...scheduleData, message: e.target.value })}
                className="resize-none"
              />
            </div>
            <Button type="submit" className="w-full">
              Confirm Visit
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Contact Number Modal */}
      <Dialog open={showContactModal} onOpenChange={setShowContactModal}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Contact Details</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
              <Phone className="w-6 h-6 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Phone Number</p>
                <p className="font-semibold text-lg">{owner.phone}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Button onClick={handleCall} variant="outline" className="gap-2">
                <Phone className="w-4 h-4" />
                Call Now
              </Button>
              <Button onClick={handleMessage} className="gap-2">
                <MessageCircle className="w-4 h-4" />
                Message
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Video Modal */}
      <Dialog open={showVideoModal} onOpenChange={setShowVideoModal}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Property Video Tour</DialogTitle>
          </DialogHeader>
          <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mt-4">
            <div className="text-center">
              <Play className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Video tour coming soon</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* WhatsApp-style Chat Modal */}
      <Dialog open={showChatModal} onOpenChange={setShowChatModal}>
        <DialogContent className="max-w-md h-[600px] flex flex-col p-0 overflow-hidden">
          {/* Chat Header - Primary Green */}
          <div className="flex items-center gap-3 p-4 bg-primary text-primary-foreground">
            <button
              onClick={() => setShowChatModal(false)}
              className="p-1 hover:bg-primary-foreground/10 rounded-full transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <Avatar className="w-10 h-10 border-2 border-primary-foreground/20">
              <AvatarImage src={ownerProfile?.avatar_url || ''} />
              <AvatarFallback className="bg-primary-foreground/20 text-primary-foreground">
                {getInitials(owner.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold truncate">{owner.name}</h3>
              <p className="text-xs text-primary-foreground/70">
                {property.title}
              </p>
            </div>
            <Phone className="w-5 h-5 cursor-pointer hover:opacity-80" onClick={handleCall} />
          </div>

          {/* Chat Messages - Light green tinted background */}
          <ScrollArea 
            className="flex-1 p-4 bg-primary/5"
            ref={scrollAreaRef}
          >
            {isLoadingMessages ? (
              <div className="flex items-center justify-center h-full">
                <p className="text-muted-foreground">Loading messages...</p>
              </div>
            ) : chatMessages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <MessageCircle className="w-8 h-8 text-primary" />
                </div>
                <p className="font-medium text-foreground">No messages yet</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Start the conversation about this property
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {chatMessages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'me' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-2 shadow-sm ${
                        message.sender === 'me'
                          ? 'bg-primary text-primary-foreground rounded-br-sm'
                          : 'bg-card text-foreground border border-border rounded-bl-sm'
                      }`}
                    >
                      {message.type === 'image' && (
                        <div className="flex items-center gap-2 mb-1">
                          <ImageIcon className="w-5 h-5" />
                        </div>
                      )}
                      {message.type === 'video' && (
                        <div className="flex items-center gap-2 mb-1">
                          <Video className="w-5 h-5" />
                        </div>
                      )}
                      {message.type === 'document' && (
                        <div className="flex items-center gap-2 mb-1">
                          <FileText className="w-5 h-5" />
                        </div>
                      )}
                      <p className="text-sm break-words">{message.content}</p>
                      <div className="flex items-center justify-end gap-1 mt-1">
                        <span className={`text-[10px] ${message.sender === 'me' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                          {message.time}
                        </span>
                        {message.sender === 'me' && renderMessageStatus(message.status)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Chat Input - Green themed */}
          <div className="p-3 bg-primary/5 border-t border-primary/10">
            {/* Hidden file inputs */}
            <input
              type="file"
              accept="image/*"
              className="hidden"
              ref={fileInputRef}
              onChange={() => handleFileUpload('image')}
            />
            <input
              type="file"
              accept="video/*"
              className="hidden"
              ref={videoInputRef}
              onChange={() => handleFileUpload('video')}
            />
            <input
              type="file"
              accept=".pdf,.doc,.docx,.txt,.xls,.xlsx"
              className="hidden"
              ref={documentInputRef}
              onChange={() => handleFileUpload('document')}
            />

            <div className="flex items-center gap-2">
              {/* Emoji Picker */}
              <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
                <PopoverTrigger asChild>
                  <button className="p-2 hover:bg-primary/10 rounded-full transition-colors">
                    <Smile className="w-5 h-5 text-primary" />
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-72 p-2" align="start" side="top">
                  <div className="grid grid-cols-8 gap-1">
                    {EMOJI_LIST.map((emoji, index) => (
                      <button
                        key={index}
                        onClick={() => handleEmojiSelect(emoji)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-primary/10 rounded transition-colors text-lg"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>

              {/* Attachment Menu */}
              <Popover open={showAttachMenu} onOpenChange={setShowAttachMenu}>
                <PopoverTrigger asChild>
                  <button className="p-2 hover:bg-primary/10 rounded-full transition-colors">
                    <Paperclip className="w-5 h-5 text-primary" />
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-48 p-2" align="start" side="top">
                  <div className="space-y-1">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full flex items-center gap-3 p-2 hover:bg-primary/10 rounded-lg transition-colors"
                    >
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <ImageIcon className="w-5 h-5 text-primary" />
                      </div>
                      <span className="text-sm font-medium">Image</span>
                    </button>
                    <button
                      onClick={() => videoInputRef.current?.click()}
                      className="w-full flex items-center gap-3 p-2 hover:bg-primary/10 rounded-lg transition-colors"
                    >
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Video className="w-5 h-5 text-primary" />
                      </div>
                      <span className="text-sm font-medium">Video</span>
                    </button>
                    <button
                      onClick={() => documentInputRef.current?.click()}
                      className="w-full flex items-center gap-3 p-2 hover:bg-primary/10 rounded-lg transition-colors"
                    >
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <FileText className="w-5 h-5 text-primary" />
                      </div>
                      <span className="text-sm font-medium">Document</span>
                    </button>
                  </div>
                </PopoverContent>
              </Popover>
              
              {/* Message Input */}
              <Input
                placeholder="Type a message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                className="flex-1 border-primary/20 bg-background focus-visible:ring-primary"
              />
              
              {/* Send Button */}
              <Button
                onClick={handleSendMessage}
                size="icon"
                className="rounded-full h-10 w-10 bg-primary hover:bg-primary/90"
                disabled={!newMessage.trim()}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PropertyDetails;
