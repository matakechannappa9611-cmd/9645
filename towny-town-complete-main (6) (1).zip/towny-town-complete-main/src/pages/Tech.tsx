import Header from "@/components/Header";
import Footer from "@/components/Footer";
import MobileNav from "@/components/MobileNav";
import { Zap, Shield, TrendingUp, MapPin, RefreshCw } from "lucide-react";

const Tech = () => {
  const features = [
    { icon: Zap, title: "Fast and smooth performance" },
    { icon: Shield, title: "Strong security and user privacy" },
    { icon: TrendingUp, title: "Scalable systems that grow with users and towns" },
    { icon: MapPin, title: "Smart location-based search" },
    { icon: RefreshCw, title: "Regular improvements based on user feedback" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header activeTab="tech" onTabChange={() => {}} />
      
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <h1 className="text-4xl font-bold text-foreground mb-8">Tech@Towny</h1>
        
        <div className="space-y-6 text-muted-foreground">
          <p className="text-lg leading-relaxed">
            Towny is built with modern technology to provide a fast, secure, and reliable experience for everyone.
          </p>
          
          <div className="pt-4">
            <h2 className="text-2xl font-semibold text-foreground mb-6">Our focus includes:</h2>
            <ul className="space-y-4">
              {features.map((feature, index) => (
                <li key={index} className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-lg">{feature.title}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <p className="text-lg leading-relaxed pt-6 border-t border-border mt-8">
            We believe great technology should work quietly in the background while delivering simple and powerful results.
          </p>
        </div>
      </main>
      
      <Footer />
      <MobileNav activeTab="tech" onTabChange={() => {}} />
    </div>
  );
};

export default Tech;
