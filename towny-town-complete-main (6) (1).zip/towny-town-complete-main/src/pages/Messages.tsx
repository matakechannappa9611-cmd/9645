import { useState, useEffect, useRef } from 'react';
import { MessageSquare, Send, Loader2 } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import MobileNav from '@/components/MobileNav';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

type Message = {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  property_id: string | null;
  is_read: boolean;
  created_at: string;
};

type Profile = {
  user_id: string;
  name: string | null;
  avatar_url: string | null;
};

type Conversation = {
  partnerId: string;
  partnerName: string;
  partnerAvatar: string | null;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
};

const Messages = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [profiles, setProfiles] = useState<Map<string, Profile>>(new Map());
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleTabChange = (tab: string) => {
    if (tab === 'home') navigate('/');
    else if (tab === 'messaging') navigate('/messages');
    else if (tab === 'notifications') navigate('/notifications');
    else if (tab === 'saved') navigate('/saved');
  };

  const getInitials = (name: string | null) => {
    if (!name) return '?';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  // Fetch conversations
  useEffect(() => {
    if (!user) return;

    const fetchConversations = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('messages')
          .select('*')
          .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
          .order('created_at', { ascending: false });

        if (error) throw error;

        // Get unique partner IDs
        const partnerIds = new Set<string>();
        data?.forEach((msg) => {
          const partnerId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
          partnerIds.add(partnerId);
        });

        // Fetch profiles for all partners
        if (partnerIds.size > 0) {
          const { data: profilesData } = await supabase
            .from('profiles')
            .select('user_id, name, avatar_url')
            .in('user_id', Array.from(partnerIds));

          const profileMap = new Map<string, Profile>();
          profilesData?.forEach((p) => {
            profileMap.set(p.user_id, p);
          });
          setProfiles(profileMap);
        }

        // Group messages by conversation partner
        const convMap = new Map<string, Conversation>();
        data?.forEach((msg) => {
          const partnerId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
          if (!convMap.has(partnerId)) {
            const profile = profiles.get(partnerId);
            convMap.set(partnerId, {
              partnerId,
              partnerName: profile?.name || `User ${partnerId.slice(0, 8)}`,
              partnerAvatar: profile?.avatar_url || null,
              lastMessage: msg.content,
              lastMessageTime: msg.created_at,
              unreadCount: msg.receiver_id === user.id && !msg.is_read ? 1 : 0,
            });
          } else if (msg.receiver_id === user.id && !msg.is_read) {
            const conv = convMap.get(partnerId)!;
            conv.unreadCount++;
          }
        });

        // Update conversation names with fetched profiles
        const { data: latestProfiles } = await supabase
          .from('profiles')
          .select('user_id, name, avatar_url')
          .in('user_id', Array.from(partnerIds));

        latestProfiles?.forEach((p) => {
          if (convMap.has(p.user_id)) {
            const conv = convMap.get(p.user_id)!;
            conv.partnerName = p.name || conv.partnerName;
            conv.partnerAvatar = p.avatar_url;
          }
        });

        setConversations(Array.from(convMap.values()));
      } catch (error) {
        console.error('Error fetching conversations:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchConversations();
  }, [user]);

  // Fetch messages for selected conversation
  useEffect(() => {
    if (!user || !selectedConversation) return;

    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .or(`and(sender_id.eq.${user.id},receiver_id.eq.${selectedConversation}),and(sender_id.eq.${selectedConversation},receiver_id.eq.${user.id})`)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error fetching messages:', error);
        return;
      }

      setMessages(data || []);

      // Mark messages as read
      await supabase
        .from('messages')
        .update({ is_read: true })
        .eq('sender_id', selectedConversation)
        .eq('receiver_id', user.id);
    };

    fetchMessages();
  }, [user, selectedConversation]);

  // Real-time subscription
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('messages-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
        },
        (payload) => {
          const newMsg = payload.new as Message;
          
          // Only add if it's part of current conversation
          if (
            selectedConversation &&
            ((newMsg.sender_id === user.id && newMsg.receiver_id === selectedConversation) ||
             (newMsg.sender_id === selectedConversation && newMsg.receiver_id === user.id))
          ) {
            setMessages((prev) => [...prev, newMsg]);
          }

          // Show toast for new messages from others
          if (newMsg.receiver_id === user.id && newMsg.sender_id !== selectedConversation) {
            toast({
              title: 'New message',
              description: newMsg.content.slice(0, 50) + (newMsg.content.length > 50 ? '...' : ''),
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, selectedConversation, toast]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || !selectedConversation || isSending) return;

    setIsSending(true);
    try {
      const { error } = await supabase.from('messages').insert({
        sender_id: user.id,
        receiver_id: selectedConversation,
        content: newMessage.trim(),
      });

      if (error) throw error;
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: 'Error',
        description: 'Failed to send message',
        variant: 'destructive',
      });
    } finally {
      setIsSending(false);
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background pb-16 md:pb-0">
        <Header activeTab="messaging" onTabChange={handleTabChange} />
        <main className="container mx-auto px-4 py-12">
          <div className="flex flex-col items-center justify-center text-center">
            <MessageSquare className="w-16 h-16 text-muted-foreground mb-4" />
            <h1 className="text-2xl font-bold text-foreground mb-2">Messages</h1>
            <p className="text-muted-foreground mb-6">Please login to view your messages</p>
            <Button onClick={() => navigate('/auth')}>Login</Button>
          </div>
        </main>
        <Footer />
        <MobileNav activeTab="messaging" onTabChange={handleTabChange} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16 md:pb-0">
      <Header activeTab="messaging" onTabChange={handleTabChange} />
      <main className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold text-foreground mb-6">Messages</h1>
        
        <div className="bg-card border border-border rounded-xl overflow-hidden h-[600px] grid grid-cols-1 md:grid-cols-3">
          {/* Conversations List */}
          <div className="border-r border-border">
            <div className="p-4 border-b border-border">
              <h2 className="font-semibold">Conversations</h2>
            </div>
            <ScrollArea className="h-[calc(600px-57px)]">
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              ) : conversations.length === 0 ? (
                <div className="p-4 text-center text-muted-foreground text-sm">
                  No conversations yet
                </div>
              ) : (
                conversations.map((conv) => (
                  <button
                    key={conv.partnerId}
                    onClick={() => setSelectedConversation(conv.partnerId)}
                    className={`w-full p-4 flex items-center gap-3 hover:bg-muted/50 transition-colors border-b border-border ${
                      selectedConversation === conv.partnerId ? 'bg-muted' : ''
                    }`}
                  >
                    <Avatar className="w-10 h-10 flex-shrink-0">
                      <AvatarImage src={conv.partnerAvatar || undefined} alt={conv.partnerName} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {getInitials(conv.partnerName)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 text-left min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium truncate">{conv.partnerName}</p>
                        <span className="text-xs text-muted-foreground">
                          {formatTime(conv.lastMessageTime)}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{conv.lastMessage}</p>
                    </div>
                    {conv.unreadCount > 0 && (
                      <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                        {conv.unreadCount}
                      </span>
                    )}
                  </button>
                ))
              )}
            </ScrollArea>
          </div>

          {/* Chat Area */}
          <div className="md:col-span-2 flex flex-col">
            {selectedConversation ? (
              (() => {
                const selectedProfile = conversations.find(c => c.partnerId === selectedConversation);
                return (
                  <>
                    {/* Chat Header */}
                    <div className="p-4 border-b border-border flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={selectedProfile?.partnerAvatar || undefined} alt={selectedProfile?.partnerName} />
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {getInitials(selectedProfile?.partnerName || null)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold">{selectedProfile?.partnerName || `User ${selectedConversation.slice(0, 8)}`}</p>
                        <p className="text-xs text-green-500">Online</p>
                      </div>
                    </div>

                {/* Messages */}
                <ScrollArea className="flex-1 p-4" ref={scrollRef}>
                  <div className="space-y-4">
                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.sender_id === user.id ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[70%] px-4 py-2 rounded-2xl ${
                            msg.sender_id === user.id
                              ? 'bg-primary text-primary-foreground rounded-br-md'
                              : 'bg-muted text-foreground rounded-bl-md'
                          }`}
                        >
                          <p className="text-sm">{msg.content}</p>
                          <p className={`text-xs mt-1 ${
                            msg.sender_id === user.id ? 'text-primary-foreground/70' : 'text-muted-foreground'
                          }`}>
                            {formatTime(msg.created_at)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {/* Input */}
                <form onSubmit={handleSendMessage} className="p-4 border-t border-border">
                  <div className="flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type a message..."
                      className="flex-1 rounded-full"
                      disabled={isSending}
                    />
                    <Button
                      type="submit"
                      size="icon"
                      className="rounded-full"
                      disabled={isSending || !newMessage.trim()}
                    >
                      {isSending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </form>
                  </>
                );
              })()
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
                <MessageSquare className="w-12 h-12 mb-4 opacity-50" />
                <p>Select a conversation to start messaging</p>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
      <MobileNav activeTab="messaging" onTabChange={handleTabChange} />
    </div>
  );
};

export default Messages;
