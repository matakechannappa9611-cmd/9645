import { Bell } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import MobileNav from '@/components/MobileNav';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';

const Notifications = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleTabChange = (tab: string) => {
    if (tab === 'home') navigate('/');
    else if (tab === 'messaging') navigate('/messages');
    else if (tab === 'notifications') navigate('/notifications');
    else if (tab === 'saved') navigate('/saved');
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background pb-16 md:pb-0">
        <Header activeTab="notifications" onTabChange={handleTabChange} />
        <main className="container mx-auto px-4 py-12">
          <div className="flex flex-col items-center justify-center text-center">
            <Bell className="w-16 h-16 text-muted-foreground mb-4" />
            <h1 className="text-2xl font-bold text-foreground mb-2">Notifications</h1>
            <p className="text-muted-foreground mb-6">Please login to view your notifications</p>
            <Button onClick={() => navigate('/auth')}>Login</Button>
          </div>
        </main>
        <Footer />
        <MobileNav activeTab="notifications" onTabChange={handleTabChange} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16 md:pb-0">
      <Header activeTab="notifications" onTabChange={handleTabChange} />
      <main className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold text-foreground mb-6">Notifications</h1>
        
        <div className="bg-card border border-border rounded-xl p-8 text-center">
          <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No notifications yet</p>
          <p className="text-sm text-muted-foreground mt-2">
            You'll receive updates about properties and messages here
          </p>
        </div>
      </main>
      <Footer />
      <MobileNav activeTab="notifications" onTabChange={handleTabChange} />
    </div>
  );
};

export default Notifications;