import Header from "@/components/Header";
import Footer from "@/components/Footer";
import MobileNav from "@/components/MobileNav";
import { Mail, Phone, MessageCircle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const Help = () => {
  const faqs = [
    {
      question: "How do I post a property on Towny?",
      answer: "Click on the 'Post Property' button in the header, fill in the property details, upload images, and submit. Your listing will be live once verified.",
    },
    {
      question: "Is it free to list a property?",
      answer: "Yes, basic property listings on Towny are completely free. Premium features may be available for enhanced visibility.",
    },
    {
      question: "How do I contact a property owner?",
      answer: "Click on any property listing to view details, then use the contact options provided to reach out to the owner directly.",
    },
    {
      question: "How can I save properties I like?",
      answer: "Click the heart icon on any property card to save it to your favorites. You can view all saved properties in your profile.",
    },
    {
      question: "What areas does Towny cover?",
      answer: "Towny currently operates in major cities across India, with a focus on Bangalore, Mumbai, Delhi, and other metropolitan areas.",
    },
    {
      question: "How do I report a suspicious listing?",
      answer: "If you find a listing that seems fraudulent or suspicious, please contact us immediately at townynow@gmail.com with the listing details.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header activeTab="help" onTabChange={() => {}} />
      
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <h1 className="text-4xl font-bold text-foreground mb-4">Help Center</h1>
        <p className="text-lg text-muted-foreground mb-8">
          Find answers to common questions or reach out to our support team.
        </p>
        
        {/* FAQ Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-semibold text-foreground mb-6">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        
        {/* Contact Section */}
        <div className="border-t border-border pt-8">
          <h2 className="text-2xl font-semibold text-foreground mb-6">Still need help?</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <a 
              href="mailto:townynow@gmail.com"
              className="flex items-center gap-3 p-4 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Mail className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Email Us</p>
                <p className="text-sm text-muted-foreground">townynow@gmail.com</p>
              </div>
            </a>
            
            <a 
              href="https://wa.me/919743591156"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-4 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">WhatsApp</p>
                <p className="text-sm text-muted-foreground">Chat with us</p>
              </div>
            </a>
            
            <a 
              href="tel:+919743591156"
              className="flex items-center gap-3 p-4 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Phone className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Call Us</p>
                <p className="text-sm text-muted-foreground">+91 97435 91156</p>
              </div>
            </a>
          </div>
        </div>
      </main>
      
      <Footer />
      <MobileNav activeTab="help" onTabChange={() => {}} />
    </div>
  );
};

export default Help;
