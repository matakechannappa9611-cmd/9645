import { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, Home, Building2, Users, Phone, Gift } from 'lucide-react';
import townyLogo from '@/assets/towny-logo.png';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { supabase } from '@/integrations/supabase/client';
import { setupRecaptcha, sendPhoneOTP, verifyPhoneOTP } from '@/lib/firebase';

type AuthMode = 'login' | 'signup' | 'otp' | 'verify-otp' | 'phone' | 'verify-phone' | 'signup-phone' | 'signup-verify-phone';

const Auth = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const referralCode = searchParams.get('ref');
  const { toast } = useToast();
  const { user, signIn, signUp, loading } = useAuth();
  const [authMode, setAuthMode] = useState<AuthMode>(referralCode ? 'signup' : 'login');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [resendTimer, setResendTimer] = useState(0);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    phone: '',
  });

  // Initialize reCAPTCHA ONCE on page load
  useEffect(() => {
    setupRecaptcha('recaptcha-container');
  }, []);

  // Redirect if already logged in
  useEffect(() => {
    if (user && !loading) {
      navigate('/');
    }
  }, [user, loading, navigate]);

  // Countdown timer for resend OTP
  useEffect(() => {
    if (resendTimer > 0) {
      const interval = setInterval(() => {
        setResendTimer((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [resendTimer]);

  const startResendTimer = () => {
    setResendTimer(60);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.email || !formData.password) {
      toast({
        title: 'Missing fields',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    if (authMode === 'signup' && !formData.name) {
      toast({
        title: 'Missing name',
        description: 'Please enter your full name',
        variant: 'destructive',
      });
      return;
    }

    if (formData.password.length < 8) {
      toast({
        title: 'Password too short',
        description: 'Password must be at least 8 characters',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      if (authMode === 'login') {
        const { error } = await signIn(formData.email, formData.password);
        if (error) {
          toast({
            title: 'Sign in failed',
            description: error.message || 'Invalid email or password',
            variant: 'destructive',
          });
        } else {
          toast({
            title: 'Welcome back!',
            description: 'You have successfully signed in',
          });
          navigate('/');
        }
      } else {
        // For signup, move to phone verification step first
        setAuthMode('signup-phone');
        toast({
          title: 'Almost there!',
          description: 'Please verify your mobile number to complete signup',
        });
      }
    } catch (err) {
      toast({
        title: 'Error',
        description: 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    }

    setIsLoading(false);
  };

  const handleOtpRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.email) {
      toast({
        title: 'Email required',
        description: 'Please enter your email address',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await supabase.functions.invoke('send-email-otp', {
        body: { email: formData.email }
      });
      
      if (response.error) {
        toast({
          title: 'Failed to send OTP',
          description: response.error.message || 'Could not send verification code',
          variant: 'destructive',
        });
      } else if (response.data?.error) {
        toast({
          title: 'Failed to send OTP',
          description: response.data.error,
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'OTP sent!',
          description: 'Check your email for the 6-digit verification code. Valid for 5 minutes.',
        });
        setOtpCode('');
        startResendTimer();
        setAuthMode('verify-otp');
      }
    } catch (err: any) {
      console.error('Email OTP error:', err);
      toast({
        title: 'Error',
        description: 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    }

    setIsLoading(false);
  };

  const handleOtpVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (otpCode.length !== 6) {
      toast({
        title: 'Invalid OTP',
        description: 'Please enter the complete 6-digit code',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await supabase.functions.invoke('verify-email-otp', {
        body: { email: formData.email, otp: otpCode }
      });
      
      if (response.error) {
        toast({
          title: 'Verification failed',
          description: response.error.message || 'Invalid or expired code',
          variant: 'destructive',
        });
      } else if (response.data?.error) {
        toast({
          title: 'Verification failed',
          description: response.data.error,
          variant: 'destructive',
        });
      } else if (response.data?.actionLink) {
        const url = new URL(response.data.actionLink);
        const token_hash = url.searchParams.get('token');
        
        if (token_hash) {
          const { error: verifyError } = await supabase.auth.verifyOtp({
            token_hash,
            type: 'magiclink',
          });
          
          if (verifyError) {
            toast({
              title: 'Sign in failed',
              description: verifyError.message,
              variant: 'destructive',
            });
          } else {
            toast({
              title: 'Welcome!',
              description: response.data.isNewUser ? 'Account created successfully!' : 'You have successfully signed in',
            });
            navigate('/');
          }
        }
      }
    } catch (err: any) {
      console.error('OTP verify error:', err);
      toast({
        title: 'Error',
        description: 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    }

    setIsLoading(false);
  };

  const handlePhoneOtpRequest = async (e?: React.FormEvent) => {
    e?.preventDefault();
    
    if (!formData.phone || formData.phone.length !== 10) {
      toast({
        title: 'Invalid phone number',
        description: 'Please enter a valid 10-digit mobile number',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      // sendPhoneOTP handles recaptcha internally
      const result = await sendPhoneOTP(formData.phone);
      
      if (!result.success) {
        toast({
          title: 'Failed to send OTP',
          description: result.error || 'Could not send verification code',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'OTP sent!',
          description: 'Check your phone for the 6-digit verification code.',
        });
        setOtpCode('');
        startResendTimer();
        setAuthMode('verify-phone');
      }
    } catch (err: any) {
      console.error('Phone OTP error:', err);
      toast({
        title: 'Error',
        description: err.message || 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    }

    setIsLoading(false);
  };

  const handlePhoneOtpVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (otpCode.length !== 6) {
      toast({
        title: 'Invalid OTP',
        description: 'Please enter the complete 6-digit code',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      const result = await verifyPhoneOTP(otpCode);
      
      if (!result.success) {
        toast({
          title: 'Verification failed',
          description: result.error || 'Invalid or expired code',
          variant: 'destructive',
        });
      } else {
        // Firebase auth successful, now sign in to Supabase with the phone number
        // We'll create/sign in the user using a custom approach
        const firebaseUser = result.user;
        const phoneNumber = firebaseUser.phoneNumber;
        
        // Use Supabase admin to create/get user or sign in with a password
        // For now, we'll use signUp with a generated password based on phone
        const tempPassword = `firebase_${phoneNumber}_${Date.now()}`;
        
        // Try to sign in first, if fails, sign up
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: `${phoneNumber?.replace('+', '')}@phone.towny.app`,
          password: tempPassword,
        });
        
        if (signInError) {
          // User doesn't exist, create new account
          const { error: signUpError } = await supabase.auth.signUp({
            email: `${phoneNumber?.replace('+', '')}@phone.towny.app`,
            password: tempPassword,
            options: {
              emailRedirectTo: `${window.location.origin}/`,
              data: {
                phone: phoneNumber,
                auth_provider: 'firebase_phone',
              }
            }
          });
          
          if (signUpError && !signUpError.message.includes('already registered')) {
            throw signUpError;
          }
          
          // Sign in after signup
          await supabase.auth.signInWithPassword({
            email: `${phoneNumber?.replace('+', '')}@phone.towny.app`,
            password: tempPassword,
          });
        }
        
        toast({
          title: 'Welcome!',
          description: 'You have successfully signed in',
        });
        
        navigate('/');
      }
    } catch (err: any) {
      console.error('Phone OTP verify error:', err);
      toast({
        title: 'Error',
        description: err.message || 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    }

    setIsLoading(false);
  };

  // Handle phone OTP request for signup flow
  const handleSignupPhoneOtpRequest = async (e?: React.FormEvent) => {
    e?.preventDefault();
    
    if (!formData.phone || formData.phone.length !== 10) {
      toast({
        title: 'Invalid phone number',
        description: 'Please enter a valid 10-digit mobile number',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      // sendPhoneOTP handles recaptcha internally
      const result = await sendPhoneOTP(formData.phone);
      
      if (!result.success) {
        toast({
          title: 'Failed to send OTP',
          description: result.error || 'Could not send verification code',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'OTP sent!',
          description: 'Check your phone for the 6-digit verification code.',
        });
        setOtpCode('');
        startResendTimer();
        setAuthMode('signup-verify-phone');
      }
    } catch (err: any) {
      console.error('Phone OTP error:', err);
      toast({
        title: 'Error',
        description: err.message || 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    }

    setIsLoading(false);
  };

  // Handle phone OTP verification for signup flow
  const handleSignupPhoneOtpVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (otpCode.length !== 6) {
      toast({
        title: 'Invalid OTP',
        description: 'Please enter the complete 6-digit code',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      const result = await verifyPhoneOTP(otpCode);
      
      if (!result.success) {
        toast({
          title: 'Verification failed',
          description: result.error || 'Invalid or expired code',
          variant: 'destructive',
        });
      } else {
        // Phone verified, now complete the Supabase signup
        const { error } = await signUp(formData.email, formData.password, formData.name);
        
        if (error) {
          if (error.message.includes('already registered')) {
            toast({
              title: 'Account exists',
              description: 'This email is already registered. Please sign in instead.',
              variant: 'destructive',
            });
            setAuthMode('login');
          } else {
            toast({
              title: 'Sign up failed',
              description: error.message || 'Could not create account',
              variant: 'destructive',
            });
          }
        } else {
          // Update profile with phone number
          const { data: session } = await supabase.auth.getSession();
          if (session?.session?.user) {
            await supabase.from('profiles').upsert({
              user_id: session.session.user.id,
              phone: `+91${formData.phone}`,
              name: formData.name,
            });
            
            // Process referral if code exists
            if (referralCode) {
              try {
                await supabase.rpc('process_referral', {
                  referral_code_param: referralCode,
                  new_user_id: session.session.user.id,
                });
              } catch (err) {
                console.error('Error processing referral:', err);
              }
            }
          }
          
          toast({
            title: 'Account created!',
            description: referralCode ? 'Welcome to Towny! Your referrer earned a free boost.' : 'Welcome to Towny!',
          });
          
          navigate('/');
        }
      }
    } catch (err: any) {
      console.error('Signup phone OTP verify error:', err);
      toast({
        title: 'Error',
        description: err.message || 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    }

    setIsLoading(false);
  };

  const features = [
    {
      icon: Home,
      title: 'Find Properties',
      description: 'Browse thousands of listings',
    },
    {
      icon: Building2,
      title: 'Post Your Property',
      description: 'Reach millions of users',
    },
    {
      icon: Users,
      title: 'Connect Directly',
      description: 'Chat with property owners',
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  const renderForm = () => {
    if (authMode === 'otp') {
      return (
        <form onSubmit={handleOtpRequest} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="otp-email" className="text-sm font-medium">
              Email
            </Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                id="otp-email"
                type="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="pl-11 h-12 rounded-lg border-border"
              />
            </div>
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-lg text-base font-semibold"
            disabled={isLoading}
          >
            {isLoading ? 'Sending OTP...' : 'Send OTP'}
          </Button>

          <p className="text-xs text-muted-foreground text-center">
            We'll send a 6-digit code to your email.
          </p>
        </form>
      );
    }

    if (authMode === 'verify-otp') {
      return (
        <form onSubmit={handleOtpVerify} className="space-y-5">
          <div className="space-y-3">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
              <Mail className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-center">Enter verification code</h3>
            <p className="text-sm text-muted-foreground text-center">
              We sent a 6-digit code to <strong>{formData.email}</strong>
            </p>
            <p className="text-xs text-muted-foreground text-center">
              Check your spam folder if you don't see the email.
            </p>
          </div>

          <div className="flex justify-center">
            <InputOTP
              maxLength={6}
              value={otpCode}
              onChange={(value) => setOtpCode(value)}
            >
              <InputOTPGroup>
                <InputOTPSlot index={0} />
                <InputOTPSlot index={1} />
                <InputOTPSlot index={2} />
                <InputOTPSlot index={3} />
                <InputOTPSlot index={4} />
                <InputOTPSlot index={5} />
              </InputOTPGroup>
            </InputOTP>
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-lg text-base font-semibold"
            disabled={isLoading || otpCode.length !== 6}
          >
            {isLoading ? 'Verifying...' : 'Verify & Sign In'}
          </Button>

          <button
            type="button"
            onClick={handleOtpRequest}
            className="w-full text-sm text-muted-foreground hover:text-primary disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isLoading || resendTimer > 0}
          >
            {resendTimer > 0 
              ? `Resend OTP in ${resendTimer}s` 
              : "Didn't receive code? Resend OTP"}
          </button>

          <button
            type="button"
            onClick={() => setAuthMode('otp')}
            className="w-full text-sm text-muted-foreground hover:text-primary"
          >
            Use a different email
          </button>
        </form>
      );
    }

    // Phone OTP form
    if (authMode === 'phone') {
      return (
        <form onSubmit={handlePhoneOtpRequest} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="phone" className="text-sm font-medium">
              Mobile Number
            </Label>
            <div className="relative">
              <div className="flex">
                <span className="inline-flex items-center px-3 text-sm text-muted-foreground bg-muted border border-r-0 border-border rounded-l-lg">
                  +91
                </span>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="9876543210"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className="h-12 rounded-l-none border-border"
                  maxLength={10}
                />
              </div>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-lg text-base font-semibold"
            disabled={isLoading}
          >
            {isLoading ? 'Sending OTP...' : 'Send OTP'}
          </Button>

          <p className="text-xs text-muted-foreground text-center">
            We'll send a 6-digit code to your mobile number.
          </p>
        </form>
      );
    }

    if (authMode === 'verify-phone') {
      return (
        <form onSubmit={handlePhoneOtpVerify} className="space-y-5">
          <div className="space-y-3">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
              <Phone className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-center">Enter verification code</h3>
            <p className="text-sm text-muted-foreground text-center">
              We sent a 6-digit code to <strong>+91 {formData.phone}</strong>
            </p>
          </div>

          <div className="flex justify-center">
            <InputOTP
              maxLength={6}
              value={otpCode}
              onChange={(value) => setOtpCode(value)}
            >
              <InputOTPGroup>
                <InputOTPSlot index={0} />
                <InputOTPSlot index={1} />
                <InputOTPSlot index={2} />
                <InputOTPSlot index={3} />
                <InputOTPSlot index={4} />
                <InputOTPSlot index={5} />
              </InputOTPGroup>
            </InputOTP>
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-lg text-base font-semibold"
            disabled={isLoading || otpCode.length !== 6}
          >
            {isLoading ? 'Verifying...' : 'Verify & Sign In'}
          </Button>

          <button
            type="button"
            onClick={() => handlePhoneOtpRequest()}
            className="w-full text-sm text-muted-foreground hover:text-primary disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isLoading || resendTimer > 0}
          >
            {resendTimer > 0 
              ? `Resend OTP in ${resendTimer}s` 
              : "Didn't receive code? Resend OTP"}
          </button>

          <button
            type="button"
            onClick={() => setAuthMode('phone')}
            className="w-full text-sm text-muted-foreground hover:text-primary"
          >
            Use a different number
          </button>
        </form>
      );
    }

    // Signup phone number entry form
    if (authMode === 'signup-phone') {
      return (
        <form onSubmit={handleSignupPhoneOtpRequest} className="space-y-5">
          <div className="space-y-3">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
              <Phone className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-center">Verify your mobile number</h3>
            <p className="text-sm text-muted-foreground text-center">
              We'll send a 6-digit code to verify your mobile number
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="signup-phone" className="text-sm font-medium">
              Mobile Number
            </Label>
            <div className="relative">
              <div className="flex">
                <span className="inline-flex items-center px-3 text-sm text-muted-foreground bg-muted border border-r-0 border-border rounded-l-lg">
                  +91
                </span>
                <Input
                  id="signup-phone"
                  type="tel"
                  placeholder="9876543210"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className="h-12 rounded-l-none border-border"
                  maxLength={10}
                />
              </div>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-lg text-base font-semibold"
            disabled={isLoading}
          >
            {isLoading ? 'Sending OTP...' : 'Send OTP'}
          </Button>
        </form>
      );
    }

    // Signup phone OTP verification form
    if (authMode === 'signup-verify-phone') {
      return (
        <form onSubmit={handleSignupPhoneOtpVerify} className="space-y-5">
          <div className="space-y-3">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
              <Phone className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-center">Enter verification code</h3>
            <p className="text-sm text-muted-foreground text-center">
              We sent a 6-digit code to <strong>+91 {formData.phone}</strong>
            </p>
          </div>

          <div className="flex justify-center">
            <InputOTP
              maxLength={6}
              value={otpCode}
              onChange={(value) => setOtpCode(value)}
            >
              <InputOTPGroup>
                <InputOTPSlot index={0} />
                <InputOTPSlot index={1} />
                <InputOTPSlot index={2} />
                <InputOTPSlot index={3} />
                <InputOTPSlot index={4} />
                <InputOTPSlot index={5} />
              </InputOTPGroup>
            </InputOTP>
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-lg text-base font-semibold"
            disabled={isLoading || otpCode.length !== 6}
          >
            {isLoading ? 'Creating account...' : 'Verify & Create Account'}
          </Button>

          <button
            type="button"
            onClick={() => handleSignupPhoneOtpRequest()}
            className="w-full text-sm text-muted-foreground hover:text-primary disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isLoading || resendTimer > 0}
          >
            {resendTimer > 0 
              ? `Resend OTP in ${resendTimer}s` 
              : "Didn't receive code? Resend OTP"}
          </button>

          <button
            type="button"
            onClick={() => {
              setAuthMode('signup-phone');
              setOtpCode('');
            }}
            className="w-full text-sm text-muted-foreground hover:text-primary"
          >
            Use a different number
          </button>
        </form>
      );
    }

    // Password-based login/signup
    return (
      <form onSubmit={handlePasswordSubmit} className="space-y-5">
        {authMode === 'signup' && (
          <div className="space-y-2">
            <Label htmlFor="name" className="text-sm font-medium">
              Full Name
            </Label>
            <div className="relative">
              <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                id="name"
                type="text"
                placeholder="John Doe"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="pl-11 h-12 rounded-lg border-border"
              />
            </div>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="email" className="text-sm font-medium">
            Email
          </Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              className="pl-11 h-12 rounded-lg border-border"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="password" className="text-sm font-medium">
            Password
          </Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              id="password"
              type={showPassword ? 'text' : 'password'}
              placeholder="••••••••"
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              className="pl-11 pr-11 h-12 rounded-lg border-border"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            >
              {showPassword ? (
                <EyeOff className="w-5 h-5" />
              ) : (
                <Eye className="w-5 h-5" />
              )}
            </button>
          </div>
          {authMode === 'signup' && (
            <p className="text-xs text-muted-foreground">
              Minimum 8 characters
            </p>
          )}
        </div>

        <Button
          type="submit"
          className="w-full h-12 rounded-lg text-base font-semibold"
          disabled={isLoading}
        >
          {isLoading ? 'Please wait...' : authMode === 'login' ? 'Sign In' : 'Sign Up'}
        </Button>
      </form>
    );
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-gradient-to-b from-primary to-primary/80 lg:bg-none">
      {/* Background decorative elements - visible on all screens */}
      <div className="absolute top-0 left-0 w-full h-full lg:w-1/2 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-5 md:top-20 md:left-10 w-20 h-20 md:w-32 md:h-32 border border-primary-foreground/10 rounded-full" />
        <div className="absolute top-24 right-10 md:top-40 md:right-20 w-32 h-32 md:w-48 md:h-48 border border-primary-foreground/10 rounded-full" />
        <div className="absolute bottom-20 left-1/4 w-16 h-16 md:w-24 md:h-24 border border-primary-foreground/10 rounded-full" />
      </div>

      {/* Left Side - Branding (always visible, different layout on mobile) */}
      <div className="relative z-10 w-full lg:w-1/2 p-6 md:p-8 lg:p-12 flex flex-col justify-center lg:bg-gradient-to-b lg:from-primary lg:to-primary/80">
        <div className="max-w-md mx-auto lg:mx-auto">
          {/* Logo */}
          <div className="flex items-center gap-4 mb-4 lg:mb-8">
            <img src={townyLogo} alt="Towny" className="w-14 h-14 md:w-20 md:h-20 lg:w-24 lg:h-24 object-contain" />
            <span className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary-foreground">Towny</span>
          </div>

          {/* Tagline */}
          <p className="text-base lg:text-xl text-primary-foreground/90 mb-6 lg:mb-12 leading-relaxed">
            Find your perfect home, PG, or commercial space with ease
          </p>

          {/* Feature Cards - hidden on mobile, visible on tablet and up */}
          <div className="hidden md:block space-y-4 mb-8 lg:mb-0">
            {features.map((feature, index) => (
              <div
                key={index}
                className="flex items-center gap-4 p-3 lg:p-4 bg-primary-foreground/10 backdrop-blur-sm rounded-xl border border-primary-foreground/10"
              >
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-lg bg-primary-foreground/10 flex items-center justify-center">
                  <feature.icon className="w-5 h-5 lg:w-6 lg:h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm lg:text-base text-primary-foreground">
                    {feature.title}
                  </h3>
                  <p className="text-xs lg:text-sm text-primary-foreground/70">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="w-full lg:w-1/2 flex items-start lg:items-center justify-center p-4 md:p-8 bg-background lg:bg-background rounded-t-3xl lg:rounded-none -mt-4 lg:mt-0 relative z-20">
        <div className="w-full max-w-md">

          {/* Referral Banner */}
          {referralCode && (
            <div className="mb-4 p-4 bg-primary/10 border border-primary/20 rounded-xl flex items-center gap-3">
              <Gift className="w-6 h-6 text-primary shrink-0" />
              <div>
                <p className="text-sm font-medium text-primary">You've been referred!</p>
                <p className="text-xs text-muted-foreground">Sign up to help your friend earn a free boost</p>
              </div>
            </div>
          )}

          {/* Form Card */}
          <div className="bg-card rounded-2xl p-8 shadow-card border border-border">
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold text-foreground italic">
                {authMode === 'login' && 'Welcome Back'}
                {authMode === 'signup' && 'Create Account'}
                {authMode === 'otp' && 'Sign In with Email OTP'}
                {authMode === 'verify-otp' && 'Verify Email OTP'}
                {authMode === 'phone' && 'Sign In with Mobile'}
                {authMode === 'verify-phone' && 'Verify Mobile OTP'}
                {authMode === 'signup-phone' && 'Verify Mobile'}
                {authMode === 'signup-verify-phone' && 'Complete Signup'}
              </h1>
              <p className="text-primary mt-2">
                {authMode === 'login' && 'Sign in to continue to Towny'}
                {authMode === 'signup' && 'Sign up to get started with Towny'}
                {authMode === 'otp' && "We'll send a code to your email"}
                {authMode === 'verify-otp' && 'Enter the code we sent to your email'}
                {authMode === 'phone' && "We'll send a code to your mobile"}
                {authMode === 'verify-phone' && 'Enter the code we sent to your mobile'}
                {authMode === 'signup-phone' && 'Verify your mobile number to complete signup'}
                {authMode === 'signup-verify-phone' && 'Enter the code to create your account'}
              </p>
            </div>

            {renderForm()}

            {/* Auth mode toggles */}
            {!['verify-otp', 'verify-phone', 'signup-phone', 'signup-verify-phone'].includes(authMode) && (
              <div className="mt-6 space-y-3">
                {authMode === 'login' && (
                  <>
                    <button
                      type="button"
                      onClick={() => setAuthMode('otp')}
                      className="w-full flex items-center justify-center gap-2 py-3 border border-border rounded-lg text-muted-foreground hover:text-foreground hover:border-primary transition-colors"
                    >
                      <Mail className="w-4 h-4" />
                      Sign in with Email OTP
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthMode('phone')}
                      className="w-full flex items-center justify-center gap-2 py-3 border border-border rounded-lg text-muted-foreground hover:text-foreground hover:border-primary transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      Sign in with Mobile OTP
                    </button>
                  </>
                )}
                
                {authMode === 'otp' && (
                  <>
                    <button
                      type="button"
                      onClick={() => setAuthMode('login')}
                      className="w-full flex items-center justify-center gap-2 py-3 border border-border rounded-lg text-muted-foreground hover:text-foreground hover:border-primary transition-colors"
                    >
                      <Lock className="w-4 h-4" />
                      Sign in with password
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthMode('phone')}
                      className="w-full flex items-center justify-center gap-2 py-3 border border-border rounded-lg text-muted-foreground hover:text-foreground hover:border-primary transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      Sign in with Mobile OTP
                    </button>
                  </>
                )}

                {authMode === 'phone' && (
                  <>
                    <button
                      type="button"
                      onClick={() => setAuthMode('login')}
                      className="w-full flex items-center justify-center gap-2 py-3 border border-border rounded-lg text-muted-foreground hover:text-foreground hover:border-primary transition-colors"
                    >
                      <Lock className="w-4 h-4" />
                      Sign in with password
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthMode('otp')}
                      className="w-full flex items-center justify-center gap-2 py-3 border border-border rounded-lg text-muted-foreground hover:text-foreground hover:border-primary transition-colors"
                    >
                      <Mail className="w-4 h-4" />
                      Sign in with Email OTP
                    </button>
                  </>
                )}

                {/* Login/Signup toggle */}
                <p className="text-center text-muted-foreground">
                  {['login', 'otp', 'phone'].includes(authMode) ? "Don't have an account? " : 'Already have an account? '}
                  <button
                    type="button"
                    onClick={() => setAuthMode(authMode === 'signup' ? 'login' : 'signup')}
                    className="text-primary font-semibold hover:underline"
                  >
                    {['login', 'otp', 'phone'].includes(authMode) ? 'Sign Up' : 'Sign In'}
                  </button>
                </p>
              </div>
            )}

            {['verify-otp', 'verify-phone'].includes(authMode) && (
              <p className="text-center mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode(authMode === 'verify-phone' ? 'phone' : 'otp');
                    setOtpCode('');
                  }}
                  className="text-muted-foreground hover:text-primary transition-colors text-sm"
                >
                  ← Back to {authMode === 'verify-phone' ? 'mobile' : 'email'} input
                </button>
              </p>
            )}
          </div>

          {/* Back to home */}
          <p className="text-center mt-6">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="text-muted-foreground hover:text-primary transition-colors text-sm"
            >
              ← Back to Home
            </button>
          </p>
        </div>
      </div>
      
      {/* Hidden reCAPTCHA container for Firebase Phone Auth */}
      <div id="recaptcha-container"></div>
    </div>
  );
};

export default Auth;
