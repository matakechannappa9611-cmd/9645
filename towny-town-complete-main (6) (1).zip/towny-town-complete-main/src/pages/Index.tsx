import { useState, useMemo, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import SearchFilters from '@/components/SearchFilters';
import MapView from '@/components/MapView';
import LocationProperties from '@/components/LocationProperties';
import FeaturedProperties from '@/components/FeaturedProperties';
import PropertyGrid from '@/components/PropertyGrid';
import Footer from '@/components/Footer';
import MobileNav from '@/components/MobileNav';
import { properties } from '@/data/properties';
import { SearchFilters as SearchFiltersType } from '@/types/property';
import { useToast } from '@/hooks/use-toast';

// Calculate distance between two coordinates in km (Haversine formula)
const getDistanceFromLatLonInKm = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371; // Radius of the earth in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const Index = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('home');

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'home') navigate('/');
    else if (tab === 'messaging') navigate('/messages');
    else if (tab === 'notifications') navigate('/notifications');
    else if (tab === 'saved') navigate('/saved');
  };
  const [filters, setFilters] = useState<SearchFiltersType>({
    location: '',
    bhkType: 'All',
    propertyType: 'All',
    tenantType: 'All',
    nearMe: false,
  });
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [locationRequested, setLocationRequested] = useState(false);

  // Request location permission on page load
  useEffect(() => {
    if (!locationRequested && navigator.geolocation) {
      setLocationRequested(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ lat: latitude, lng: longitude });
          toast({
            title: 'Location detected',
            description: 'You can use "Near Me" to find nearby properties',
          });
        },
        (error) => {
          console.log('Location permission denied or unavailable:', error.message);
        },
        { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
      );
    }
  }, [locationRequested, toast]);

  const featuredProperties = useMemo(
    () => properties.filter((p) => p.isFeatured),
    []
  );

  const filteredProperties = useMemo(() => {
    return properties.filter((property) => {
      // Filter by "Near Me" - 5km radius
      if (filters.nearMe && userLocation && property.coordinates) {
        const distance = getDistanceFromLatLonInKm(
          userLocation.lat,
          userLocation.lng,
          property.coordinates.lat,
          property.coordinates.lng
        );
        if (distance > 5) return false;
      }

      // Filter by location/city
      if (filters.location && !filters.nearMe) {
        const locationMatch = 
          property.city.toLowerCase().includes(filters.location.toLowerCase()) ||
          property.location.toLowerCase().includes(filters.location.toLowerCase());
        if (!locationMatch) return false;
      }
      
      // Filter by BHK type
      if (filters.bhkType && filters.bhkType !== 'All') {
        const bhkNum = parseInt(filters.bhkType);
        if (!isNaN(bhkNum) && property.bhk !== bhkNum) {
          return false;
        }
      }
      
      // Filter by property type
      if (filters.propertyType !== 'All' && property.type !== filters.propertyType) {
        return false;
      }
      
      return true;
    });
  }, [filters, userLocation]);

  const locationProperties = useMemo(() => {
    if (filters.nearMe && userLocation) {
      return filteredProperties;
    }
    return properties.filter((p) => p.city === 'Bangalore');
  }, [filters.nearMe, userLocation, filteredProperties]);

  const handleNearMeToggle = useCallback((enabled: boolean) => {
    if (enabled && !userLocation) {
      setIsLocating(true);
      
      if (!navigator.geolocation) {
        setIsLocating(false);
        setFilters((prev) => ({ ...prev, nearMe: false }));
        toast({
          title: 'Geolocation not supported',
          description: 'Your browser does not support geolocation',
          variant: 'destructive',
        });
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ lat: latitude, lng: longitude });
          setIsLocating(false);
          toast({
            title: 'Location detected',
            description: 'Showing properties within 5km radius',
          });
        },
        (error) => {
          console.error('Geolocation error:', error.code, error.message);
          setIsLocating(false);
          setFilters((prev) => ({ ...prev, nearMe: false }));
          
          toast({
            title: 'Location access failed',
            description: 'Please enable location access',
            variant: 'destructive',
          });
        },
        { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
      );
    }
  }, [toast, userLocation]);

  const handleSearch = () => {
    toast({
      title: 'Searching...',
      description: `Found ${filteredProperties.length} properties`,
    });
  };

  return (
    <div className="min-h-screen bg-background pb-16 md:pb-0">
      <Header activeTab={activeTab} onTabChange={handleTabChange} />
      <SearchFilters
        filters={filters}
        onFilterChange={setFilters}
        onSearch={handleSearch}
        onNearMeToggle={handleNearMeToggle}
        isLocating={isLocating}
      />

      <main className="container mx-auto px-4 py-6">
        {/* Map and Properties Side by Side */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Map */}
          <div className="lg:h-auto">
            <MapView 
              properties={filteredProperties} 
              propertyCount={filteredProperties.length}
              userLocation={userLocation}
              showNearMe={filters.nearMe}
              onBadgeClick={() => {
                document.getElementById('all-properties')?.scrollIntoView({ behavior: 'smooth' });
              }}
            />
          </div>

          {/* Properties Near You */}
          <div>
            <LocationProperties 
              properties={locationProperties}
              title={filters.nearMe && userLocation ? 'Properties Near You (5km)' : 'Properties in Bangalore'}
            />
          </div>
        </section>

        {/* Distance Calculator removed - now integrated in MapView */}

        {/* Featured Properties */}
        <FeaturedProperties properties={featuredProperties} />

        {/* All Properties (excluding featured) */}
        <div id="all-properties">
          <PropertyGrid properties={properties} excludeFeatured={true} />
        </div>
      </main>

      <Footer />
      <MobileNav activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  );
};

export default Index;
