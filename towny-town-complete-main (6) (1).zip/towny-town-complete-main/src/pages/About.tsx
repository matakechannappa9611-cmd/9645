import Header from "@/components/Header";
import Footer from "@/components/Footer";
import MobileNav from "@/components/MobileNav";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header activeTab="about" onTabChange={() => {}} />
      
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <h1 className="text-4xl font-bold text-foreground mb-8">About Towny</h1>
        
        <div className="space-y-6 text-muted-foreground">
          <p className="text-lg leading-relaxed">
            Towny is a location-based discovery platform designed to help people find properties, places, and opportunities within towns and local communities. We make searching simple, transparent, and accessible for everyone—whether you're looking to buy, rent, sell, or explore.
          </p>
          
          <p className="text-lg leading-relaxed">
            Our goal is to empower local communities by connecting people with trusted listings, nearby services, and real opportunities. Towny focuses on clarity, speed, and trust, helping users make confident decisions without unnecessary complexity.
          </p>
          
          <div className="pt-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">Our Mission</h2>
            <p className="text-lg leading-relaxed">
              To simplify local discovery and property search through technology that is easy to use, reliable, and community-driven.
            </p>
          </div>
          
          <div className="pt-4">
            <h2 className="text-2xl font-semibold text-foreground mb-4">Our Vision</h2>
            <p className="text-lg leading-relaxed">
              To become the most trusted local discovery platform for towns and neighborhoods across regions.
            </p>
          </div>
        </div>
      </main>
      
      <Footer />
      <MobileNav activeTab="about" onTabChange={() => {}} />
    </div>
  );
};

export default About;
