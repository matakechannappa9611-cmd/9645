import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Gift, 
  Copy, 
  Share2, 
  CheckCircle, 
  Clock, 
  Users, 
  Sparkles,
  MessageCircle,
  Link2,
  ArrowLeft,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useReferral } from '@/hooks/useReferral';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const Referrals = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, loading: authLoading } = useAuth();
  const {
    referralCode,
    activeBoosts,
    hasActiveBoost,
    boostExpiresAt,
    monthlyReferralsUsed,
    maxMonthlyReferrals,
    loading,
    getReferralLink,
    shareViaWhatsApp,
    copyReferralLink,
    copyReferralCode,
  } = useReferral();

  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  const handleCopyCode = async () => {
    const success = await copyReferralCode();
    if (success) {
      setCopiedCode(true);
      toast({
        title: 'Copied!',
        description: 'Referral code copied to clipboard',
      });
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleCopyLink = async () => {
    const success = await copyReferralLink();
    if (success) {
      setCopiedLink(true);
      toast({
        title: 'Copied!',
        description: 'Referral link copied to clipboard',
      });
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const handleWhatsAppShare = () => {
    shareViaWhatsApp();
    toast({
      title: 'Opening WhatsApp',
      description: 'Share your referral with friends!',
    });
  };

  const getTimeRemaining = () => {
    if (!boostExpiresAt) return null;
    const now = new Date();
    const diff = boostExpiresAt.getTime() - now.getTime();
    if (diff <= 0) return 'Expired';
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m remaining`;
    }
    return `${minutes}m remaining`;
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Back Button */}
        <Button
          variant="ghost"
          className="mb-4"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        {/* Hero Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
            <Gift className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Refer & Earn</h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Invite friends to Towny and enjoy <strong>1-Day Free Boost</strong> for each successful signup. No payment required!
          </p>
        </div>

        {/* Active Boost Banner */}
        {hasActiveBoost && (
          <Card className="mb-6 border-primary bg-primary/5">
            <CardContent className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Zap className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-primary">Free Boost Active!</p>
                  <p className="text-sm text-muted-foreground">
                    Your listings are featured
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-sm font-medium">
                  <Clock className="w-4 h-4" />
                  {getTimeRemaining()}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Referral Code Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              Your Referral Code
            </CardTitle>
            <CardDescription>
              Share this code with friends to earn free boosts
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Code Display */}
            <div className="flex items-center gap-3">
              <div className="flex-1 bg-muted rounded-lg p-4 text-center">
                <span className="text-2xl font-bold tracking-wider">
                  {referralCode?.code || '------'}
                </span>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={handleCopyCode}
                className="h-14 w-14"
              >
                {copiedCode ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <Copy className="w-5 h-5" />
                )}
              </Button>
            </div>

            {/* Link Display */}
            <div className="flex items-center gap-3">
              <div className="flex-1 bg-muted rounded-lg p-3 overflow-hidden">
                <p className="text-sm text-muted-foreground truncate">
                  {getReferralLink() || 'Loading...'}
                </p>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={handleCopyLink}
              >
                {copiedLink ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <Link2 className="w-5 h-5" />
                )}
              </Button>
            </div>

            {/* Share Buttons */}
            <div className="flex gap-3">
              <Button
                className="flex-1"
                onClick={handleWhatsAppShare}
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Share via WhatsApp
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={handleCopyLink}
              >
                <Share2 className="w-4 h-4 mr-2" />
                Copy Link
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Your Referral Stats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="bg-muted rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-primary">
                  {referralCode?.successful_referrals || 0}
                </p>
                <p className="text-sm text-muted-foreground">Successful Referrals</p>
              </div>
              <div className="bg-muted rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-primary">
                  {activeBoosts.length}
                </p>
                <p className="text-sm text-muted-foreground">Active Boosts</p>
              </div>
              <div className="bg-muted rounded-lg p-4 text-center col-span-2 md:col-span-1">
                <p className="text-2xl font-bold text-primary">
                  {maxMonthlyReferrals - monthlyReferralsUsed}
                </p>
                <p className="text-sm text-muted-foreground">Boosts Left This Month</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm shrink-0">
                  1
                </div>
                <div>
                  <p className="font-medium">Share Your Code</p>
                  <p className="text-sm text-muted-foreground">
                    Send your unique referral code or link to friends
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm shrink-0">
                  2
                </div>
                <div>
                  <p className="font-medium">Friend Signs Up</p>
                  <p className="text-sm text-muted-foreground">
                    Your friend creates an account and verifies their phone/email
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm shrink-0">
                  3
                </div>
                <div>
                  <p className="font-medium">You Get Rewarded</p>
                  <p className="text-sm text-muted-foreground">
                    Automatically receive 1-Day Free Boost for your listings
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Benefits */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Free Boost Benefits</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
                <span>Higher listing visibility in search results</span>
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
                <span>Featured badge on your property</span>
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
                <span>WhatsApp & Call buttons enabled</span>
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
                <span>Valid for 24 hours</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Rules */}
        <Card>
          <CardHeader>
            <CardTitle>Rules</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Maximum 3 free boost days per month</li>
              <li>• Only valid signups count (verified phone/email)</li>
              <li>• No self-referrals allowed</li>
              <li>• One reward per unique referral</li>
              <li>• Boost expires automatically after 24 hours</li>
            </ul>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
};

export default Referrals;
