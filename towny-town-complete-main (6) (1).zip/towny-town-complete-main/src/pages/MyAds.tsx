import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Edit2, Trash2, Eye, MoreVertical, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { indianCities } from '@/data/properties';

interface PropertyAd {
  id: string;
  title: string;
  property_type: string;
  furnishing: string | null;
  rent: number;
  security_deposit: number | null;
  city: string;
  area: string;
  address: string | null;
  bedrooms: number | null;
  bathrooms: number | null;
  sqft: number | null;
  description: string | null;
  status: string | null;
  created_at: string;
}

const MyAds = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [myAds, setMyAds] = useState<PropertyAd[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingAd, setEditingAd] = useState<PropertyAd | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteAdId, setDeleteAdId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const [editForm, setEditForm] = useState({
    title: '',
    property_type: '',
    furnishing: '',
    rent: '',
    security_deposit: '',
    city: '',
    area: '',
    address: '',
    bedrooms: '',
    bathrooms: '',
    sqft: '',
    description: '',
    status: '',
  });

  const propertyTypes = [
    { value: '1bhk', label: '1BHK' },
    { value: '2bhk', label: '2BHK' },
    { value: '3bhk', label: '3BHK' },
    { value: 'pg', label: 'PG' },
    { value: 'hotel', label: 'Hotel' },
    { value: 'commercial', label: 'Commercial' },
    { value: 'plot', label: 'Plot' },
  ];

  const furnishingOptions = [
    { value: 'unfurnished', label: 'Unfurnished' },
    { value: 'semi', label: 'Semi-Furnished' },
    { value: 'fully', label: 'Fully Furnished' },
  ];

  const statusOptions = [
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' },
    { value: 'rented', label: 'Rented' },
  ];

  useEffect(() => {
    if (user) {
      fetchMyAds();
    }
  }, [user]);

  const fetchMyAds = async () => {
    if (!user) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('properties')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast({
        title: 'Error fetching ads',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      setMyAds(data || []);
    }
    setLoading(false);
  };

  const handleEditClick = (ad: PropertyAd) => {
    setEditingAd(ad);
    setEditForm({
      title: ad.title,
      property_type: ad.property_type,
      furnishing: ad.furnishing || '',
      rent: ad.rent.toString(),
      security_deposit: ad.security_deposit?.toString() || '',
      city: ad.city,
      area: ad.area,
      address: ad.address || '',
      bedrooms: ad.bedrooms?.toString() || '',
      bathrooms: ad.bathrooms?.toString() || '',
      sqft: ad.sqft?.toString() || '',
      description: ad.description || '',
      status: ad.status || 'active',
    });
    setIsEditDialogOpen(true);
  };

  const handleEditFormChange = (field: string, value: string) => {
    const numericFields = ['rent', 'security_deposit', 'bedrooms', 'bathrooms', 'sqft'];
    if (numericFields.includes(field)) {
      const numValue = parseFloat(value);
      if (value !== '' && (isNaN(numValue) || numValue < 0)) {
        return;
      }
    }
    setEditForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveEdit = async () => {
    if (!editingAd) return;

    if (!editForm.title || !editForm.property_type || !editForm.rent || !editForm.city || !editForm.area) {
      toast({
        title: 'Required fields missing',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);

    const { error } = await supabase
      .from('properties')
      .update({
        title: editForm.title,
        property_type: editForm.property_type,
        furnishing: editForm.furnishing || null,
        rent: parseFloat(editForm.rent),
        security_deposit: editForm.security_deposit ? parseFloat(editForm.security_deposit) : null,
        city: editForm.city,
        area: editForm.area,
        address: editForm.address || null,
        bedrooms: editForm.bedrooms ? parseInt(editForm.bedrooms) : null,
        bathrooms: editForm.bathrooms ? parseInt(editForm.bathrooms) : null,
        sqft: editForm.sqft ? parseInt(editForm.sqft) : null,
        description: editForm.description || null,
        status: editForm.status,
      })
      .eq('id', editingAd.id);

    if (error) {
      toast({
        title: 'Error updating ad',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Ad updated successfully',
      });
      setIsEditDialogOpen(false);
      setEditingAd(null);
      fetchMyAds();
    }
    setIsSaving(false);
  };

  const handleDeleteClick = (adId: string) => {
    setDeleteAdId(adId);
  };

  const handleConfirmDelete = async () => {
    if (!deleteAdId) return;

    setIsDeleting(true);
    const { error } = await supabase
      .from('properties')
      .delete()
      .eq('id', deleteAdId);

    if (error) {
      toast({
        title: 'Error deleting ad',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Ad deleted successfully',
      });
      fetchMyAds();
    }
    setIsDeleting(false);
    setDeleteAdId(null);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN').format(price);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Sign in to view your ads</h1>
          <p className="text-muted-foreground mb-6">You need to be logged in to see your posted properties.</p>
          <Button onClick={() => navigate('/auth')}>Sign In</Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate(-1)}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">My Ads</h1>
              <p className="text-muted-foreground">Manage your posted properties</p>
            </div>
          </div>
          <Button className="gap-2" onClick={() => navigate('/')}>
            <Plus className="h-4 w-4" />
            Post New Ad
          </Button>
        </div>

        {/* Ads List */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : myAds.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mb-4">
                <Plus className="h-10 w-10 text-muted-foreground" />
              </div>
              <h2 className="text-xl font-semibold text-foreground mb-2">No ads posted yet</h2>
              <p className="text-muted-foreground text-center max-w-md mb-6">
                Start posting your properties to reach thousands of potential tenants and buyers.
              </p>
              <Button onClick={() => navigate('/')}>
                <Plus className="h-4 w-4 mr-2" />
                Post Your First Ad
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {myAds.map((ad) => (
              <Card key={ad.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground text-lg">{ad.title}</h3>
                      <p className="text-sm text-muted-foreground">{ad.area}, {ad.city}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <p className="text-lg font-bold text-primary">₹{formatPrice(ad.rent)}/mo</p>
                        <span className="text-sm text-muted-foreground">
                          {ad.property_type.toUpperCase()} • {ad.bedrooms || 0} BHK • {ad.sqft || '-'} sqft
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={ad.status === 'active' ? 'default' : 'secondary'}>
                        {ad.status}
                      </Badge>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => navigate(`/property/${ad.id}`)}>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEditClick(ad)}>
                            <Edit2 className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            className="text-destructive"
                            onClick={() => handleDeleteClick(ad.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Property Ad</DialogTitle>
            <DialogDescription>
              Update the details of your property listing
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="edit-title">Title <span className="text-destructive">*</span></Label>
              <Input
                id="edit-title"
                value={editForm.title}
                onChange={(e) => handleEditFormChange('title', e.target.value)}
              />
            </div>

            {/* Property Type & Status */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Property Type <span className="text-destructive">*</span></Label>
                <Select
                  value={editForm.property_type}
                  onValueChange={(value) => handleEditFormChange('property_type', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {propertyTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select
                  value={editForm.status}
                  onValueChange={(value) => handleEditFormChange('status', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Furnishing */}
            <div className="space-y-2">
              <Label>Furnishing</Label>
              <Select
                value={editForm.furnishing}
                onValueChange={(value) => handleEditFormChange('furnishing', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select furnishing" />
                </SelectTrigger>
                <SelectContent>
                  {furnishingOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Rent & Deposit */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-rent">Rent (₹/month) <span className="text-destructive">*</span></Label>
                <Input
                  id="edit-rent"
                  type="number"
                  min="0"
                  value={editForm.rent}
                  onChange={(e) => handleEditFormChange('rent', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-deposit">Security Deposit (₹)</Label>
                <Input
                  id="edit-deposit"
                  type="number"
                  min="0"
                  value={editForm.security_deposit}
                  onChange={(e) => handleEditFormChange('security_deposit', e.target.value)}
                />
              </div>
            </div>

            {/* City & Area */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>City <span className="text-destructive">*</span></Label>
                <Select
                  value={editForm.city}
                  onValueChange={(value) => handleEditFormChange('city', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select city" />
                  </SelectTrigger>
                  <SelectContent>
                    {indianCities.map((city) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-area">Area <span className="text-destructive">*</span></Label>
                <Input
                  id="edit-area"
                  value={editForm.area}
                  onChange={(e) => handleEditFormChange('area', e.target.value)}
                />
              </div>
            </div>

            {/* Address */}
            <div className="space-y-2">
              <Label htmlFor="edit-address">Address</Label>
              <Input
                id="edit-address"
                value={editForm.address}
                onChange={(e) => handleEditFormChange('address', e.target.value)}
              />
            </div>

            {/* Bedrooms, Bathrooms, Sqft */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-bedrooms">Bedrooms</Label>
                <Input
                  id="edit-bedrooms"
                  type="number"
                  min="0"
                  value={editForm.bedrooms}
                  onChange={(e) => handleEditFormChange('bedrooms', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-bathrooms">Bathrooms</Label>
                <Input
                  id="edit-bathrooms"
                  type="number"
                  min="0"
                  value={editForm.bathrooms}
                  onChange={(e) => handleEditFormChange('bathrooms', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-sqft">Area (sqft)</Label>
                <Input
                  id="edit-sqft"
                  type="number"
                  min="0"
                  value={editForm.sqft}
                  onChange={(e) => handleEditFormChange('sqft', e.target.value)}
                />
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                rows={4}
                value={editForm.description}
                onChange={(e) => handleEditFormChange('description', e.target.value)}
              />
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4">
              <Button 
                variant="outline" 
                onClick={() => setIsEditDialogOpen(false)}
                disabled={isSaving}
              >
                Cancel
              </Button>
              <Button onClick={handleSaveEdit} disabled={isSaving}>
                {isSaving ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteAdId} onOpenChange={() => setDeleteAdId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this ad?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete your property listing.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleConfirmDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Footer />
    </div>
  );
};

export default MyAds;