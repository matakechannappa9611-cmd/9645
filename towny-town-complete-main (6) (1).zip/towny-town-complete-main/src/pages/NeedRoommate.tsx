import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, MapPin, IndianRupee, Filter, Phone, Mail, Calendar, Briefcase, X, MessageCircle, Send, Paperclip, Video, Image, Smile, Check, CheckCheck } from 'lucide-react';
import Header from '@/components/Header';
import MobileNav from '@/components/MobileNav';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Message {
  id: string;
  text?: string;
  videoUrl?: string;
  imageUrl?: string;
  sender: 'me' | 'them';
  time: string;
  status: 'sent' | 'delivered' | 'read';
}

interface RoommateListing {
  id: string;
  name: string;
  age: number;
  gender: string;
  occupation: string;
  location: string;
  city: string;
  budget: number;
  lookingFor: string;
  moveInDate: string;
  preferences: string[];
  avatar: string;
  postedAt: string;
  phone: string;
  email: string;
  bio: string;
}

// Mock roommate listings
const roommateListings: RoommateListing[] = [
  {
    id: '1',
    name: 'Rahul S.',
    age: 25,
    gender: 'Male',
    occupation: 'Software Engineer',
    location: 'Koramangala',
    city: 'Bangalore',
    budget: 15000,
    lookingFor: 'Male roommate',
    moveInDate: 'Immediate',
    preferences: ['Non-smoker', 'Vegetarian', 'Working Professional'],
    avatar: '',
    postedAt: '2 days ago',
    phone: '+91 98765 43210',
    email: 'rahul.s@email.com',
    bio: 'Software engineer working at a tech startup. Looking for a clean and quiet roommate who respects personal space.',
  },
  {
    id: '2',
    name: 'Priya M.',
    age: 24,
    gender: 'Female',
    occupation: 'Marketing Executive',
    location: 'Indiranagar',
    city: 'Bangalore',
    budget: 12000,
    lookingFor: 'Female roommate',
    moveInDate: '1st Jan 2025',
    preferences: ['Non-smoker', 'Clean', 'Quiet'],
    avatar: '',
    postedAt: '1 day ago',
    phone: '+91 98765 43211',
    email: 'priya.m@email.com',
    bio: 'Marketing professional who values cleanliness and a peaceful environment. Love cooking on weekends.',
  },
  {
    id: '3',
    name: 'Amit K.',
    age: 27,
    gender: 'Male',
    occupation: 'Data Analyst',
    location: 'HSR Layout',
    city: 'Bangalore',
    budget: 18000,
    lookingFor: 'Any roommate',
    moveInDate: '15th Jan 2025',
    preferences: ['Working Professional', 'Pet-friendly'],
    avatar: '',
    postedAt: '3 days ago',
    phone: '+91 98765 43212',
    email: 'amit.k@email.com',
    bio: 'Data analyst who works flexible hours. Have a small dog. Looking for a pet-friendly roommate.',
  },
  {
    id: '4',
    name: 'Sneha R.',
    age: 23,
    gender: 'Female',
    occupation: 'Student',
    location: 'BTM Layout',
    city: 'Bangalore',
    budget: 8000,
    lookingFor: 'Female roommate',
    moveInDate: 'Immediate',
    preferences: ['Student', 'Non-smoker', 'Vegetarian'],
    avatar: '',
    postedAt: '5 hours ago',
    phone: '+91 98765 43213',
    email: 'sneha.r@email.com',
    bio: 'Final year engineering student. Prefer a quiet study environment. Looking for a like-minded roommate.',
  },
];

const NeedRoommate = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('roommate');
  const [searchLocation, setSearchLocation] = useState('');
  const [genderFilter, setGenderFilter] = useState('all');
  const [selectedRoommate, setSelectedRoommate] = useState<RoommateListing | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatRoommate, setChatRoommate] = useState<RoommateListing | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'home') navigate('/');
    else if (tab === 'messaging') navigate('/messages');
    else if (tab === 'notifications') navigate('/notifications');
    else if (tab === 'saved') navigate('/saved');
    else if (tab === 'roommate') navigate('/need-roommate');
  };

  const filteredListings = roommateListings.filter((listing) => {
    const locationMatch = !searchLocation || 
      listing.location.toLowerCase().includes(searchLocation.toLowerCase()) ||
      listing.city.toLowerCase().includes(searchLocation.toLowerCase());
    
    const genderMatch = genderFilter === 'all' || 
      listing.gender.toLowerCase() === genderFilter.toLowerCase();
    
    return locationMatch && genderMatch;
  });

  const handleViewProfile = (listing: RoommateListing) => {
    setSelectedRoommate(listing);
    setIsProfileOpen(true);
  };

  const handleOpenChat = (listing: RoommateListing) => {
    setChatRoommate(listing);
    setMessages([
      {
        id: '1',
        text: `Hi! I'm interested in being your roommate. Is the room still available?`,
        sender: 'me',
        time: '10:30 AM',
        status: 'read',
      },
      {
        id: '2',
        text: `Hello! Yes, the room is still available. Would you like to schedule a visit?`,
        sender: 'them',
        time: '10:32 AM',
        status: 'read',
      },
    ]);
    setIsChatOpen(true);
    setIsProfileOpen(false);
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    const message: Message = {
      id: Date.now().toString(),
      text: newMessage,
      sender: 'me',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
    };
    
    setMessages(prev => [...prev, message]);
    setNewMessage('');
    
    // Simulate message delivery
    setTimeout(() => {
      setMessages(prev => 
        prev.map(m => m.id === message.id ? { ...m, status: 'delivered' } : m)
      );
    }, 500);
    
    // Simulate read receipt
    setTimeout(() => {
      setMessages(prev => 
        prev.map(m => m.id === message.id ? { ...m, status: 'read' } : m)
      );
    }, 1000);
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) {
        toast({
          title: 'File too large',
          description: 'Please select a video under 50MB',
          variant: 'destructive',
        });
        return;
      }
      
      const videoUrl = URL.createObjectURL(file);
      const message: Message = {
        id: Date.now().toString(),
        videoUrl,
        sender: 'me',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'sent',
      };
      
      setMessages(prev => [...prev, message]);
      
      toast({
        title: 'Video sent!',
        description: 'Your video has been sent successfully.',
      });
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      const message: Message = {
        id: Date.now().toString(),
        imageUrl,
        sender: 'me',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'sent',
      };
      
      setMessages(prev => [...prev, message]);
    }
  };

  const renderMessageStatus = (status: Message['status']) => {
    if (status === 'sent') return <Check className="w-3 h-3 text-muted-foreground" />;
    if (status === 'delivered') return <CheckCheck className="w-3 h-3 text-muted-foreground" />;
    if (status === 'read') return <CheckCheck className="w-3 h-3 text-blue-500" />;
    return null;
  };

  return (
    <div className="min-h-screen bg-background pb-16 md:pb-0">
      <Header activeTab={activeTab} onTabChange={handleTabChange} />

      <main className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Users className="w-6 h-6 text-primary" />
              Need Roommate
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Find your perfect roommate or flatmate
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-6">
          <div className="relative flex-1 min-w-[200px] max-w-[300px]">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by location..."
              value={searchLocation}
              onChange={(e) => setSearchLocation(e.target.value)}
              className="pl-10 rounded-lg"
            />
          </div>
          
          <Select value={genderFilter} onValueChange={setGenderFilter}>
            <SelectTrigger className="w-[140px] rounded-lg">
              <SelectValue placeholder="Gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" className="gap-2 rounded-lg">
            <Filter className="w-4 h-4" />
            More Filters
          </Button>
        </div>

        {/* Listings */}
        {filteredListings.length === 0 ? (
          <div className="text-center py-16">
            <Users className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-foreground mb-2">No roommates found</h2>
            <p className="text-muted-foreground">Try adjusting your filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredListings.map((listing) => (
              <Card key={listing.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-14 h-14">
                      <AvatarImage src={listing.avatar} />
                      <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                        {listing.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-foreground">{listing.name}</h3>
                        <span className="text-xs text-muted-foreground">{listing.postedAt}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {listing.age} yrs • {listing.occupation}
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-4 h-4 text-primary" />
                      <span>{listing.location}, {listing.city}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <IndianRupee className="w-4 h-4 text-primary" />
                      <span>Budget: ₹{listing.budget.toLocaleString('en-IN')}/mo</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="w-4 h-4 text-primary" />
                      <span>{listing.lookingFor}</span>
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {listing.preferences.slice(0, 3).map((pref) => (
                      <Badge key={pref} variant="secondary" className="text-xs">
                        {pref}
                      </Badge>
                    ))}
                  </div>

                  <div className="mt-4 flex gap-2">
                    <Button size="sm" className="flex-1" onClick={() => handleOpenChat(listing)}>
                      <MessageCircle className="w-4 h-4 mr-1" />
                      Contact
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1" onClick={() => handleViewProfile(listing)}>
                      View Profile
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      {/* Profile Dialog */}
      <Dialog open={isProfileOpen} onOpenChange={setIsProfileOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Avatar className="h-14 w-14">
                <AvatarImage src={selectedRoommate?.avatar} />
                <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                  {selectedRoommate?.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div>
                <span className="block">{selectedRoommate?.name}</span>
                <span className="text-sm font-normal text-muted-foreground">
                  {selectedRoommate?.age} yrs • {selectedRoommate?.gender}
                </span>
              </div>
            </DialogTitle>
            <DialogDescription className="sr-only">
              Roommate profile details
            </DialogDescription>
          </DialogHeader>
          
          {selectedRoommate && (
            <div className="space-y-4 mt-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedRoommate.occupation}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedRoommate.location}, {selectedRoommate.city}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <IndianRupee className="h-4 w-4 text-muted-foreground" />
                  <span>Budget: ₹{selectedRoommate.budget.toLocaleString('en-IN')}/month</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Move-in: {selectedRoommate.moveInDate}</span>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">About</h4>
                <p className="text-sm text-muted-foreground">{selectedRoommate.bio}</p>
              </div>

              <div>
                <h4 className="font-medium mb-2">Preferences</h4>
                <div className="flex flex-wrap gap-1">
                  {selectedRoommate.preferences.map((pref) => (
                    <Badge key={pref} variant="secondary" className="text-xs">
                      {pref}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t">
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedRoommate.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedRoommate.email}</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setIsProfileOpen(false)}>
                  <X className="h-4 w-4 mr-2" />
                  Close
                </Button>
                <Button className="flex-1" onClick={() => handleOpenChat(selectedRoommate)}>
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Chat
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* WhatsApp-style Chat Dialog */}
      <Dialog open={isChatOpen} onOpenChange={setIsChatOpen}>
        <DialogContent className="sm:max-w-md p-0 h-[600px] max-h-[80vh] flex flex-col">
          {/* Chat Header */}
          <div className="bg-primary p-3 flex items-center gap-3 rounded-t-lg">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-primary-foreground hover:bg-primary/80"
              onClick={() => setIsChatOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
            <Avatar className="h-10 w-10">
              <AvatarImage src={chatRoommate?.avatar} />
              <AvatarFallback className="bg-primary-foreground/20 text-primary-foreground">
                {chatRoommate?.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="font-semibold text-primary-foreground">{chatRoommate?.name}</h3>
              <p className="text-xs text-primary-foreground/70">Online</p>
            </div>
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80">
              <Phone className="h-5 w-5" />
            </Button>
          </div>

          {/* Chat Messages */}
          <ScrollArea className="flex-1 p-4 bg-[#ece5dd] dark:bg-zinc-900">
            <div className="space-y-3">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'me' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.sender === 'me'
                        ? 'bg-[#dcf8c6] dark:bg-emerald-800 text-foreground'
                        : 'bg-white dark:bg-zinc-800 text-foreground'
                    }`}
                  >
                    {message.text && <p className="text-sm">{message.text}</p>}
                    {message.imageUrl && (
                      <img 
                        src={message.imageUrl} 
                        alt="Shared image" 
                        className="rounded-lg max-w-full max-h-48 object-cover"
                      />
                    )}
                    {message.videoUrl && (
                      <video 
                        src={message.videoUrl} 
                        controls 
                        className="rounded-lg max-w-full max-h-48"
                      />
                    )}
                    <div className="flex items-center justify-end gap-1 mt-1">
                      <span className="text-[10px] text-muted-foreground">{message.time}</span>
                      {message.sender === 'me' && renderMessageStatus(message.status)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Chat Input */}
          <div className="p-3 bg-background border-t flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
            />
            <input
              type="file"
              ref={videoInputRef}
              accept="video/*"
              className="hidden"
              onChange={handleVideoUpload}
            />
            
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-muted-foreground"
              onClick={() => fileInputRef.current?.click()}
            >
              <Image className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-muted-foreground"
              onClick={() => videoInputRef.current?.click()}
            >
              <Video className="h-5 w-5" />
            </Button>
            
            <Input
              placeholder="Type a message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1 rounded-full"
            />
            
            <Button 
              size="icon" 
              className="rounded-full bg-primary"
              onClick={handleSendMessage}
              disabled={!newMessage.trim()}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <MobileNav activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  );
};

export default NeedRoommate;
