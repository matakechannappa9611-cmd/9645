import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Coins, ArrowDownCircle, ArrowUpCircle, Gift, Clock, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useAuth } from '@/contexts/AuthContext';
import { useTownyCoins } from '@/hooks/useTownyCoins';
import { useToast } from '@/hooks/use-toast';

const CoinsPage = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const {
    balance,
    totalEarned,
    totalWithdrawn,
    transactions,
    withdrawalRequests,
    loading,
    canWithdraw,
    requestWithdrawal,
    refreshCoins,
  } = useTownyCoins();

  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [upiId, setUpiId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  const handleWithdraw = async () => {
    const amount = parseInt(withdrawAmount);
    
    if (!amount || amount < 100) {
      toast({
        title: 'Invalid Amount',
        description: 'Minimum withdrawal is 100 coins',
        variant: 'destructive',
      });
      return;
    }

    if (!upiId || !upiId.includes('@')) {
      toast({
        title: 'Invalid UPI ID',
        description: 'Please enter a valid UPI ID',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    const result = await requestWithdrawal(amount, upiId);
    setIsSubmitting(false);

    if (result.success) {
      toast({
        title: 'Withdrawal Requested',
        description: `Your withdrawal of ${amount} coins has been submitted`,
      });
      setWithdrawAmount('');
      setUpiId('');
    } else {
      toast({
        title: 'Withdrawal Failed',
        description: result.error,
        variant: 'destructive',
      });
    }
  };

  const getTransactionIcon = (type: string) => {
    if (type === 'earn') return <ArrowDownCircle className="w-4 h-4 text-green-500" />;
    return <ArrowUpCircle className="w-4 h-4 text-red-500" />;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="gap-1"><Clock className="w-3 h-3" />Pending</Badge>;
      case 'approved':
        return <Badge className="gap-1 bg-blue-500"><CheckCircle2 className="w-3 h-3" />Approved</Badge>;
      case 'completed':
        return <Badge className="gap-1 bg-green-500"><CheckCircle2 className="w-3 h-3" />Completed</Badge>;
      case 'rejected':
        return <Badge variant="destructive" className="gap-1"><AlertCircle className="w-3 h-3" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Back Button */}
        <Button
          variant="ghost"
          className="mb-4 gap-2"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
            <Coins className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Towny Coins</h1>
            <p className="text-muted-foreground">Earn & withdraw your rewards</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <Coins className="w-6 h-6 mx-auto text-amber-500 mb-2" />
                <p className="text-2xl font-bold">{balance}</p>
                <p className="text-xs text-muted-foreground">Balance</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <ArrowDownCircle className="w-6 h-6 mx-auto text-green-500 mb-2" />
                <p className="text-2xl font-bold">{totalEarned}</p>
                <p className="text-xs text-muted-foreground">Total Earned</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <ArrowUpCircle className="w-6 h-6 mx-auto text-blue-500 mb-2" />
                <p className="text-2xl font-bold">{totalWithdrawn}</p>
                <p className="text-xs text-muted-foreground">Withdrawn</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Earn More */}
        <Card className="mb-6 bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Gift className="w-8 h-8 text-primary" />
                <div>
                  <p className="font-medium">Earn 10 coins per referral!</p>
                  <p className="text-sm text-muted-foreground">Invite friends and earn rewards</p>
                </div>
              </div>
              <Button onClick={() => navigate('/referrals')} size="sm">
                Refer Now
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Withdraw Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <ArrowUpCircle className="w-5 h-5" />
              Withdraw Coins
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
              <p className="text-sm flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                Minimum withdrawal: <strong>100 coins</strong>
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                placeholder="Enter amount (min 100)"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                min={100}
                max={balance}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="upi">UPI ID</Label>
              <Input
                id="upi"
                type="text"
                placeholder="yourname@upi"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
              />
            </div>

            <Button
              onClick={handleWithdraw}
              disabled={!canWithdraw || isSubmitting}
              className="w-full"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                'Request Withdrawal'
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Withdrawal Requests */}
        {withdrawalRequests.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Withdrawal History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {withdrawalRequests.map((request) => (
                  <div
                    key={request.id}
                    className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                  >
                    <div>
                      <p className="font-medium">{request.amount} coins</p>
                      <p className="text-xs text-muted-foreground">{request.upi_id}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(request.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    {getStatusBadge(request.status)}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Transaction History */}
        {transactions.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Transaction History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      {getTransactionIcon(tx.transaction_type)}
                      <div>
                        <p className="font-medium text-sm">{tx.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(tx.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <span className={`font-bold ${tx.amount > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {tx.amount > 0 ? '+' : ''}{tx.amount}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {transactions.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <Coins className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No transactions yet</p>
              <p className="text-sm text-muted-foreground">Start referring friends to earn coins!</p>
            </CardContent>
          </Card>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default CoinsPage;
