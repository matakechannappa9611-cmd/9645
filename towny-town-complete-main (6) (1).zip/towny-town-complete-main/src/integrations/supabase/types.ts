export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      ai_chat_conversations: {
        Row: {
          budget: string | null
          created_at: string
          id: string
          location: string | null
          messages: Json
          requirement: string | null
          session_id: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          budget?: string | null
          created_at?: string
          id?: string
          location?: string | null
          messages?: Json
          requirement?: string | null
          session_id: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          budget?: string | null
          created_at?: string
          id?: string
          location?: string | null
          messages?: Json
          requirement?: string | null
          session_id?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      chat_leads: {
        Row: {
          budget: string
          created_at: string
          id: string
          location: string
          requirement: string
        }
        Insert: {
          budget: string
          created_at?: string
          id?: string
          location: string
          requirement: string
        }
        Update: {
          budget?: string
          created_at?: string
          id?: string
          location?: string
          requirement?: string
        }
        Relationships: []
      }
      coin_transactions: {
        Row: {
          amount: number
          created_at: string
          description: string | null
          id: string
          source: string
          transaction_type: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          description?: string | null
          id?: string
          source: string
          transaction_type: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string | null
          id?: string
          source?: string
          transaction_type?: string
          user_id?: string
        }
        Relationships: []
      }
      daily_posts: {
        Row: {
          created_at: string | null
          id: string
          post_count: number | null
          post_date: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          post_count?: number | null
          post_date?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          post_count?: number | null
          post_date?: string | null
          user_id?: string
        }
        Relationships: []
      }
      device_tracking: {
        Row: {
          action_type: string | null
          created_at: string | null
          device_fingerprint: string | null
          id: string
          ip_address: unknown
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action_type?: string | null
          created_at?: string | null
          device_fingerprint?: string | null
          id?: string
          ip_address?: unknown
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action_type?: string | null
          created_at?: string | null
          device_fingerprint?: string | null
          id?: string
          ip_address?: unknown
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      email_subscribers: {
        Row: {
          email: string
          id: string
          is_active: boolean
          subscribed_at: string
        }
        Insert: {
          email: string
          id?: string
          is_active?: boolean
          subscribed_at?: string
        }
        Update: {
          email?: string
          id?: string
          is_active?: boolean
          subscribed_at?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          content: string
          created_at: string
          id: string
          is_read: boolean
          property_id: string | null
          receiver_id: string
          sender_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          is_read?: boolean
          property_id?: string | null
          receiver_id: string
          sender_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          is_read?: boolean
          property_id?: string | null
          receiver_id?: string
          sender_id?: string
        }
        Relationships: []
      }
      otp_codes: {
        Row: {
          code: string
          created_at: string
          email: string
          expires_at: string
          id: string
          phone: string | null
          type: string
          verified: boolean | null
        }
        Insert: {
          code: string
          created_at?: string
          email: string
          expires_at: string
          id?: string
          phone?: string | null
          type?: string
          verified?: boolean | null
        }
        Update: {
          code?: string
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          phone?: string | null
          type?: string
          verified?: boolean | null
        }
        Relationships: []
      }
      phone_patterns: {
        Row: {
          created_at: string | null
          flagged: boolean | null
          id: string
          phone_prefix: string
          registration_count: number | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          flagged?: boolean | null
          id?: string
          phone_prefix: string
          registration_count?: number | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          flagged?: boolean | null
          id?: string
          phone_prefix?: string
          registration_count?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          id: string
          is_voip_number: boolean | null
          location: string | null
          name: string | null
          phone: string | null
          phone_verified: boolean | null
          phone_verified_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          id?: string
          is_voip_number?: boolean | null
          location?: string | null
          name?: string | null
          phone?: string | null
          phone_verified?: boolean | null
          phone_verified_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          id?: string
          is_voip_number?: boolean | null
          location?: string | null
          name?: string | null
          phone?: string | null
          phone_verified?: boolean | null
          phone_verified_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      properties: {
        Row: {
          address: string | null
          area: string
          available_date: string | null
          bathrooms: number | null
          bedrooms: number | null
          city: string
          created_at: string
          description: string | null
          facing: string | null
          furnishing: string | null
          hidden_reason: string | null
          id: string
          images: string[] | null
          is_hidden: boolean | null
          meal_included: string | null
          plot_area: string | null
          property_type: string
          rent: number
          report_count: number | null
          room_type: string | null
          security_deposit: number | null
          sharing_type: string | null
          sqft: number | null
          star_rating: string | null
          status: string | null
          tenant_type: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          address?: string | null
          area: string
          available_date?: string | null
          bathrooms?: number | null
          bedrooms?: number | null
          city: string
          created_at?: string
          description?: string | null
          facing?: string | null
          furnishing?: string | null
          hidden_reason?: string | null
          id?: string
          images?: string[] | null
          is_hidden?: boolean | null
          meal_included?: string | null
          plot_area?: string | null
          property_type: string
          rent: number
          report_count?: number | null
          room_type?: string | null
          security_deposit?: number | null
          sharing_type?: string | null
          sqft?: number | null
          star_rating?: string | null
          status?: string | null
          tenant_type?: string | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          address?: string | null
          area?: string
          available_date?: string | null
          bathrooms?: number | null
          bedrooms?: number | null
          city?: string
          created_at?: string
          description?: string | null
          facing?: string | null
          furnishing?: string | null
          hidden_reason?: string | null
          id?: string
          images?: string[] | null
          is_hidden?: boolean | null
          meal_included?: string | null
          plot_area?: string | null
          property_type?: string
          rent?: number
          report_count?: number | null
          room_type?: string | null
          security_deposit?: number | null
          sharing_type?: string | null
          sqft?: number | null
          star_rating?: string | null
          status?: string | null
          tenant_type?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      property_reports: {
        Row: {
          created_at: string | null
          details: string | null
          id: string
          property_id: string
          reason: Database["public"]["Enums"]["report_reason"]
          reporter_id: string
        }
        Insert: {
          created_at?: string | null
          details?: string | null
          id?: string
          property_id: string
          reason: Database["public"]["Enums"]["report_reason"]
          reporter_id: string
        }
        Update: {
          created_at?: string | null
          details?: string | null
          id?: string
          property_id?: string
          reason?: Database["public"]["Enums"]["report_reason"]
          reporter_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "property_reports_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
        ]
      }
      referral_codes: {
        Row: {
          code: string
          created_at: string
          id: string
          successful_referrals: number
          total_referrals: number
          user_id: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          successful_referrals?: number
          total_referrals?: number
          user_id: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          successful_referrals?: number
          total_referrals?: number
          user_id?: string
        }
        Relationships: []
      }
      referrals: {
        Row: {
          completed_at: string | null
          created_at: string
          id: string
          referral_code: string
          referred_user_id: string | null
          referrer_id: string
          status: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          id?: string
          referral_code: string
          referred_user_id?: string | null
          referrer_id: string
          status?: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          id?: string
          referral_code?: string
          referred_user_id?: string | null
          referrer_id?: string
          status?: string
        }
        Relationships: []
      }
      user_badges: {
        Row: {
          badge_type: string
          expires_at: string | null
          id: string
          user_id: string
          verification_data: Json | null
          verified_at: string | null
        }
        Insert: {
          badge_type: string
          expires_at?: string | null
          id?: string
          user_id: string
          verification_data?: Json | null
          verified_at?: string | null
        }
        Update: {
          badge_type?: string
          expires_at?: string | null
          id?: string
          user_id?: string
          verification_data?: Json | null
          verified_at?: string | null
        }
        Relationships: []
      }
      user_boosts: {
        Row: {
          boost_type: string
          created_at: string
          expires_at: string
          id: string
          is_active: boolean
          source: string
          user_id: string
        }
        Insert: {
          boost_type?: string
          created_at?: string
          expires_at: string
          id?: string
          is_active?: boolean
          source?: string
          user_id: string
        }
        Update: {
          boost_type?: string
          created_at?: string
          expires_at?: string
          id?: string
          is_active?: boolean
          source?: string
          user_id?: string
        }
        Relationships: []
      }
      user_coins: {
        Row: {
          balance: number
          created_at: string
          id: string
          total_earned: number
          total_withdrawn: number
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          created_at?: string
          id?: string
          total_earned?: number
          total_withdrawn?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          created_at?: string
          id?: string
          total_earned?: number
          total_withdrawn?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_trust: {
        Row: {
          created_at: string | null
          daily_post_limit: number | null
          id: string
          is_suspended: boolean | null
          suspended_until: string | null
          suspension_reason: string | null
          total_posts: number | null
          total_reports_made: number | null
          total_reports_received: number | null
          trust_level: Database["public"]["Enums"]["user_trust_level"] | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          daily_post_limit?: number | null
          id?: string
          is_suspended?: boolean | null
          suspended_until?: string | null
          suspension_reason?: string | null
          total_posts?: number | null
          total_reports_made?: number | null
          total_reports_received?: number | null
          trust_level?: Database["public"]["Enums"]["user_trust_level"] | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          daily_post_limit?: number | null
          id?: string
          is_suspended?: boolean | null
          suspended_until?: string | null
          suspension_reason?: string | null
          total_posts?: number | null
          total_reports_made?: number | null
          total_reports_received?: number | null
          trust_level?: Database["public"]["Enums"]["user_trust_level"] | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      withdrawal_requests: {
        Row: {
          amount: number
          created_at: string
          id: string
          processed_at: string | null
          status: string
          upi_id: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          processed_at?: string | null
          status?: string
          upi_id: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          processed_at?: string | null
          status?: string
          upi_id?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      award_referral_coins: {
        Args: { coins_amount?: number; referrer_user_id: string }
        Returns: boolean
      }
      can_post_property: { Args: { user_id_param: string }; Returns: Json }
      cleanup_expired_otps: { Args: never; Returns: undefined }
      generate_referral_code: {
        Args: { user_id_param: string }
        Returns: string
      }
      grant_phone_verified_badge: {
        Args: { user_id_param: string }
        Returns: boolean
      }
      has_active_boost: { Args: { user_id_param: string }; Returns: boolean }
      process_referral: {
        Args: { new_user_id: string; referral_code_param: string }
        Returns: boolean
      }
      record_property_post: {
        Args: { user_id_param: string }
        Returns: boolean
      }
      request_coin_withdrawal: {
        Args: {
          amount_param: number
          upi_id_param: string
          user_id_param: string
        }
        Returns: boolean
      }
      upgrade_trust_level: {
        Args: { user_id_param: string }
        Returns: Database["public"]["Enums"]["user_trust_level"]
      }
    }
    Enums: {
      report_reason:
        | "broker"
        | "fake_price"
        | "already_rented"
        | "spam"
        | "misleading_photos"
        | "wrong_location"
        | "other"
      user_trust_level: "new" | "verified" | "trusted" | "broker_flagged"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      report_reason: [
        "broker",
        "fake_price",
        "already_rented",
        "spam",
        "misleading_photos",
        "wrong_location",
        "other",
      ],
      user_trust_level: ["new", "verified", "trusted", "broker_flagged"],
    },
  },
} as const
