import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface BoostedUser {
  user_id: string;
  expires_at: string;
}

export const useBoostedUsers = () => {
  const [boostedUserIds, setBoostedUserIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBoostedUsers = async () => {
      try {
        const { data, error } = await supabase
          .from('user_boosts')
          .select('user_id, expires_at')
          .eq('is_active', true)
          .gt('expires_at', new Date().toISOString());

        if (error) {
          console.error('Error fetching boosted users:', error);
          return;
        }

        const userIds = new Set((data as BoostedUser[])?.map(b => b.user_id) || []);
        setBoostedUserIds(userIds);
      } catch (error) {
        console.error('Error fetching boosted users:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchBoostedUsers();

    // Refresh every 5 minutes
    const interval = setInterval(fetchBoostedUsers, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const isUserBoosted = (userId: string) => boostedUserIds.has(userId);

  return { boostedUserIds, isUserBoosted, loading };
};
