import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface ReferralCode {
  code: string;
  total_referrals: number;
  successful_referrals: number;
}

interface UserBoost {
  id: string;
  boost_type: string;
  source: string;
  expires_at: string;
  is_active: boolean;
  created_at: string;
}

interface ReferralStats {
  referralCode: ReferralCode | null;
  activeBoosts: UserBoost[];
  hasActiveBoost: boolean;
  boostExpiresAt: Date | null;
  monthlyReferralsUsed: number;
  maxMonthlyReferrals: number;
  loading: boolean;
}

export const useReferral = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<ReferralStats>({
    referralCode: null,
    activeBoosts: [],
    hasActiveBoost: false,
    boostExpiresAt: null,
    monthlyReferralsUsed: 0,
    maxMonthlyReferrals: 3,
    loading: true,
  });

  const fetchReferralCode = async () => {
    if (!user) return null;

    // Try to get existing code
    const { data: existing } = await supabase
      .from('referral_codes')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (existing) {
      return existing;
    }

    // Generate new code
    const { data: newCode } = await supabase.rpc('generate_referral_code', {
      user_id_param: user.id,
    });

    if (newCode) {
      const { data: created } = await supabase
        .from('referral_codes')
        .select('*')
        .eq('user_id', user.id)
        .single();
      return created;
    }

    return null;
  };

  const fetchActiveBoosts = async () => {
    if (!user) return [];

    const { data } = await supabase
      .from('user_boosts')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_active', true)
      .gt('expires_at', new Date().toISOString())
      .order('expires_at', { ascending: true });

    return data || [];
  };

  const fetchStats = async () => {
    if (!user) {
      setStats((prev) => ({ ...prev, loading: false }));
      return;
    }

    try {
      const [referralCode, activeBoosts] = await Promise.all([
        fetchReferralCode(),
        fetchActiveBoosts(),
      ]);

      // Count monthly referrals
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { count } = await supabase
        .from('user_boosts')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('source', 'referral')
        .gte('created_at', startOfMonth.toISOString());

      const hasActiveBoost = activeBoosts.length > 0;
      const boostExpiresAt = hasActiveBoost
        ? new Date(activeBoosts[0].expires_at)
        : null;

      setStats({
        referralCode: referralCode as ReferralCode | null,
        activeBoosts: activeBoosts as UserBoost[],
        hasActiveBoost,
        boostExpiresAt,
        monthlyReferralsUsed: count || 0,
        maxMonthlyReferrals: 3,
        loading: false,
      });
    } catch (error) {
      console.error('Error fetching referral stats:', error);
      setStats((prev) => ({ ...prev, loading: false }));
    }
  };

  useEffect(() => {
    fetchStats();
  }, [user]);

  const getReferralLink = () => {
    if (!stats.referralCode?.code) return '';
    return `${window.location.origin}/auth?ref=${stats.referralCode.code}`;
  };

  const shareViaWhatsApp = () => {
    const link = getReferralLink();
    const message = `🏠 List your property on Towny and get amazing visibility!\n\nUse my referral code: ${stats.referralCode?.code}\n\n${link}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  const copyReferralLink = async () => {
    const link = getReferralLink();
    try {
      await navigator.clipboard.writeText(link);
      return true;
    } catch {
      return false;
    }
  };

  const copyReferralCode = async () => {
    if (!stats.referralCode?.code) return false;
    try {
      await navigator.clipboard.writeText(stats.referralCode.code);
      return true;
    } catch {
      return false;
    }
  };

  return {
    ...stats,
    getReferralLink,
    shareViaWhatsApp,
    copyReferralLink,
    copyReferralCode,
    refreshStats: fetchStats,
  };
};
