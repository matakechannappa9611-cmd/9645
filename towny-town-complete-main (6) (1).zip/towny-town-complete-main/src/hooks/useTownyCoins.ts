import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface UserCoins {
  balance: number;
  total_earned: number;
  total_withdrawn: number;
}

interface CoinTransaction {
  id: string;
  amount: number;
  transaction_type: string;
  source: string;
  description: string;
  created_at: string;
}

interface WithdrawalRequest {
  id: string;
  amount: number;
  upi_id: string;
  status: string;
  created_at: string;
  processed_at: string | null;
}

interface TownyCoinsState {
  coins: UserCoins | null;
  transactions: CoinTransaction[];
  withdrawalRequests: WithdrawalRequest[];
  loading: boolean;
}

export const useTownyCoins = () => {
  const { user } = useAuth();
  const [state, setState] = useState<TownyCoinsState>({
    coins: null,
    transactions: [],
    withdrawalRequests: [],
    loading: true,
  });

  const fetchCoins = async () => {
    if (!user) {
      setState(prev => ({ ...prev, loading: false }));
      return;
    }

    try {
      // Fetch coin balance
      const { data: coinsData } = await supabase
        .from('user_coins')
        .select('*')
        .eq('user_id', user.id)
        .single();

      // Fetch transactions
      const { data: transactionsData } = await supabase
        .from('coin_transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20);

      // Fetch withdrawal requests
      const { data: withdrawalsData } = await supabase
        .from('withdrawal_requests')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      setState({
        coins: coinsData as UserCoins | null,
        transactions: (transactionsData || []) as CoinTransaction[],
        withdrawalRequests: (withdrawalsData || []) as WithdrawalRequest[],
        loading: false,
      });
    } catch (error) {
      console.error('Error fetching coins:', error);
      setState(prev => ({ ...prev, loading: false }));
    }
  };

  useEffect(() => {
    fetchCoins();
  }, [user]);

  const requestWithdrawal = async (amount: number, upiId: string) => {
    if (!user) return { success: false, error: 'Not logged in' };

    if (amount < 100) {
      return { success: false, error: 'Minimum withdrawal is 100 coins' };
    }

    if (!state.coins || state.coins.balance < amount) {
      return { success: false, error: 'Insufficient balance' };
    }

    try {
      const { data, error } = await supabase.rpc('request_coin_withdrawal', {
        user_id_param: user.id,
        amount_param: amount,
        upi_id_param: upiId,
      });

      if (error) throw error;

      if (data) {
        await fetchCoins();
        return { success: true };
      } else {
        return { success: false, error: 'Failed to process withdrawal' };
      }
    } catch (error: any) {
      console.error('Withdrawal error:', error);
      return { success: false, error: error.message };
    }
  };

  return {
    ...state,
    balance: state.coins?.balance || 0,
    totalEarned: state.coins?.total_earned || 0,
    totalWithdrawn: state.coins?.total_withdrawn || 0,
    canWithdraw: (state.coins?.balance || 0) >= 100,
    requestWithdrawal,
    refreshCoins: fetchCoins,
  };
};
