export interface Property {
  id: string;
  title: string;
  location: string;
  city: string;
  price: number;
  priceUnit: 'mo' | 'total';
  type: 'BHK' | 'PG' | 'Hotel' | 'Commercial' | 'Plot';
  bhk?: number;
  bedrooms: number;
  bathrooms: number;
  sqft: number;
  image: string;
  isFeatured?: boolean;
  isNew?: boolean;
  tenantType?: 'bachelors' | 'family' | 'anyone';
  userId?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export type PropertyType = 'All' | 'BHK' | 'PG' | 'Hotel' | 'Commercial' | 'Plot';
export type TenantType = 'All' | 'bachelors' | 'family' | 'anyone';

export interface SearchFilters {
  location: string;
  bhkType: string;
  propertyType: PropertyType;
  tenantType: TenantType;
  nearMe: boolean;
}
