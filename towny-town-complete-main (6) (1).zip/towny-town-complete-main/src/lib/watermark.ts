/**
 * Adds a "Towny" watermark to an image
 */
export const addWatermark = (imageDataUrl: string): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }
      
      // Set canvas dimensions to match image
      canvas.width = img.width;
      canvas.height = img.height;
      
      // Draw original image
      ctx.drawImage(img, 0, 0);
      
      // Calculate watermark size based on image dimensions
      const fontSize = Math.max(img.width * 0.08, 24); // 8% of width, min 24px
      
      // Configure watermark text style
      ctx.font = `bold ${fontSize}px Arial, sans-serif`;
      ctx.textAlign = 'right';
      ctx.textBaseline = 'bottom';
      
      // Position watermark in bottom-right corner with padding
      const padding = fontSize * 0.5;
      const x = canvas.width - padding;
      const y = canvas.height - padding;
      
      // Add semi-transparent background for better visibility
      const text = 'Towny';
      const textMetrics = ctx.measureText(text);
      const textWidth = textMetrics.width;
      const textHeight = fontSize;
      
      // Draw background rectangle
      ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
      ctx.fillRect(
        x - textWidth - padding * 0.5,
        y - textHeight - padding * 0.2,
        textWidth + padding,
        textHeight + padding * 0.4
      );
      
      // Draw watermark text with shadow for visibility
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 4;
      ctx.shadowOffsetX = 2;
      ctx.shadowOffsetY = 2;
      
      // Draw text in white
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.fillText(text, x, y);
      
      // Reset shadow
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
      
      // Convert canvas to data URL
      const watermarkedImage = canvas.toDataURL('image/jpeg', 0.9);
      resolve(watermarkedImage);
    };
    
    img.onerror = () => {
      reject(new Error('Failed to load image'));
    };
    
    img.src = imageDataUrl;
  });
};
