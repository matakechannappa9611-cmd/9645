import { initializeApp } from 'firebase/app';
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from 'firebase/auth';

// Extend window interface for global recaptchaVerifier
declare global {
  interface Window {
    recaptchaVerifier: RecaptchaVerifier | null;
    confirmationResult: ConfirmationResult | null;
  }
}

const firebaseConfig = {
  apiKey: "AIzaSyA4b53-g2ZRvRWbs1ib8cj6jmApUabTIBA",
  authDomain: "towny56-8ebcd.firebaseapp.com",
  projectId: "towny56-8ebcd",
  storageBucket: "towny56-8ebcd.firebasestorage.app",
  messagingSenderId: "468516138675",
  appId: "1:468516138675:web:4bf71f3dcb7efd311b4ac6",
  measurementId: "G-YCLT127K0X"
};

const app = initializeApp(firebaseConfig);
export const firebaseAuth = getAuth(app);

// Initialize global variables
if (typeof window !== 'undefined') {
  window.recaptchaVerifier = null;
  window.confirmationResult = null;
}

export const setupRecaptcha = (containerId: string): void => {
  // If verifier already exists, do nothing - only create ONCE
  if (window.recaptchaVerifier) {
    console.log('reCAPTCHA already initialized');
    return;
  }

  // Wait for container to be available
  const container = document.getElementById(containerId);
  if (!container) {
    console.log('reCAPTCHA container not found, will retry...');
    return;
  }

  // Create new RecaptchaVerifier attached to window - ONLY ONCE
  window.recaptchaVerifier = new RecaptchaVerifier(
    firebaseAuth,
    containerId,
    {
      size: 'invisible',
      callback: () => {
        console.log('reCAPTCHA solved');
      },
      'expired-callback': () => {
        console.log('reCAPTCHA expired');
        // Clear verifier on expiry so it gets recreated
        if (window.recaptchaVerifier) {
          try {
            window.recaptchaVerifier.clear();
          } catch (e) {
            console.log('Clear error ignored:', e);
          }
          window.recaptchaVerifier = null;
        }
      }
    }
  );
  
  console.log('reCAPTCHA initialized successfully');
};

export const sendPhoneOTP = async (
  phoneNumber: string
): Promise<{ success: boolean; error?: string }> => {
  try {
    // Format phone number with country code - MUST be +91XXXXXXXXXX format
    const formattedPhone = phoneNumber.startsWith('+') ? phoneNumber : `+91${phoneNumber}`;
    
    console.log('Sending OTP to:', formattedPhone);

    // Use existing recaptcha verifier - DO NOT create new one here
    if (!window.recaptchaVerifier) {
      return { success: false, error: 'reCAPTCHA not initialized. Please refresh the page.' };
    }
    
    window.confirmationResult = await signInWithPhoneNumber(
      firebaseAuth, 
      formattedPhone, 
      window.recaptchaVerifier
    );
    
    return { success: true };
  } catch (error: any) {
    console.error('Error sending OTP:', error);
    
    // Only reset on specific errors that require re-initialization
    if (error.code === 'auth/argument-error' || error.code === 'auth/invalid-app-credential') {
      if (window.recaptchaVerifier) {
        try {
          window.recaptchaVerifier.clear();
        } catch (e) {
          console.log('Clear error ignored:', e);
        }
        window.recaptchaVerifier = null;
      }
    }
    
    return { success: false, error: error.message || 'Failed to send OTP' };
  }
};

export const verifyPhoneOTP = async (
  otp: string
): Promise<{ success: boolean; user?: any; error?: string }> => {
  try {
    if (!window.confirmationResult) {
      return { success: false, error: 'No OTP request found. Please request a new OTP.' };
    }
    
    const result = await window.confirmationResult.confirm(otp);
    // Reset after successful verification
    window.confirmationResult = null;
    return { success: true, user: result.user };
  } catch (error: any) {
    console.error('Error verifying OTP:', error);
    return { success: false, error: error.message || 'Invalid OTP' };
  }
};

export const getFirebaseIdToken = async (): Promise<string | null> => {
  const user = firebaseAuth.currentUser;
  if (user) {
    return await user.getIdToken();
  }
  return null;
};
